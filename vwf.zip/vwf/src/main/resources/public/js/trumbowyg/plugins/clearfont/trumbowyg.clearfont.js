(function ($) {
    'use strict';
    let defaultOptions = {}

    $.extend(true, $.trumbowyg, {
        // Add some translations
        langs: {
            en: {
                clearfont: 'Clear font'
            },
            ru: {
                clearfont: 'Очистить шрифт'
            }
        },

        plugins: {
            clearfont: {

                init: function (trumbowyg) {
                    trumbowyg.o.plugins.clearfont = $.extend(true, {},
                        defaultOptions,
                        trumbowyg.o.plugins.clearfont || {}
                    );

                    trumbowyg.addBtnDef('clearfont', {
                        hasIcon: false,
                        text: trumbowyg.lang.clearfont,
                        fn: function () {
                            const sel = trumbowyg.doc.getSelection();

                            if (sel.rangeCount === 0) return;

                            const range = sel.getRangeAt(0);

                            function cleanFonts(container) {
                                // Удаляем теги <font>
                                $(container).find('font').each(function () {
                                    $(this).replaceWith($(this).contents());
                                });

                                // Очищаем остальные шрифтовые стили
                                $(container).find('*').addBack().each(function () {
                                    const $this = $(this);
                                    // Удаляем специфичные шрифтовые стили
                                    $this.css({
                                        'font-family': '',
                                        'font-size': '',
                                        'color': '',
                                        'background-color': '',
                                        'line-height': '',
                                        'font-weight': '',
                                        'font-style': '',
                                        'text-decoration': ''
                                    });
                                    // Удаляем атрибут style, если он пустой после очистки
                                    if (!$this.attr('style') || $this.attr('style').trim() === '') {
                                        $this.removeAttr('style');
                                    }
                                });
                            }

                            if (range.collapsed) {
                                // Если выделения нет, очищаем стили всего содержимого редактора
                                const content = trumbowyg.$ed;

                                cleanFonts(content);
                            } else {
                                // Если есть выделение, очищаем стили только в выделенной области
                                // Создаём контейнер для содержимого выделения
                                const container = document.createElement('div');
                                container.appendChild(range.cloneContents());

                                // Очищаем внутри контейнера
                                cleanFonts(container);

                                // Удаляем исходное содержимое выделения
                                range.deleteContents();

                                // Вставляем очищенное содержимое обратно
                                const fragment = document.createDocumentFragment();
                                while (container.firstChild) {
                                    fragment.appendChild(container.firstChild);
                                }
                                range.insertNode(fragment);

                                // Обновляем выделение, чтобы избежать проблем с курсором
                                sel.removeAllRanges();
                                sel.addRange(range);
                            }

                            // Синхронизируем код редактора
                            trumbowyg.syncCode();
                        }
                    });
                }
            }
        }
    })
})(jQuery);