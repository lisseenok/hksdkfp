function initDraggable() {
    let allDraggables = document.getElementsByClassName("modal-card-head");
    if (allDraggables == null || allDraggables.length === 0) return;

    dragElement(allDraggables[0].parentElement)

    // allDraggables[0].parentElement.onmousedown = function () {
    //     dragElement(this)
    // }

    function dragElement(elmnt) {
        var pos1 = 0,
            pos2 = 0,
            pos3 = 0,
            pos4 = 0;
        let modalHeaders = document.getElementsByClassName("modal-card-head")
        if (modalHeaders == null || modalHeaders.length === 0) return;

        /* if present, the header is where you move the DIV from:*/
        modalHeaders[0].onmousedown = dragMouseDown;

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            var winW = document.documentElement.clientWidth || document.body.clientWidth,
                winH = document.documentElement.clientHeight || document.body.clientHeight;
            maxX = winW - elmnt.offsetWidth - 1,
                maxY = winH - elmnt.offsetHeight - 1;
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            //console.log((elmnt.offsetLeft - pos1), maxY, (elmnt.offsetLeft - pos1), maxX);
            if ((elmnt.offsetTop - pos2) <= maxY && (elmnt.offsetTop - pos2) >= 0) {
                elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
            }
            if ((elmnt.offsetLeft - pos1) <= maxX && (elmnt.offsetLeft - pos1) >= 0) {
                elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
            }
        }

        function closeDragElement() {
            /* stop moving when mouse button is released:*/
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }
}
