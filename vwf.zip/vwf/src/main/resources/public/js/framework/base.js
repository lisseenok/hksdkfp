const initQueue = {
    beforeInit: [],
    afterInit: []
}

const InitQueueOrder = {
    BEFORE_INIT: 'BEFORE_INIT',
    AFTER_INIT: 'AFTER_INIT'
};

const doc = $(document)

doc.ready(function () {
    initUI()

    if (typeof initForms === 'function')
        initForms()
})

function addInitFunction(initFunction, order) {
    let arrayToAddTo
    if (order === InitQueueOrder.AFTER_INIT) {
        arrayToAddTo = initQueue.afterInit
    } else if (order === InitQueueOrder.BEFORE_INIT) {
        arrayToAddTo = initQueue.beforeInit
    } else {
        console.debug(`No such order: ${order}`)
        return
    }

    arrayToAddTo.push(initFunction)
}

function initUI() {
    initQueue.beforeInit.map(f => f()) // execute page-specific initialization functions

    if (typeof initUIComponents === 'function')
        initUIComponents()

    doc.unbind("keyup")
    doc.keyup(function (e) {
        // todo check if close is present
        if (e.key === "Escape") { // escape key maps to keycode `27`
            // $('#vwf_layout_modal_zone').html("")
            $('.modal').each(function () {
                $(this).remove()
            })

            $('html').each(function () {
                $(this).removeClass('is-clipped')
            })
        }
    });

    $('.select_input').each(function () {
        let selectProps = {
            language: uiMessages.locale.code,
            theme: 'bulma',
            escapeMarkup: function(markup) {
                return markup;
            }
        }

        let select = $(this)
        select.off() // kill all listeners

        let searchAttr = select.attr('data-vwf-search')
        if (typeof searchAttr !== 'undefined' && searchAttr !== false) {
            selectProps.ajax = {
                method: 'PATCH',
                url: function (params) {
                    let uri = new URL(prepareRedirect(select.attr('data-vwf-search')))
                    uri.searchParams.append('l_filter', params.term || '')
                    uri.searchParams.append('l_page', params.page || 1)
                    return uri.toString()
                }/*,
                error: function( xhr, textStatus ) {
                    processError( xhr.status )
                }*/
            }
            //selectProps.minimumInputLength = 1
        }

        try {
            this.select2('destroy')
        } catch (err) {
        }
        select.select2(selectProps)

        let autoFormId = select.attr('data-vwf-auto-form')
        if (typeof autoFormId !== 'undefined' && autoFormId !== false) {
            select.on('change', function () {
                $('#' + select.attr('data-vwf-auto-form')).submit()
            })
        }

        let label = $('label[for="' + select.attr('id') + '"]')
        label.on('click', function () {
            select.select2('open')
        })
    })

    $('.selectize_input').each(function () {
        $(this).selectize()
    })

    $('.select_auto').each(function () {
        let select = $(this);
        select.off()
        select.on('change', function () {
            $('#' + select.attr('data-vwf-auto-form')).submit()
        })

        let label = $('label[for="' + select.attr('id') + '"]')
        label.on('click', function () {
            select.select2('open')
        })
    })

    $('.date_picker').each(function () {
        let datepicker = $(this)

        let params

        let scrollContainer = datepicker.attr('data-vwf-scroll')
        let dateFormat = datepicker.attr('data-vwf-date')
        let timeFormat = datepicker.attr('data-vwf-time')
        let minDate = datepicker.attr('data-vwf-mid')
        let maxDate = datepicker.attr('data-vwf-mad')
        let minTime = datepicker.attr('data-vwf-mit')
        let maxTime = datepicker.attr('data-vwf-mat')

        if (typeof scrollContainer !== 'undefined' && scrollContainer !== false) {
            params = {
                autoClose: true,
                container: '#' + scrollContainer,
                position({$datepicker, $target, $pointer, done}) {
                    let popper = Popper.createPopper($target, $datepicker, {
                        placement: 'top',
                        modifiers: [
                            {
                                name: 'flip',
                                options: {
                                    padding: {
                                        top: 64
                                    }
                                }
                            },
                            {
                                name: 'offset',
                                options: {
                                    offset: [0, 20]
                                }
                            },
                            {
                                name: 'arrow',
                                options: {
                                    element: $pointer
                                }
                            }
                        ]
                    })

                    return function completeHide() {
                        popper.destroy();
                        done();
                    }
                }
            }
        } else {
            params = {autoClose: true}
        }

        if (typeof dateFormat !== 'undefined' && dateFormat !== false)
            params.dateFormat = dateFormat

        if (typeof timeFormat !== 'undefined' && timeFormat !== false) {
            params.timepicker = true
            params.timeFormat = timeFormat
        }

        if (typeof timeFormat !== 'undefined' && timeFormat !== false
            && (typeof dateFormat === 'undefined' || dateFormat === false))
            params.onlyTimepicker = true

        if (typeof minDate !== 'undefined' && minDate !== false)
            params.minDate = minDate

        if (typeof maxDate !== 'undefined' && maxDate !== false)
            params.maxDate = maxDate

        if (typeof minTime !== 'undefined' && minTime !== false)
            params.minTime = minTime

        if (typeof maxTime !== 'undefined' && maxTime !== false)
            params.maxTime = maxTime

        params.locale = uiMessages.locale.datepicker[uiMessages.locale.code]

        datepicker.off()
        new AirDatepicker('#' + datepicker.attr('id'), params)
    })

    try {
        $('.vwf_code_textarea').each(function () {
            let textarea = $(this)
            let initialized = textarea.attr('data-vwf-initialized')
            let language = textarea.attr('data-vwf-lang')

            if (initialized === 'false' || initialized === false) {
                let cm = CodeMirror.fromTextArea(document.getElementById(textarea.attr('id')), {
                    lineNumbers: true,
                    mode: language,
                    readOnly: false,
                    lineWrapping: true,
                    indentUnit: 4,
                    tabSize: 4
                });
                cm.setSize(null, 500)

                textarea.attr('data-vwf-initialized', true)
            }
        })
    } catch (e) {
        console.warn('CodeMirror is not included, but field of type CODE is present.')
    }

    try {
        $('.vwf_wysiwyg_textarea').each(function () {
            let textarea = $(this)
            let realId = textarea.attr('id')
            let initialized = textarea.attr('data-vwf-initialized')

            if (initialized === 'false' || initialized === false) {
                textarea.trumbowyg({
                    lang: 'ru',
                    imageWidthModalEdit: true,
                    btns: [
                        ['fontfamily'],
                        ['clearfont'],
                        ['viewHTML'],
                        ['undo', 'redo'],
                        ['formatting'],
                        ['strong', 'em', 'del'],
                        ['foreColor', 'backColor', 'superscript', 'subscript'],
                        ['link'],
                        ['insertImage'],
                        ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                        ['unorderedList', 'orderedList'],
                        ['horizontalRule'],
                        ['removeformat'],
                        ['fullscreen']
                    ]
                });

                // initial DOM object gets replaced by cruel richtext plugin, so we need to pick it up by ID again to modify
                $(`#${realId}`).attr('data-vwf-initialized', true)
            }
        })
    } catch (e) {
        console.warn('jQuery RichText is not included, but field of type WYSIWYG is present.')
    }

    $('.has_mask').each(function () {
        let input = $(this)
        let maskPattern = input.attr('data-vwf-mask')

        if (typeof maskPattern !== 'undefined' && maskPattern !== false)
            input.mask(maskPattern)
    })

    $('.remove_param').each(function () {
        let url = new URL(window.location.href);
        url.searchParams.delete($(this).attr('data-vwf-remove-param'))
        window.history.replaceState({page: url.href}, document.title, url.href)
    })

    $('.auto_remove').each(function () {
        let target = $(this)
        setTimeout(function () {
            target.fadeOut("slow", function () {
                target.remove()
            })
        }, 5000)
    })

    $('.vwf_ac_li').each(function () {
        let confirm = $(this)
        confirm.off()

        confirm.on('click', $.debounce(250, function (event) {
            event.stopImmediatePropagation()
            event.stopPropagation()
            let root = $(this)

            let confirmMessage = root.attr('data-vwf-confirmmessage')
            let dialogType = root.attr('data-vwf-confirmdialogtype')
            let confirmButtonLabel = root.attr('data-vwf-confirmbuttonlabel')
            let toggleId = root.attr('data-vwf-toggle')
            if (typeof confirmMessage !== 'undefined' && confirmMessage !== false) {
                Bulma().alert({
                    type: (typeof dialogType !== 'undefined' && dialogType !== false) ? dialogType : 'theme',
                    title: uiMessages.confirmAction,
                    body: confirmMessage,
                    confirm: {
                        label: (typeof confirmButtonLabel !== 'undefined' && confirmButtonLabel !== false) ? confirmButtonLabel : 'Ok',
                        onClick: function () {
                            root.addClass('is-loading')
                            ajaxAction(root.attr('action'), toggleId, root, true)
                        }
                    },
                    cancel: {
                        label: uiMessages.cancel,
                        onClick: function () {
                            if (typeof toggleId !== 'undefined' && toggleId !== false) {
                                let target = document.getElementById(toggleId)
                                if (typeof target !== 'undefined' && target != null)
                                    target.checked = target.getAttribute('checked') === 'checked' || target.getAttribute('checked') === 'true'
                                // target.checked = !target.checked
                            }
                        }
                    }
                })
                initUI()
            } else {
                root.addClass('is-loading')

                ajaxAction(root.attr('action'), toggleId, root, true)
            }
        }))

        // set auto-refresh
        let refresh = confirm.attr('data-vwf-refresh')
        if (refresh !== false && refresh != null) {
            if (typeof refresh !== 'number')
                refresh = parseInt(refresh, 10)

            setTimeout(function () {
                confirm.trigger('click')
                // ajaxAction(refresh.attr('action'), null, false)
            }, refresh)
        }
    })

    let notificationsCount = $('#vwf_notc').val()

    let link = document.querySelector("link[rel~='icon']");
    let faviconBackup = $('#vwf_ficon')
    if (notificationsCount > 0) {
        let badger = new Badger({});
        badger.value = notificationsCount

        if (typeof faviconBackup.val() == 'undefined' || faviconBackup.val() === '')
            faviconBackup.val(link.href)
    } else if (typeof faviconBackup.val() != 'undefined' && faviconBackup.val() !== '') {
        link.href = faviconBackup.val();
    }

    initQueue.afterInit.map(f => f()) // execute page-specific initialization functions

    if (typeof initDraggable === 'function')
        initDraggable()

    // loaded deferred frames
    $('.qui_deferred_frame').each(function () {
        let frame = $(this)
        ajaxAction(frame.attr('data-vwf-defer'))
    })
}

function ajaxAction(action) {
    ajaxAction(action, null)
}

function ajaxAction(action, toggleTarget) {
    ajaxAction(action, toggleTarget, true)
}

function ajaxAction(action, toggleTarget, backdrop) {
    ajaxAction(action, toggleTarget, null, backdrop)
}

function ajaxAction(action, toggleTarget, button, backdrop) {
    if (backdrop) showBackdrop()
    $.ajax({
        method: 'PATCH',
        url: action,
        success: function (response) {
            if (response.success === true) {
                processSuccessCascade(response.actions)
            } else {
                processGlobalErrors(response.globalErrors)
            }
            hideBackdrop()
            hideMenus()

            if (button) button.removeClass('is-loading')
        },
        error: function (xhr, textStatus) {
            hideBackdrop()
            hideMenus()
            if (button) button.removeClass('is-loading')
            processError(xhr.status)

            if (typeof toggleTarget !== 'undefined' && toggleTarget !== false && toggleTarget != null) {
                let target = document.getElementById(toggleTarget)
                if (typeof target !== 'undefined' && target != null)
                    target.checked = !target.checked
            }
        }
    })
}

function processError(status) {
    if (status === 500) {
        iziToast["error"]({
            title: uiMessages.errors.error,
            message: uiMessages.errors.server,
            position: 'topRight'
        })
    } else {
        iziToast["error"]({
            title: uiMessages.errors.error,
            message: uiMessages.errors.notFound,
            position: 'topRight'
        })
    }
}

function processSuccessCascade(cascade) {
    processSuccessCascade(cascade, true)
}

function processSuccessCascade(cascade, backdrop) {
    if (typeof cascade === 'undefined' || cascade == null || cascade === [])
        return

    for (let action of cascade) {
        if (typeof action === 'undefined' || action == null)
            continue

        if (action.action === 'redirect') {
            window.location.href = prepareRedirect(action.uri)
        } else if (action.action === 'notify') {
            iziToast[action.type]({
                title: action.title ?? '',
                message: action.message,
                position: 'topRight'
            })
        } else if (action.action === 'loadFragment') {
            replaceWithFragment(action.uri, action.targetId, backdrop)
        } else if (action.action === 'insertPayload') {
            $('#' + action.targetId).html(action.payload)
        } else if (action.action === 'openModal') {
            openModal(action.uri)
        } else if (action.action === 'closeModal') {
            closeModal()
        } else if (action.action === 'downloadFile') {
            download(action.file)
        } else if (action.action === 'reloadPage') {
            window.location.reload()
        } else if (action.action === 'reloadRootFrame') {
            let frame = action.frame ?? 'content_frame'
            replaceWithFragment(window.location.pathname + window.location.search, `${frame}_${h_id}`, backdrop)
        } else if (action.action === 'jsfn') {
            try {
                let data = JSON.parse(action.fnData)

                if (data == null)
                    window[action.fn]()
                else
                    window[action.fn](data)
            } catch (e) {
                console.log('JSFN failed', e)
            }
        } else if (action.action === 'nth') {
            // do nothing
        }
    }
}

function processGlobalErrors(errors) {
    if (typeof errors === 'undefined' || errors == null || errors === [])
        return

    for (let error of errors) {
        iziToast["error"]({
            message: error,
            position: 'topRight'
        })
    }
}

$('.notification').on('click', '.delete', (e) => {
    $(e.target).parent().remove();
});

function downloadFile(uri) {
    showBackdrop()
    $.ajax({
        method: 'GET',
        url: prepareRedirect(uri),
        success: function (response) {
            download(response)

            hideBackdrop()
        },
        error: function (xhr, textStatus) {
            hideBackdrop()
            processError(xhr.status)
        }
    })
}

function download(file) {
    /*var anchor = document.createElement("a")
    document.body.appendChild(anchor)
    anchor.style.display = 'none'
    anchor.target = '_blank'
    let blob = new Blob([file.content], {type: file.contentType})
    let url = window.URL.createObjectURL(blob);
    anchor.href = url;
    anchor.download = file.fileName;
    anchor.click();
    window.URL.revokeObjectURL(url);*/

    let mime = file.contentType
    let bstr = atob(file.content);
    let n = bstr.length;
    let uint8Array = new Uint8Array(n);
    while (n--) {
        uint8Array[n] = bstr.charCodeAt(n);
    }
    let processed = new File([uint8Array], file.fileName, {type: mime});
    saveAs(processed, file.fileName)
}

function prepareRedirect(uri) {
    let url = window.location.origin
    if (url.endsWith('/'))
        url.substring(0, url.length - 2)
    if (!uri.startsWith('/'))
        uri = '/' + uri
    return url + uri
}

function replaceWithFragment(uri) {
    replaceWithFragment(uri, true)
}

function replaceWithFragment(uri, backdrop) {
    replaceWithFragment(uri, 'content_zone')
}

function replaceWithFragment(uri, target) {
    replaceWithFragment(uri, target, true)
}

let LOCK = false

function replaceWithFragment(uri, target, backdrop) {
    if (LOCK) {
        setTimeout(function () {
            replaceWithFragment(uri, target, backdrop)
        }, 100)
    } else {
        if (backdrop) showBackdrop()
        LOCK = true
        $.ajax({
            method: 'GET',
            url: prepareRedirect(uri),
            success: function (response) {
                $('#' + target).replaceWith(response)
                initUI()

                if (typeof initForms === 'function')
                    initForms()

                if (backdrop) hideBackdrop()
                LOCK = false
            },
            error: function (xhr, textStatus) {
                processError(xhr.status)
                if (backdrop) hideBackdrop()
                LOCK = false
            }
        })
    }
}

function insertFragment(uri, target) {
    showBackdrop()
    $.ajax({
        method: 'GET',
        url: prepareRedirect(uri),
        success: function (response) {
            $('#' + target).html(response)
            initUI()

            if (typeof initForms === 'function')
                initForms()

            hideBackdrop()
        },
        error: function (xhr, textStatus) {
            processError(xhr.status)
            hideBackdrop()
        }
    })
}
