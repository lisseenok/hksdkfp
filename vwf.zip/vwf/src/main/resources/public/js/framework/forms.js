function initForms() {
    let forms = $( 'form' );

    forms.each(function () {
        let form = $( this );
        form.off('submit')
        form.on('submit', function (e) {
            let jForm = $( this );
            let asynchronous = jForm.attr( 'data-vwf-async' )
            let noval = jForm.attr( 'novalidate' )
            if ( ( typeof asynchronous !== 'undefined' && asynchronous !== false )
                || ( typeof noval !== 'undefined' && noval !== false ) ) {
                e.preventDefault()
                e.stopPropagation()

                onFormSubmit( jForm )
            }
        })
    })
}

$.fn.disableSubmits = function () {
    let submits = this.findSubmits()

    submits.each( function () {
        let submit = $( this )
        submit.attr( 'disabled', 'disabled' )
        submit.addClass( 'is-disabled' )
        submit.addClass( 'is-loading' )
    } )
}

$.fn.enableSubmits = function () {
    let submits = this.findSubmits()

    submits.each( function () {
        let submit = $( this )
        submit.removeAttr( 'disabled' )
        submit.removeClass( 'is-disabled' )
        submit.removeClass( 'is-loading' )
    } )
}

$.fn.findSubmits = function () {
    let formId = this.attr( 'id' )
    return  $( '#' + formId + ' button[type="submit"], #' + formId + ' input[type="submit"], '
        + 'button[type="submit"][form="' + formId + '"], input[type="submit"][form="' + formId + '"]' )
}

$.fn.serializeIds = function () {
    let id = this.attr( 'id' )
    let ids = []
    $( '#' + id + ' input, #' + id + ' select, #' + id + ' textarea, '
        + ' input[data-vwf-form=\'' + id + '\'], select[data-vwf-form=\'' + id + '\'], textarea[data-vwf-form=\'' + id + '\']')
        .map( function() {
            let fieldId = $( this ).attr( 'id' )
            if ( !ids.includes( fieldId ) ) ids.push( fieldId )
        } )

    return ids;
}

$.fn.serializeObject = async function() {
    let output = {
        csrf: '',
        fields: {},
        files: {}
    };

    for ( let id of this.serializeIds() ) {
        if ( typeof id === 'undefined' )
            continue

        if ( id.includes( '.' ) ) {
            id = id.replaceAll( '.', '\\.' )
        }

        let field = $( '#' + id )
        let isFileInput = field.is( 'input' ) && field.attr( 'type' ) === 'file'
        let isCheckBox = field.is( 'input' ) && ( field.attr( 'type' ) === 'checkbox' )
        let isRadio = field.is( 'input' ) && ( field.attr( 'type' ) === 'radio' )
        let name = field.attr( 'name' )

        if ( typeof name === 'undefined' || name === false || name === 'undefined' || name === '' ) continue // skip if no name

        // process value according to input type
        if ( isFileInput ) {
            let fileDatas = await fileListToBase64( field[0].files )
            output.files[name] = fileDatas // either a single file or multiple
        } else {
            let val = field.val()
            if ( !Array.isArray( val ) ) val = [val] // convert to array

            if ( isCheckBox ) {
                output.fields[name] = [field.prop( 'checked' )]
            } else if ( isRadio ) {
                if ( field.is( ':checked' ) ) output.fields[name] = val
            } else {
                output.fields[name] = val
            }
        }
    }

    return output;
};

async function fileListToBase64(fileList) {
    function getBase64( file ) {
        const reader = new FileReader()
        return new Promise( resolve => {
            reader.onload = ev => {
                resolve( {
                    fileName: file.name,
                    contentType: file.type,
                    content: ev.target.result.replace( 'data:' + file.type + ';base64,', '' )
                } )
            }
            reader.readAsDataURL( file )
        } )
    }
    const promises = []

    for ( let file of fileList )
        promises.push( getBase64( file ) )

    return await Promise.all( promises )
}

function onFormSubmit( jForm ) {
    if ( validateFormLocal( jForm ) ) {
        jForm.serializeObject().then( data => {
            jForm.disableSubmits()
            $.ajax({
                method: 'POST',
                url: jForm.attr('action'),
                contentType: 'application/json',
                data: JSON.stringify( data ),
                success: function (response) {
                    jForm.enableSubmits()
                    if (response.success === true) {
                        processSuccessCascade( response.actions )
                    } else {
                        if ( response.fieldErrors != null && Object.keys( response.fieldErrors ).length > 0 ) {
                            jForm.serializeIds().map( fieldId => {
                                $('#' + fieldId).removeClass('is-danger')
                                $('#' + fieldId + '_err').addClass('is-hidden')
                            })

                            Object.keys( response.fieldErrors ).map(err => {
                                $('#' + err).addClass('is-danger')
                                let errField = $('#' + err + '_err')
                                let html = response.fieldErrors[err].join(';<br>')
                                errField.html( html )
                                errField.removeClass('is-hidden')
                            })

                            iziToast['error']({
                                title: '',
                                message: uiMessages.errors.formIncomplete,
                                position: 'topRight'
                            })
                        }

                        processGlobalErrors( response.globalErrors )
                    }
                },
                error: function( xhr, textStatus ) {
                    jForm.enableSubmits()
                    processError( xhr.status )
                }
            })
        } )
    }
}

function validateFormLocal( jForm ) {
    let result = true;

    let fieldIds = jForm.serializeIds()

    fieldIds.filter( fId => typeof fId !== 'undefined' )
    fieldIds.map(fieldId => {
        if ( typeof fieldId !== 'undefined' ) {
            let field = $('#' + fieldId)
            let selectContainer = $( 'span[aria-controls="select2-' + fieldId + '-container"]' )
            let errField = $('#' + fieldId + '_err')

            if ( field.is( 'select' ) ) {
                selectContainer.removeClass( 'is-danger' )
            } else {
                field.removeClass( 'is-danger' )
            }

            let required = field.attr('required')
            let pattern = field.attr( 'pattern' )
            errField.addClass('is-hidden')

            let errors = []

            if ( field.attr( 'type' ) === 'file' ) {
                let files = field[0].files
                if ( typeof required !== 'undefined' && required !== false
                    && ( typeof files === 'undefined' || files.length === 0 ) ) {
                        errors.push( uiMessages.validation.required )
                } else {
                    let maxSize = field.attr('data-vwf-max-size')
                    let extensionsAttr = field.attr('data-vwf-extensions')
                    let mimeTypes = field.attr('data-vwf-mime-types')

                    for ( let file of files ) {
                        if ( typeof maxSize !== 'undefined' ) {
                            if (file.size > maxSize)
                                errors.push(uiMessages.validation.file.size
                                    .format( file.name, formatBytes( maxSize ), formatBytes( file.size ) ) )
                        }

                        if ( typeof mimeTypes !== 'undefined' ) {
                            let extensions = mimeTypes.split( '|' )
                            if (extensions.includes('application/zip')) extensions.push('application/x-zip-compressed')
                            if ( !extensions.includes( file.type ) )
                                errors.push( uiMessages.validation.file.extension
                                    .format( file.name, extensionsAttr.replaceAll( ',', ', ' ) ) )
                        }
                    }
                }
            } else {
                if ( typeof required !== 'undefined' && required !== false ) {
                    if ( field.is( 'input[type="checkbox"]' ) ) {
                        if ( !field.is( ':checked' ) )
                            errors.push( uiMessages.validation.required )
                    } else {
                        if ( typeof field.val() === 'undefined' || field.val() === '' || field.val() === null
                            || ( $.isArray( field.val() ) && field.val().length == 0 ) ) {
                            errors.push( uiMessages.validation.required )
                        } else if ( typeof pattern !== 'undefined' && pattern !== false ) {
                            let regexp = new RegExp( pattern )
                            if ( !regexp.test( field.val() ) ) {
                                let patternHelp = field.attr( 'data-vwf-pattern' )
                                if ( typeof patternHelp !== 'undefined' && patternHelp !== false ) {
                                    errors.push( uiMessages.validation.pattern.format( ' <' + patternHelp + '>' ) )
                                } else {
                                    errors.push( uiMessages.validation.pattern.format( '' ) )
                                }
                            }
                        }
                    }
                }
            }

            if (errors.length > 0) {
                result = false;

                if ( field.is( 'select' ) ) {
                    selectContainer.addClass( 'is-danger' )
                } else {
                    field.addClass('is-danger')
                }

                errField.removeClass('is-hidden')
                errField.html(errors.join(';<br>'))
            }
        }
    } )

    // extend validation on page. function validateCustom( jForm ) accepts jQuery form and must return 'true' or 'false'
    if ( typeof validateCustom === 'function' ) {
        result = validateCustom( jForm );
    }

    if (!result) {
        iziToast['error']({
            title: '',
            message: uiMessages.errors.formIncomplete,
            position: 'topRight'
        })
    }

    return result;
}

String.prototype.format = function () {
    let args = arguments;
    return this.replace(/{([0-9]+)}/g, function (match, index) {
        return typeof args[index] == 'undefined' ? match : args[index];
    });
};

function formatBytes( bytes ) {
    let units = [uiMessages.validation.file.units.b, uiMessages.validation.file.units.kb, uiMessages.validation.file.units.mb, uiMessages.validation.file.units.gb, uiMessages.validation.file.units.tb]
    let i

    for ( i = 0; bytes >= 1024 && i < 4; i++ )
        bytes /= 1024;

    return bytes.toFixed( 2 ) + ' ' + units[i];
}
