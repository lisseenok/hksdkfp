$( document ).ready( function () {
    $( '.confirm_action' ).each( function () {
        let confirm = $( this )
        confirm.off()
        confirm.on( 'click', function () {
            let root = $( this )
            confirmAndPerform( root.attr( 'data-vwf-type' ),
                root.attr( 'action' ),
                root.attr( 'data-vwf-message' ),
                root.attr( 'data-vwf-confirm-label' ),
                root.attr( 'data-vwf-target' ),
                root.attr( 'data-vwf-refresh-offset' ),
                root.attr( 'data-vwf-reload-action' ),
                root.attr( 'data-vwf-reload-target' ),
                root.attr( 'data-vwf-history' ) )
        } )
    } )
} )

/**
 * uri - полный uri (с context path) для совершения подтверждаемого действия
 * text - текст вопроса о подтверждении
 * confirmLabel - надпись на кнопке подтврерждения
 * actionTarget - в каком окне будет выполнено действие (если синхронное) - "_blank" - хак для загрузки файлов и рефреша
 * refreshOffset - через сколько мс обновить страницу (только если actionTarget=="_blank")
 * reloadAction - откуда выгрузить фрагмент для обновления (запрос станет асинхронным)
 * reloadTarget - ID элемента, который будет заменен выгруженным асинхронно фрагментом
 */
/* deprecated */
function confirmAndPerform( type, uri, text, confirmLabel, actionTarget, refreshOffset, reloadAction, reloadTarget, history ) {
    Bulma().alert({
        type: type ?? 'info',
        title: uiMessages.confirmAction,
        body: text,
        confirm: {
            label: confirmLabel,
            onClick: function () {
                let url = prepareRedirect( uri )
                if ( typeof actionTarget !== 'undefined' && actionTarget === '_blank' ) {
                    let anchor = document.createElement('a');
                    anchor.href = url;
                    anchor.target="_blank";
                    anchor.click();

                    if ( typeof refreshOffset !== 'undefined' ) {
                        setTimeout(function () {
                            window.location.reload()
                        }, refreshOffset )
                    }
                } else if ( typeof reloadAction !== 'undefined' && typeof reloadTarget !== 'undefined' ) {
                    $.ajax({
                        method: 'GET',
                        url: url,
                        success: function () {
                            replaceWithFragment( reloadAction, reloadTarget )
                        },
                        error: function ( xhr, textStatus ) {
                            if ( xhr.status === 500 ) {
                                $.notify( uiMessages.errors.server )
                            } else {
                                $.notify( uiMessages.errors.notFound )
                            }
                        }
                    })
                } else {
                    if ( typeof history !== 'undefined' && history === 'keep' )
                        window.location.href = url
                    else
                        window.location.replace(url)
                }
            }
        },
        cancel: {
            label: uiMessages.cancel
        }
    });
}
