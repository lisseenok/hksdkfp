const SIDEBAR_KEY = 'ds_sidebar_state'
const VALUE_MINIFIED = 'minified'
const VALUE_OPEN = 'open'

$(document).ready(() => {
    let currentState = localStorage.getItem(SIDEBAR_KEY)
    let sidebar = $('#main_sidebar')

    if (sidebar.length === 0) return // no sidebar in this project

    if (currentState === VALUE_MINIFIED) {
        // it's minified
        let wasMinified = sidebar.hasClass('is-minified')

        sidebar.addClass('is-minified')
        $('#main_sidebar_head').addClass('is-hidden')
        $('#sidebar_ctrl_open').removeClass('is-hidden')

        if (!wasMinified) {
            // notify state because it forgor
            $.ajax({
                url: sidebar.attr('data-ctl') + '?m=true',
                method: 'POST',
                body: {}
            })
        }
    } else {
        // it's open
        sidebar.removeClass('is-minified')
        $('#main_sidebar_head').removeClass('is-hidden')
        $('#sidebar_ctrl_close').removeClass('is-hidden')
    }
})

function toggleSidebar() {
    let sidebar = $('#main_sidebar')
    let minified = false

    if (sidebar.hasClass('is-minified')) {
        sidebar.removeClass('is-minified')
        $('#main_sidebar_head').removeClass('is-hidden')
        $('#sidebar_ctrl_close').removeClass('is-hidden')
        $('#sidebar_ctrl_open').addClass('is-hidden')
        localStorage.setItem(SIDEBAR_KEY, VALUE_OPEN)
    } else {
        sidebar.addClass('is-minified')
        $('#main_sidebar_head').addClass('is-hidden')
        $('#sidebar_ctrl_close').addClass('is-hidden')
        $('#sidebar_ctrl_open').removeClass('is-hidden')
        localStorage.setItem(SIDEBAR_KEY, VALUE_MINIFIED)

        minified = true
    }

    // notify state
    $.ajax({
        url: sidebar.attr('data-ctl') + '?m=' + minified,
        method: 'POST',
        body: {}
    })
}
