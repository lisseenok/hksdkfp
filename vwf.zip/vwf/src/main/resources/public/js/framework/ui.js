function initUIComponents() {
    let navBurgers = $('.navbar-burger')
    navBurgers.each(function () {
        let navTrigger = $(this)
        navTrigger.off()
        navTrigger.on('click', function () {
            let expanded = navTrigger.attr('aria-expanded')
            let navMenu = $('#' + navTrigger.attr('data-target'))
            if (typeof expanded != 'undefined' && expanded == 'true') {
                navBurgers.each(function () {
                    let currentTrigger = $(this)
                    currentTrigger.attr('aria-expanded', 'false')
                    currentTrigger.removeClass('is-active')
                })
                navMenu.removeClass('is-active')
            } else {
                navBurgers.each(function () {
                    let currentTrigger = $(this)
                    currentTrigger.attr('aria-expanded', 'true')
                    currentTrigger.addClass('is-active')
                })
                navMenu.addClass('is-active')
            }
        })
    })

    $('.dropdown-trigger').each(function () {
        let dropdownTrigger = $(this)
        let parent = dropdownTrigger.parent()
        if (parent.hasClass('is-hoverable')) return

        dropdownTrigger.off()
        dropdownTrigger.on('click', function () {
            let parent = dropdownTrigger.parent()
            let ddContent = parent.find('.dropdown-content').first()
            let windowWidth = $(window).width()

            if (parent.attr('data-fixed') != null
                && parent.attr('data-fixed') !== 0
                && (windowWidth > 768 || !ddContent.parent().hasClass('mobile-dropdown'))) {

                let buttonOffset = dropdownTrigger.offset()
                let buttonWidth = dropdownTrigger.outerWidth()

                if (parent.attr('data-fixed') === 'right') {
                    let distanceToRBorder = windowWidth - (buttonOffset.left + buttonWidth)
                    ddContent.css({
                        'position': 'fixed',
                        'right': distanceToRBorder + 'px',
                        'max-width': `calc(98vw - ${distanceToRBorder})`
                    })
                } else if (parent.attr('data-fixed') === 'left') {
                    let distanceToLBorder = buttonOffset.left
                    ddContent.css({
                        'position': 'fixed',
                        'left': distanceToLBorder + 'px'
                    })
                }
            }

            if (parent.hasClass('is-active')) {
                parent.removeClass('is-active')
                $('#screen_mask').hide()
            } else {
                parent.addClass('is-active')
                $('#screen_mask').show()
            }
        })
    })

    $('.navbar-item.has-dropdown > a.navbar-link').each(function () {
        let dropdownTrigger = $(this)
        let dropdownMenu = $('#' + dropdownTrigger.attr('aria-controls'))

        if (!dropdownTrigger.hasClass('is-active'))
            dropdownMenu.addClass('is-hidden')

        dropdownTrigger.off()
        dropdownTrigger.on('click', function () {
            let hidden = dropdownMenu.hasClass('is-hidden')
            if (hidden) {
                hideMenus()
                dropdownTrigger.addClass('is-active')
                dropdownMenu.removeClass('is-hidden')
                $('#screen_mask').show()
            } else {
                hideMenus()
            }
        })
    })

    $('.tabpanel-link').each(function () {
        let tabpanelLink = $(this)

        if (tabpanelLink.hasClass('active')) {
            let container = tabpanelLink.parent().closest('.tabpanel-wrapper')

            var containerRect = container[0].getBoundingClientRect();
            var elementRect = tabpanelLink[0].getBoundingClientRect();

            var isElementVisible = (
                elementRect.left >= containerRect.left &&
                elementRect.right <= containerRect.right
            );

            if (!isElementVisible) {
                container.animate({
                    scrollLeft: tabpanelLink.position().left + container.scrollLeft()
                }, 500);
            }
        }
    })

    let url = new URL(window.location.href)
    if (url.searchParams.has('l_md')
        && url.searchParams.get('l_md') != null
        && url.searchParams.get('l_md') !== ''
        && $('.modal').length === 0) {
        let modal = atob(url.searchParams.get('l_md'))
        openModal(modal)
    }
}

function hideMenus() {
    $('.dropdown').each(function () {
        $(this).removeClass('is-active')
    })
    $('.navbar-item.has-dropdown > a.navbar-link').each(function () {
        let dropdownTrigger = $(this)
        dropdownTrigger.removeClass('is-active')
        $('#' + dropdownTrigger.attr('aria-controls')).addClass('is-hidden')
    })
    $('#screen_mask').hide()
}

$(document).ready(() => {
    window.addEventListener('popstate', () => {
        if ($('.modal').length > 0) closeModal()
    })
})

function openModal(uri) {
    showBackdrop()
    insertFragment(uri, 'vwf_layout_modal_zone')

    // for 'back' button interactivity
    let url = new URL(window.location.href)
    url.searchParams.set('l_md', btoa(uri))

    window.history.pushState({page: url.href}, document.title, url.href)
}

function closeModal() {
    $('#vwf_layout_modal_zone').html('')
    let url = new URL(window.location.href)
    url.searchParams.delete('l_md')
    window.history.replaceState({page: url.href}, document.title, url.href)
}

function showBackdrop(event) {
    if (event != null
        && (event.target.tagName.toLowerCase() === 'a'
            || event.target.parent.tagName.toLowerCase() === 'a') // if it's a link (or a direct parent is)
        && (event.metaKey // and cmd, ctrl or shift are pressed
            || event.ctrlKey
            || event.shiftKey))
        return // will not perform for external link click

    $('#loading_backdrop').fadeIn("fast")
}

function hideBackdrop() {
    $('#loading_backdrop').fadeOut("fast")
    // $( '#loading_backdrop' ).addClass( 'is-hidden' )
}

let globalWebCam = null

function openWebCam(target) {
    let camId = target + '_cam_apnd'
    let camWrapper = $('#' + camId + '_p')

    if (camWrapper.hasClass('is-hidden')) {
        camWrapper.removeClass('is-hidden')

        if (globalWebCam == null) {
            globalWebCam = new WebCamera({
                constraints: {
                    video: {
                        width: 320,
                        height: 240
                    }
                }
            });
        }

        let container = document.getElementById(camId);
        container.appendChild(globalWebCam.getVideoTag())

        globalWebCam.startCamera()
    } else {
        camWrapper.addClass('is-hidden')
        $('#' + camId).html('')

        globalWebCam.stopCamera()
    }
}

function snapWebCam(target) {
    globalWebCam.takePhoto().then(function (blob) {
        // turn blob into input value
        let file = new File([blob], "photo.jpg", {type: "image/jpeg", lastModified: new Date().getTime()})
        let dataTransfer = new DataTransfer()
        dataTransfer.items.add(file)

        document.getElementById(target).files = dataTransfer.files

        let camId = target + '_cam_apnd';
        $('#' + camId + '_p').addClass('is-hidden')
        $('#' + camId).html('')

        globalWebCam.stopCamera()
    })
}
