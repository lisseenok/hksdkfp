$(document).ready(function () {
    window.addEventListener('load', function () {
        $('#debug_load_time').text(performance.now() + ' ms')
    }, false);

    window.addEventListener('mousemove', function (event) {
        let x = event.clientX
        let y = event.clientY
        $('#debug_mouse_position_x').text(x)
        $('#debug_mouse_position_y').text(y)

        let els = document.elementsFromPoint(x, y)
        let elsField = $('#debug_mouse_position_elements')
        if (typeof els !== 'undefined' && els.length > 0) {
            elsField.html(els.length)
        } else {
            elsField.html('none')
        }
    })

    try {
        if (window.performance && performance.getEntriesByType) { // avoid error in Safari 10, IE9- and other old browsers
            let navTiming = performance.getEntriesByType('navigation')
            if (navTiming.length > 0) { // still not supported as of Safari 14...
                let serverTiming = navTiming[0].serverTiming
                if (serverTiming && serverTiming.length > 0) {
                    for (let i = 0; i < serverTiming.length; i++) {
                        if (serverTiming[i].name === 'debug-load-time') {
                            $('#debug_ssr_time').html(serverTiming[i].description)
                        }
                    }
                }
            }
        }
    } catch (e) {
        console.warn('Couldn\'t read debug headers.')
    }

    [...document.querySelectorAll('[id]')].forEach(el => {
        const dups = document.querySelectorAll(`[id="${el.id}"]`);

        if (dups[1] === el) {
            iziToast["warning"]({
                message: 'Duplicate IDs are present on page. See console.'
            })

            console.error(`Duplicate IDs #${el.id}`, ...dups);
        }
    });
})

function showElementBorders(doShow) {
    console.log($('.is_qui_frame'))
    if (doShow) {
        $('head').append(`<style id="debug_borders">
    .is_qui_frame {
        border: 1px solid #ff0000 !important;
    }
    
    .is_debug_qui {
        float: right;
        border: 1px solid #ff0000;
        border-right: none;
        border-top: none;
        background-color: #ffdbdb;
        font-size: 70%;
        color: #8b0000;
    }
</style>`)
        $('.is_qui_frame').each(function () {
            let frame = $(this)
            frame.html(`<div class="is_debug_qui">
    <strong>Handler:</strong>&nbsp;${frame.attr('data-debug-handler')}<br/>
    <strong>Handler ID:</strong>&nbsp;${frame.attr('data-debug-handler-id')}
</div>` + frame.html())
        })
        initUI()

        $('#debug_borders_show').addClass('is-hidden')
        $('#debug_borders_hide').removeClass('is-hidden')
    } else {
        $('#debug_borders').remove()
        $('#debug_borders_hide').addClass('is-hidden')
        $('#debug_borders_show').removeClass('is-hidden')

        $('.is_debug_qui').each(function () {
            $(this).remove()
        })
        initUI()
    }
}
