package ru.adaptms.quickui.annotation.ext;

import ru.adaptms.quickui.handler.AbstractUIHandler;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author ppolyakov at 21.02.2022 04:16
 */
@Retention( RetentionPolicy.RUNTIME)
@Target( value = {ElementType.TYPE, ElementType.METHOD})
public @interface Extension {
    Class<? extends AbstractUIHandler> handler();
    ActionType action() default ActionType.ADD_AFTER;
    ExtensionTarget target();
    int priority() default 1000;
}
