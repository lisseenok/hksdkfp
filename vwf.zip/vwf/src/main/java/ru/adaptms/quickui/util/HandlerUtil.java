package ru.adaptms.quickui.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.handler.meta.HandlerParamMeta;
import ru.adaptms.vwf.util.SpringUtils;
import ru.adaptms.vwf.util.conversion.StringConversions;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

/**
 * Util for quickly operating with mappings
 *
 * @author ppolyakov at 21.02.2022 04:03
 */
@Service( "quickui_handlerutil" )
public class HandlerUtil {
    private static final Logger LOGGER = LoggerFactory.getLogger( HandlerUtil.class );

    public static HandlerUtil instance() { return SpringUtils.getInstance( HandlerUtil.class ); }

    /**
     * Removes parameters that are irrelevant to page state (listener parameters)
     * @param componentParameters input parameters
     * @return new map with state parameters
     */
    public static Map<String, String> getIdentifyingParams( Map<String, String> componentParameters ) {
        if ( componentParameters == null || componentParameters.isEmpty() )
            return componentParameters;

        Map<String, String> parametersCopy = new HashMap<>( componentParameters );
        for ( String key : componentParameters.keySet() ) {
            if ( "lang".equals( key )
                    || key.startsWith( AbstractUIHandler.LISTENER_PREFIX ) )
                parametersCopy.remove( key );
        }

        return parametersCopy;
    }

    /**
     * Set parameters to handler ({@link ru.adaptms.quickui.annotation.HandlerParam})
     * @param handler handler to set parameter to
     * @param parameters map of incoming parameters to choose from
     */
    public static void setParameters( AbstractUIHandler handler, Map<String, Object> parameters, boolean isCode ) {
        HandlerMeta meta = handler.getMeta();

        if ( handler.getParameters() == null ) return;

        for ( HandlerParamMeta param : meta.getParams() ) {
            try {
                String key = isCode ? param.getParamCode() : param.getName();
                if ( !parameters.containsKey( key ) ) {
                    if ( param.isRequired() ) {
                        throw new IllegalArgumentException( "Required parameter \"" + param.getName() + "\" is not passed." );
                    } else {
                        // leave it be
                        //param.getSetter().invoke( handler, new Object[]{null} );
                    }
                } else {
                    Object value = parameters.get( key );
                    if ( value instanceof String strValue ) {
                        param.getSetter().invoke( handler, StringConversions.instance().convert( strValue, param.getParamClass() ) );
                    } else {
                        param.getSetter().invoke( handler, value );
                    }
                }
            } catch ( IllegalAccessException | InvocationTargetException e ) {
                LOGGER.error( "Couldn't set parameter \"" + param.getName() + "\".", e );
            }
        }
    }
}
