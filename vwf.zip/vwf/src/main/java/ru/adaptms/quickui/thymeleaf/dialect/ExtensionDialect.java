package ru.adaptms.quickui.thymeleaf.dialect;

import org.thymeleaf.processor.IProcessor;
import ru.adaptms.quickui.thymeleaf.processor.component.ComponentProcessor;
import ru.adaptms.quickui.thymeleaf.processor.ext.ExtIdTagProcessor;
import ru.adaptms.quickui.thymeleaf.processor.ext.ExtensionProcessor;
import ru.adaptms.quickui.thymeleaf.processor.frame.FrameProcessor;
import ru.adaptms.vwf.ui.thymeleaf.dialect.AbstractUIDialect;

import java.util.HashSet;
import java.util.Set;

/**
 * @author ppolyakov at 27.03.2022 15:35
 */
public class ExtensionDialect extends AbstractUIDialect {

    private static final String PROCESSOR_NAME = "QuickUI extension dialect";
    private static final String DIALECT_PREFIX = "ext";
    private static final int PRECEDENCE = 1;

    public ExtensionDialect() {
        super( PROCESSOR_NAME, DIALECT_PREFIX, PRECEDENCE );
    }

    @Override
    public Set<IProcessor> getProcessors( final String dialectPrefix ) {
        final Set<IProcessor> processors = new HashSet<>();

        processors.add( new ExtensionProcessor( dialectPrefix ) );
        processors.add( new ExtIdTagProcessor( dialectPrefix ) );

        return processors;
    }
}
