package ru.adaptms.quickui.fallback.notFound;

import ru.adaptms.quickui.annotation.Ignore;
import ru.adaptms.quickui.handler.page.NotFoundPage;

/**
 * @author ppolyakov at 23.02.2022 19:31
 */
@Ignore
public class FallbackNotFoundPage extends NotFoundPage {
}
