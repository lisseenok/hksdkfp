package ru.adaptms.quickui.util;

import ru.adaptms.quickui.handler.AbstractUIHandler;

import java.util.HashMap;

/**
 * @author ppolyakov at 27.02.2022 01:39
 */
public class ParameterMap extends HashMap<String, Object> {

    public static ParameterMap create( String name, Object value ) {
        return new ParameterMap().add( name, value );
    }

    public ParameterMap add( String name, Object value ) {
        String key = AbstractUIHandler.LISTENER_PREFIX + name;
        if ( this.containsKey( key ) )
            throw new IllegalArgumentException( "ParameterMap already contains parameter name \"" + name + "\". If you want to update value, use addOrUpdate() instead." );
        this.put( key, value );
        return this;
    }

    public ParameterMap addOrUpdate( String name, Object value ) {
        this.put( AbstractUIHandler.LISTENER_PREFIX + name, value );
        return this;
    }
}
