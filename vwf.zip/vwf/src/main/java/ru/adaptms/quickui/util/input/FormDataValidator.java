package ru.adaptms.quickui.util.input;

import ru.adaptms.vwf.ui.form.FormData;
import ru.adaptms.vwf.ui.form.SubmissionResult;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.util.FormattingUtil;

import java.text.MessageFormat;
import java.util.Date;

/**
 * @author ppolyakov at 26.05.2022 14:53
 */
public class FormDataValidator {
    private static final String ERROR_PREFIX = "framework.ui.validation.";

    private final FormData data;

    public FormDataValidator( FormData data ) {
        this.data = data;
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void required( String fieldNameSameAsId, SubmissionResult result ) {
        required( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void required( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !required( fieldName ) )
            result.addFieldError( fieldId, I18NService.instance().getMessage( ERROR_PREFIX + "required" ) );
    }

    public boolean required( String fieldName ) {
        return CommonValidators.required( data.getFieldValueMultiple( fieldName ) )
                || CommonValidators.requiredFile( data.getFileMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void minValues( String fieldNameSameAsId, int min, SubmissionResult result ) {
        minValues( fieldNameSameAsId, fieldNameSameAsId, min, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void minValues( String fieldName, String fieldId, int min, SubmissionResult result ) {
        if ( !minValues( fieldName, min ) )
            result.addFieldError( fieldId, getFormattedMessage( "values.min", min ) );
    }

    public boolean minValues( String fieldName, int min ) {
        return ( data.getFields() != null && CommonValidators.minValues( data.getFieldValueMultiple( fieldName ), min ) )
                || ( data.getFiles() != null && CommonValidators.minValuesFile( data.getFileMultiple( fieldName ), min ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void maxValues( String fieldNameSameAsId, int max, SubmissionResult result ) {
        maxValues( fieldNameSameAsId, fieldNameSameAsId, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void maxValues( String fieldName, String fieldId, int max, SubmissionResult result ) {
        if ( !maxValues( fieldName, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "values.max", max ) );
    }

    public boolean maxValues( String fieldName, int max ) {
        return ( data.getFields() != null && CommonValidators.maxValues( data.getFieldValueMultiple( fieldName ), max ) )
                || ( data.getFiles() != null && CommonValidators.maxValuesFile( data.getFileMultiple( fieldName ), max ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void valuesRange( String fieldNameSameAsId, int min, int max, SubmissionResult result ) {
        valuesRange( fieldNameSameAsId, fieldNameSameAsId, min, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void valuesRange( String fieldName, String fieldId, int min, int max, SubmissionResult result ) {
        if ( !valuesRange( fieldName, min, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "values.range", min, max ) );
    }

    public boolean valuesRange( String fieldName, int min, int max ) {
        return ( data.getFields() != null && CommonValidators.valuesRange( data.getFieldValueMultiple( fieldName ), min, max ) )
                || ( data.getFiles() != null && CommonValidators.valuesRangeFile( data.getFileMultiple( fieldName ), min, max ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param pattern regex pattern
     * @param result form result to apply errors to
     */
    public void regex( String fieldNameSameAsId, String pattern, SubmissionResult result ) {
        regex( fieldNameSameAsId, fieldNameSameAsId, pattern, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param pattern regex pattern
     * @param result form result to apply errors to
     */
    public void regex( String fieldName, String fieldId, String pattern, SubmissionResult result ) {
        regex( fieldName, fieldId, pattern, "", result );
    }

    /**
     *
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param pattern regex pattern
     * @param patternText human readable pattern description (e.g. "dd.MM.yyyy")
     * @param result form result to apply errors to
     */
    public void regex( String fieldName, String fieldId, String pattern, String patternText, SubmissionResult result ) {
        if ( !regex( fieldName, pattern ) )
            result.addFieldError( fieldId, getFormattedMessage( "pattern", " " + patternText ) );
    }

    public boolean regex( String fieldName, String pattern ) {
        return CommonValidators.regex( data.getFieldValueMultiple( fieldName ), pattern );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void minLength( String fieldNameSameAsId, int min, SubmissionResult result ) {
        minLength( fieldNameSameAsId, fieldNameSameAsId, min, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void minLength( String fieldName, String fieldId, int min, SubmissionResult result ) {
        if ( !minLength( fieldName, min ) )
            result.addFieldError( fieldId, getFormattedMessage( "length.min", min ) );
    }

    public boolean minLength( String fieldName, int minLength ) {
        return CommonValidators.minLength( data.getFieldValueMultiple( fieldName ), minLength );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void maxLength( String fieldNameSameAsId, int max, SubmissionResult result ) {
        maxLength( fieldNameSameAsId, fieldNameSameAsId, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void maxLength( String fieldName, String fieldId, int max, SubmissionResult result ) {
        if ( !maxLength( fieldName, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "length.max", max ) );
    }

    public boolean maxLength( String fieldName, int maxLength ) {
        return CommonValidators.maxLength( data.getFieldValueMultiple( fieldName ), maxLength );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void lengthRange( String fieldNameSameAsId, int min, int max, SubmissionResult result ) {
        lengthRange( fieldNameSameAsId, fieldNameSameAsId, min, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void lengthRange( String fieldName, String fieldId, int min, int max, SubmissionResult result ) {
        if ( !lengthRange( fieldName, min, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "length.range", min, max ) );
    }

    public boolean lengthRange( String fieldName, int minLength, int maxLength ) {
        return CommonValidators.lengthRange( data.getFieldValueMultiple( fieldName ), minLength, maxLength );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void email( String fieldNameSameAsId, SubmissionResult result ) {
        email( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void email( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !email( fieldName ) )
            result.addFieldError( fieldId, getFormattedMessage( "emails.is" ) );
    }

    public boolean email( String fieldName ) {
        return CommonValidators.email( data.getFieldValueMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void number( String fieldNameSameAsId, SubmissionResult result ) {
        number( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void number( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !number( fieldName ) )
            result.addFieldError( fieldId, getFormattedMessage( "numbers.is" ) );
    }

    public boolean number( String fieldName ) {
        return CommonValidators.number( data.getFieldValueMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void min( String fieldNameSameAsId, int min, SubmissionResult result ) {
        min( fieldNameSameAsId, fieldNameSameAsId, min, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void min( String fieldName, String fieldId, int min, SubmissionResult result ) {
        if ( !min( fieldName, min ) )
            result.addFieldError( fieldId, getFormattedMessage( "numbers.min", min ) );
    }

    public boolean min( String fieldName, int min ) {
        return CommonValidators.min( data.getFieldValueMultiple( fieldName ), min );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void max( String fieldNameSameAsId, int max, SubmissionResult result ) {
        max( fieldNameSameAsId, fieldNameSameAsId, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void max( String fieldName, String fieldId, int max, SubmissionResult result ) {
        if ( !max( fieldName, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "numbers.max", max ) );
    }

    public boolean max( String fieldName, int max ) {
        return CommonValidators.max( data.getFieldValueMultiple( fieldName ), max );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void range( String fieldNameSameAsId, int min, int max, SubmissionResult result ) {
        range( fieldNameSameAsId, fieldNameSameAsId, min, max, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void range( String fieldName, String fieldId, int min, int max, SubmissionResult result ) {
        if ( !range( fieldName, min, max ) )
            result.addFieldError( fieldId, getFormattedMessage( "numbers.range", min, max ) );
    }

    public boolean range( String fieldName, int min, int max ) {
        return CommonValidators.range( data.getFieldValueMultiple( fieldName ), min, max );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void numberFormat( String fieldNameSameAsId, String format, SubmissionResult result ) {
        numberFormat( fieldNameSameAsId, fieldNameSameAsId, format, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void numberFormat( String fieldName, String fieldId, String format, SubmissionResult result ) {
        if ( !numberFormat( fieldName, format ) )
            result.addFieldError( fieldId, getFormattedMessage( "numbers.format", format ) );
    }

    public boolean numberFormat( String fieldName, String format ) {
        return CommonValidators.numberFormat( data.getFieldValueMultiple( fieldName ), format );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void date( String fieldNameSameAsId, SubmissionResult result ) {
        date( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void date( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !date( fieldName ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.is-date" ) );
    }

    public boolean date( String fieldName ) {
        return CommonValidators.date( data.getFieldValueMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void time( String fieldNameSameAsId, SubmissionResult result ) {
        time( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void time( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !time( fieldName ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.is-time" ) );
    }

    public boolean time( String fieldName ) {
        return CommonValidators.time( data.getFieldValueMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void dateTime( String fieldNameSameAsId, SubmissionResult result ) {
        dateTime( fieldNameSameAsId, fieldNameSameAsId, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void dateTime( String fieldName, String fieldId, SubmissionResult result ) {
        if ( !dateTime( fieldName ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.is-date-time" ) );
    }

    public boolean dateTime( String fieldName ) {
        return CommonValidators.dateTime( data.getFieldValueMultiple( fieldName ) );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void before( String fieldNameSameAsId, Date threshold, SubmissionResult result ) {
        before( fieldNameSameAsId, fieldNameSameAsId, threshold, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void before( String fieldName, String fieldId, Date threshold, SubmissionResult result ) {
        if ( !before( fieldName, threshold ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.before",
                    FormattingUtil.instance().formatDate( threshold, "dd.MM.yyyy" ) ) );
    }

    public boolean before( String fieldName, Date threshold ) {
        return CommonValidators.before( data.getFieldValueMultiple( fieldName ), threshold );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void after( String fieldNameSameAsId, Date threshold, SubmissionResult result ) {
        after( fieldNameSameAsId, fieldNameSameAsId, threshold, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void after( String fieldName, String fieldId, Date threshold, SubmissionResult result ) {
        if ( !after( fieldName, threshold ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.after",
                    FormattingUtil.instance().formatDate( threshold, "dd.MM.yyyy" ) ) );
    }

    public boolean after( String fieldName, Date threshold ) {
        return CommonValidators.after( data.getFieldValueMultiple( fieldName ), threshold );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void dateRange( String fieldNameSameAsId, Date rangeStart, Date rangeEnd, SubmissionResult result ) {
        dateRange( fieldNameSameAsId, fieldNameSameAsId, rangeStart, rangeEnd, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void dateRange( String fieldName, String fieldId, Date rangeStart, Date rangeEnd, SubmissionResult result ) {
        if ( !dateRange( fieldName, rangeStart, rangeEnd ) )
            result.addFieldError( fieldId, getFormattedMessage( "dates.range",
                    FormattingUtil.instance().formatDate( rangeStart, "dd.MM.yyyy" ),
                    FormattingUtil.instance().formatDate( rangeEnd, "dd.MM.yyyy" )
            ) );
    }

    public boolean dateRange( String fieldName, Date periodStart, Date periodEnd ) {
        return CommonValidators.dateRange( data.getFieldValueMultiple( fieldName ), periodStart, periodEnd );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void fileExtension( String fieldNameSameAsId, String[] extensions, SubmissionResult result ) {
        fileExtension( fieldNameSameAsId, fieldNameSameAsId, extensions, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void fileExtension( String fieldName, String fieldId, String[] extensions, SubmissionResult result ) {
        if ( !fileExtension( fieldName, extensions ) )
            result.addFieldError( fieldId, getFormattedMessage( "files.extension", String.join( ", ", extensions ) ) );
    }

    public boolean fileExtension( String fieldName, String... extensions ) {
        return CommonValidators.fileExtension( data.getFileMultiple( fieldName ), extensions );
    }

    /**
     * @param fieldNameSameAsId field ID and NAME (treated as same)
     * @param result form result to apply errors to
     */
    public void fileSize( String fieldNameSameAsId, int maxSizeInBytes, SubmissionResult result ) {
        fileSize( fieldNameSameAsId, fieldNameSameAsId, maxSizeInBytes, result );
    }

    /**
     * @param fieldName field NAME
     * @param fieldId field ID
     * @param result form result to apply errors to
     */
    public void fileSize( String fieldName, String fieldId, int maxSizeInBytes, SubmissionResult result ) {
        if ( !fileSize( fieldName, maxSizeInBytes ) )
            result.addFieldError( fieldId, getFormattedMessage( "files.size", ProcessorHelper.formatMaxFileSize( maxSizeInBytes ) ) );
    }

    public boolean fileSize( String fieldName, int maxSizeInBytes ) {
        return CommonValidators.fileSize( data.getFileMultiple( fieldName ), maxSizeInBytes );
    }

    private String getFormattedMessage( String key, Object... arguments ) {
        return MessageFormat.format( I18NService.instance().getMessage( ERROR_PREFIX + key ), arguments );
    }
}
