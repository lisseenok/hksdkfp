package ru.adaptms.quickui.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.SpringUtils;

import java.util.List;

/**
 * @author ppolyakov at 23.02.2022 18:49
 */
@Service( "quickui_securitymanager" )
public class QuickUISecurityManager {
    public static QuickUISecurityManager instance() { return SpringUtils.getInstance( QuickUISecurityManager.class ); }

    private List<IQuickUISecurityResolver> resolvers;

    public boolean isAllowed( String input ) {
        if ( resolvers == null || resolvers.isEmpty() ) return true;

        for ( IQuickUISecurityResolver resolver : resolvers ) {
            if ( !resolver.isAllowed( input ) )
                return false;
        }

        return true;
    }

    @Autowired( required = false )
    public void setResolvers( List<IQuickUISecurityResolver> resolvers ) {
        this.resolvers = resolvers;
    }
}
