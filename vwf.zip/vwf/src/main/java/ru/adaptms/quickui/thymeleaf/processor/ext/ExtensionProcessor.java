package ru.adaptms.quickui.thymeleaf.processor.ext;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.annotation.ext.ActionType;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerExtensionMeta;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.registry.MappingRegistry;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class ExtensionProcessor extends AbstractElementModelProcessor {

    private static final String ATTR_NAME = "extendable";
    private static final int PRECEDENCE = 1;

    public ExtensionProcessor( final String dialectPrefix ) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                null,
                false,
                ATTR_NAME,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess( ITemplateContext context,
                              IModel model,
                              IElementModelStructureHandler structureHandler ) {
        final IModelFactory modelFactory = context.getModelFactory();

        AbstractUIHandler handler = ( AbstractUIHandler ) context.getVariable( AbstractUIHandler.HANDLER_VARIABLE );

        for ( HandlerExtensionMeta extension : handler.getMeta().getExtensions() ) {
            Integer toRemoveFirst = null;
            Integer toRemoveLast = null;

            Integer insertPosition = null;

            for ( int n = 0; n < model.size(); n++ ) {
                final ITemplateEvent event = model.get( n );

                if ( event instanceof IProcessableElementTag tag ) {
                    String attr = extension.getTargetType().getAttrName();

                    if ( !tag.hasAttribute( attr )
                            || !tag.getAttributeValue( attr ).equals( extension.getTargetAttrValue() ) )
                        continue;

                    if ( extension.getActionType() == ActionType.ADD_BEFORE ) {
                        insertPosition = n - 1;
                        break;
                    } else if ( extension.getActionType() == ActionType.ADD_AFTER ) {
                        insertPosition = calculateLastPosition( model, n ) + 1;
                        break;
                    } else if ( extension.getActionType() == ActionType.REPLACE ) {
                        insertPosition = n;
                        toRemoveFirst = n + 1;
                        toRemoveLast = calculateLastPosition( model, n ) + 1;
                        break;
                    }
                }
            }

            if ( null != insertPosition ) {
                String componentName = MappingRegistry.instance().getMetaByClass( extension.getExtensionClass() ).getName();

                model.insert( insertPosition, modelFactory.createStandaloneElementTag( "ui:component",
                        Map.of(
                                "id", componentName,
                                "handler", componentName
                        ),
                        AttributeValueQuotes.DOUBLE, false, true ) );

                if ( null != toRemoveFirst && null != toRemoveLast ) {
                    while ( toRemoveLast >= toRemoveFirst ) {
                        model.remove( toRemoveLast );
                        toRemoveLast--;
                    }
                }
            }
        }

        Map<String, String> attributeMap = ( ( IOpenElementTag ) model.get( 0 ) ).getAttributeMap();
        attributeMap.remove( ATTR_NAME );

        IOpenElementTag tagOpen = modelFactory
                .createOpenElementTag( ( ( IOpenElementTag ) model.get( 0 ) ).getElementCompleteName(), attributeMap,
                        AttributeValueQuotes.DOUBLE,
                        false );

        model.replace(0, tagOpen);
        model.replace( model.size() - 1, modelFactory.createCloseElementTag( ( ( IOpenElementTag ) model.get( 0 ) ).getElementCompleteName() ) );
    }

    private Integer calculateLastPosition( IModel model, int currentPosition ) {
        ITemplateEvent event = model.get( currentPosition );

        if ( event instanceof IOpenElementTag tag ) {
            int openTags = 0;
            int closeTags = 0;
            while ( currentPosition <= model.size() ) {
                if ( model.get( currentPosition ) instanceof IOpenElementTag openTag
                        && openTag.getElementCompleteName().equals( tag.getElementCompleteName() ) )
                    openTags++;

                if ( model.get( currentPosition ) instanceof ICloseElementTag closeTag
                        && closeTag.getElementCompleteName().equals( tag.getElementCompleteName() ) )
                    closeTags++;

                if ( openTags == closeTags ) return currentPosition;

                currentPosition++;
            }
        } else if ( event instanceof IStandaloneElementTag ) {
            return currentPosition;
        }

        return null;
    }
}
