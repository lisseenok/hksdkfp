package ru.adaptms.quickui.handler.meta;

import lombok.Getter;
import ru.adaptms.quickui.annotation.ext.ActionType;
import ru.adaptms.quickui.annotation.ext.Extension;
import ru.adaptms.quickui.annotation.ext.TargetType;
import ru.adaptms.quickui.handler.AbstractUIHandler;

import java.io.Serializable;

/**
 * @author ppolyakov at 17.04.2022 16:14
 */
public class HandlerExtensionMeta implements Serializable {

    @Getter private final Class<? extends AbstractUIHandler> extensionClass;
    @Getter private final Class<? extends AbstractUIHandler> handlerClass;
    @Getter private final ActionType actionType;
    @Getter private final TargetType targetType;
    @Getter private final String targetAttrValue;
    @Getter private final int priority;

    public HandlerExtensionMeta( Class<? extends AbstractUIHandler> handlerClass ) {
        if ( !handlerClass.isAnnotationPresent( Extension.class ) )
            throw new IllegalArgumentException( "Handler class \"" + handlerClass.getCanonicalName() + "\" is not an extension (no @Extension annotation available)." );

        Extension annotation = handlerClass.getAnnotation( Extension.class );
        this.extensionClass = handlerClass;
        this.handlerClass = annotation.handler();
        this.actionType = annotation.action();
        this.targetType = annotation.target().type();
        this.targetAttrValue = annotation.target().value();
        this.priority = annotation.priority();
    }
}
