package ru.adaptms.quickui.registry.xml;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author ppolyakov at 11.04.2022 14:33
 */
@XmlRootElement( name = "handlers" )
public class HandlersNode {

    @XmlElement( name = "handler" )
    public List<HandlerNode> handlers;

}
