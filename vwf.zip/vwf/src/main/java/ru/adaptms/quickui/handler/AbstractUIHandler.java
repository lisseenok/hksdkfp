package ru.adaptms.quickui.handler;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.ui.Model;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.quickui.util.HandlerSupport;
import ru.adaptms.vwf.ui.action.ActionResult;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.ui.util.uri.RedirectBuilder;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;
import ru.adaptms.vwf.util.RandomUtils;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.Serializable;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Standard parent for all resolvable QuickUI component handlers. Extend this in your component class for it to be resolvable
 * by the engine. If you do not need to create mapping for your handler (e.g. it is an embeddable reusable component) - mark
 * your class with @Ignore annotation. Handler marked as such will still work as a child but will not have its own mapping.
 *
 * @author ppolyakov at 21.02.2022 03:30
 */
public abstract class AbstractUIHandler implements Serializable {
    public static final String LISTENER = "l"; // prefix for parameters ignored in page mapping
    public static final String LISTENER_PREFIX = LISTENER + "_";
    public static final String PARAM_ACTION = LISTENER_PREFIX + "action"; // for actions
    public static final String PARAM_DS = LISTENER_PREFIX + "ds"; // for select autocompletes
    public static final String PARAM_FORM = LISTENER_PREFIX + "form"; // for form submissions
    public static final String PARAM_FRAME = LISTENER_PREFIX + "frame"; // for frame selection
    public static final String CONTENT_FRAME = "content_frame"; // default main frame
    public static final String HANDLER_VARIABLE = "handler"; // default handler context variable name

    @Getter
    private final HandlerMeta meta = MappingRegistry.instance().getMetaByClass(this.getClass());
    private Object redirectState = null;

    @Getter
    @Setter
    private boolean isActivated = false; // was onActivation called already
    @Setter
    private String handlerId = RandomUtils.instance().randomString(12); // todo maybe replace with UUID?

    @Getter(AccessLevel.PROTECTED)
    private HandlerSupport support = new HandlerSupport(this); // support functions for this handler
    @Getter
    private Date lastAction = new Date(); // when last action was performed. Needed for destruction countdown
    @Getter
    private boolean forDestruction = false; // is the handler marked for destruction

    @Setter
    private HttpServletRequest request; // incoming HTTP request
    @Setter
    private HttpServletResponse response; // prepared HTTP response

    @Setter
    private Model model; // model for page or fragment rendering
    @Setter
    private Map<String, String> parameters = new HashMap<>(); // parameters that came in query
    @Getter
    private Map<String, Map<String, Object>> listenerParams = new HashMap<>();

    @Getter
    @Setter
    private Map<String, AbstractUIHandler> children = new HashMap<>(); // child handlers for embedded components
    @Getter
    @Setter
    private AbstractUIHandler parent; // only for embedded components - parent

    /**
     * Lifecycle event: fired when handler is first instantiated.
     */
    public void onActivation() {
    }

    /**
     * Lifecycle event: fired when handler is rendering (page refresh or frame loads)
     */
    public void onRefresh() {
    }

    /**
     * Lifecycle event: fired when page is being destroyed
     */
    public void onDestruction() {
    }

    /**
     * Lifecycle event: fired when child component has fired an event. May add something to its result
     *
     * @param result ActionResult from child handler
     */
    public void onChildEventFired(ActionResult result) {
    }

    protected HttpServletRequest getRequest() {
        if (null != getParent())
            return getParent().getRequest();
        return request;
    }

    protected HttpServletResponse getResponse() {
        if (null != getParent())
            return getParent().getResponse();
        return response;
    }

    protected Model getModel() {
        if (null != getParent())
            return getParent().getModel();
        return model;
    }

    /**
     * Returns local message from I18n.xml
     *
     * @param code message code
     * @return resolved message for current locale
     */
    public String getMessage(String code) {
        if (!meta.getMessages().containsKey(code)) return "??" + code + "??";
        return I18NService.instance().decideLocale(meta.getMessages().get(code));
    }

    public String getMessage(String code, Object... substitutions) {
        return MessageFormat.format(getMessage(code), substitutions);
    }

    /**
     * Gets handler id chain (if it's a child handler all layers of parents' ids will be added)
     *
     * @return id or id chain
     */
    public String getHandlerId() {
        if (null != getParent())
            return getParent().getHandlerId() + "-" + handlerId;
        else
            return handlerId;
    }

    /**
     * @return plain id for this handler (ignoring parents)
     */
    public String getThisHandlerId() {
        return handlerId;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    /**
     * Any parameter that has been forwarded to page
     *
     * @param name name of the parameter
     * @return parameter value
     */
    protected String getParameter(String name) {
        return getParameters().get(name);
    }

    /**
     * Listener parameter (which doesn't influence page selection process)
     * Can be obtained via getParameter( "listener_${parameterName}" )
     *
     * @param name name of the parameter
     * @return parameter value
     */
    protected String getListenerParameter(String name) {
        return getParameters().get(LISTENER_PREFIX + name);
    }

    /**
     * Find child handler with given identifier. Traverses through all steps of id which may consist of several layers delimited with '-'
     *
     * @param id child handler identifier (or chain of such identifiers)
     * @return child handler or current handler
     */
    public AbstractUIHandler getChild(String id) {
        String[] idParts = id.split("-");

        if (idParts.length == 1)
            return children.get(id);

        AbstractUIHandler currentHandler = this;
        for (int i = 1; i < idParts.length; i++) {
            currentHandler = currentHandler.getChild(idParts[i]);
        }
        return currentHandler;
    }

    /**
     * Marks handler for destruction after action is complete. Useful for closing modals.
     *
     * @param forDestruction do destroy after action is complete
     */
    public void setForDestruction(boolean forDestruction) {
        this.forDestruction = forDestruction;
    }

    public void updateTimer() {
        this.lastAction = new Date();
    }

    public String getMapping() {
        return getMeta().getMapping();
    }

    public String getName() {
        return getMeta().getName();
    }

    /**
     * Default UriBuilder for the top level handler (the one with resolvable mapping)
     *
     * @param prependContextPath do we need to prepend app context path (usually we do)
     * @return builder
     */
    public UriBuilder getUriBuilder(boolean prependContextPath) {
        // resolve URL of only the top-level component
        AbstractUIHandler handler = this;
        while (handler.getParent() != null) {
            handler = handler.getParent();
        }

        UriBuilder builder = UriBuilder.create(handler.getMeta().getMapping(), prependContextPath);
        Map<String, String> importantParameters = HandlerUtil.getIdentifyingParams(getParameters());
        for (Map.Entry<String, String> entry : importantParameters.entrySet()) {
            builder.parameter(entry.getKey(), entry.getValue());
        }
        return builder;
    }

    /**
     * Path to handler HTML template. By default resolves by the package in which the handler class itself is located.
     *
     * @return path to the HTML template for handler.
     */
    public String getTemplate() {
        return meta.getPath() + "Template";
    }

    /**
     * Sets the half-life period of inactivity for this handler's instance. By default, the instance will be destroyed after 30 minutes of being idle.
     *
     * @return time in minutes
     */
    public int getLifePeriodInMinutes() {
        return (int) AppDefines.get(AppDefines.HANDLER_LIFE);
    }

    /**
     * Redirect user from current page to the one specified
     *
     * @param redirectTo class of handler to be redirected to
     */
    protected void redirect(Class<? extends AbstractUIHandler> redirectTo) {
        redirectState = redirectTo;
    }

    protected void redirect(RedirectBuilder redirectBuilder) {
        redirectState = redirectBuilder;
    }

    /**
     * Redirect user from current page to the one specified
     *
     * @param redirectTo handler object with set parameters to be redirected to
     */
    protected <T extends AbstractUIHandler> void redirect(T redirectTo) {
        redirectState = redirectTo;
    }

    public Object getAndClearRedirectState() {
        // ensure redirect only happens once
        Object toReturn = redirectState;
        redirectState = null;
        return toReturn;
    }

}
