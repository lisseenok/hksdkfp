package ru.adaptms.quickui.thymeleaf.dialect;

import org.thymeleaf.dialect.AbstractDialect;
import org.thymeleaf.dialect.IExpressionObjectDialect;
import org.thymeleaf.expression.IExpressionObjectFactory;
import ru.adaptms.quickui.thymeleaf.expression.UriExpressionFactory;

/**
 * @author ppolyakov at 18.04.2022 09:57
 */
public class ExpressionDialect extends AbstractDialect implements IExpressionObjectDialect {
    private final IExpressionObjectFactory URI_EXPRESSION_OBJECTS_FACTORY = new UriExpressionFactory();

    public ExpressionDialect() {
        super( UriExpressionFactory.TEMPORAL_EVALUATION_VARIABLE_NAME );
    }

    @Override
    public IExpressionObjectFactory getExpressionObjectFactory() {
        return URI_EXPRESSION_OBJECTS_FACTORY;
    }
}
