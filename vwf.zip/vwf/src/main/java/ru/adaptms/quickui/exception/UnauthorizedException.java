package ru.adaptms.quickui.exception;

/**
 * @author ppolyakov at 23.02.2022 19:00
 */
public class UnauthorizedException extends IllegalStateException {
}
