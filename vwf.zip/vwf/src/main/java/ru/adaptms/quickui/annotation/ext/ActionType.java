package ru.adaptms.quickui.annotation.ext;

/**
 * @author ppolyakov at 17.04.2022 15:58
 */
public enum ActionType {
    ADD_BEFORE,
    ADD_AFTER,
    REPLACE
}
