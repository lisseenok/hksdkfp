package ru.adaptms.quickui.controller;

import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;

/**
 * @author ppolyakov at 21.02.2022 21:34
 */
public class RedirectCommand extends IllegalStateException {

    private String pageMapping;

    public RedirectCommand( String pageMapping ) {
        super();
        this.pageMapping = pageMapping;
    }

    public RedirectCommand( Class<? extends AbstractUIHandler> pageClass ) {
        super();
        this.pageMapping = MappingRegistry.instance().getMetaByClass( pageClass ).getMapping();
    }

    public String getPageMapping() {
        return pageMapping;
    }
}
