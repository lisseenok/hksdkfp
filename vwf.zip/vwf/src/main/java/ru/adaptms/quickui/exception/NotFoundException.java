package ru.adaptms.quickui.exception;

/**
 * @author ppolyakov at 23.02.2022 19:00
 */
public class NotFoundException extends IllegalStateException {

    public NotFoundException() {
    }

    public NotFoundException( String s ) {
        super( s );
    }

    public NotFoundException( String message, Throwable cause ) {
        super( message, cause );
    }
}
