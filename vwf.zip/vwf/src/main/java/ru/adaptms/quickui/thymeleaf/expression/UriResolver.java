package ru.adaptms.quickui.thymeleaf.expression;

import ru.adaptms.vwf.ui.util.uri.UriUtil;

/**
 * @author ppolyakov at 18.04.2022 09:54
 */
public class UriResolver {
    public static UriResolver instance() { return new UriResolver(); }

    public String resolve( String input ) {
        return UriUtil.instance().prependContextPath( input );
    }

}
