package ru.adaptms.quickui.thymeleaf.processor;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.i18n.LocaleContextHolder;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.AbstractElementTagProcessor;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.expression.ThymeleafEvaluationContext;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.SpringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * @author ppolyakov at 01.01.2022 21:13
 */
public abstract class AbstractUITagProcessor extends AbstractElementTagProcessor {

    public AbstractUITagProcessor(String dialectPrefix, String elementName, int precedence) {
        super(TemplateMode.HTML,
                dialectPrefix,
                elementName,
                true, null, false,
                precedence);
    }

    @Override
    protected abstract void doProcess(ITemplateContext iTemplateContext,
                                      IProcessableElementTag iProcessableElementTag,
                                      IElementTagStructureHandler iElementTagStructureHandler);

    protected Context getContext() {
        return new Context(LocaleContextHolder.getLocale());
    }

    protected IStandardExpressionParser getParser(ITemplateContext context) {
        final IEngineConfiguration configuration = context.getConfiguration();
        return StandardExpressions.getExpressionParser(configuration);
    }

    protected String getTemplate(Context ctx) {
        return getTemplate(ctx, null);
    }

    protected String getTemplate(Context ctx, String fragment) {
        String path = this.getClass().getCanonicalName().replaceAll("\\.", "/");
        path = path.replace(this.getClass().getSimpleName(), this.getClass().getSimpleName().replace("Processor", ""));
        return getTemplate(ctx, fragment, path);
    }

    protected String getTemplate(Context ctx, String fragment, String templatePath) {
        SpringTemplateEngine ste = (SpringTemplateEngine) SpringUtils.getBeanByName("templateEngine");
        ctx.setVariable(ThymeleafEvaluationContext.THYMELEAF_EVALUATION_CONTEXT_CONTEXT_VARIABLE_NAME,
                new ThymeleafEvaluationContext(SpringUtils.getApplicationContext(), null));

        return ste.process(templatePath, new HashSet<>(Collections.singletonList(fragment != null ? fragment : "default")), ctx);
    }

    protected void applyBooleanField(Context outgoingContext, IProcessableElementTag elementTag, String attrName, Object ctxResult) {
        applyBooleanField(outgoingContext, elementTag, attrName, attrName, ctxResult);
    }

    protected void applyBooleanField(Context outgoingContext, IProcessableElementTag elementTag, String attrName, String targetName, Object ctxResult) {
        if (elementTag.hasAttribute(attrName) && StringUtils.isBlank(elementTag.getAttributeValue(attrName))) {
            outgoingContext.setVariable(targetName, true);
        } else if (ctxResult instanceof String) {
            String disabledStr = (String) ctxResult;
            outgoingContext.setVariable(targetName, attrName.equals(disabledStr) || "true".equals(disabledStr));
        } else if (ctxResult instanceof Boolean) {
            Boolean ctxResultBool = (Boolean) ctxResult;
            outgoingContext.setVariable(targetName, ctxResultBool);
        } else {
            outgoingContext.setVariable(targetName, false);
        }
    }

    protected boolean requireAttributes(IProcessableElementTag tag, IElementTagStructureHandler structureHandler, String... requiredAttrs) {
        List<String> nonPresentRequiredAttrs = null;

        if (requiredAttrs != null) {
            for (String requiredAttr : requiredAttrs) {
                if (!tag.hasAttribute(requiredAttr)) {
                    if (nonPresentRequiredAttrs == null) nonPresentRequiredAttrs = new ArrayList<>();
                    nonPresentRequiredAttrs.add(requiredAttr);
                }
            }
        }

        if (nonPresentRequiredAttrs != null && !nonPresentRequiredAttrs.isEmpty()) {
            String missing = "«" + String.join("», «", nonPresentRequiredAttrs) + "»";
            structureHandler.replaceWith(
                    "<div style=\"border: 1px solid #8b0000; padding: 5px; background-color: #ffd5d5; color: #8b0000\">Couldn't render tag "
                            + tag.toString().replace("<", "&lt;").replace(">", "&gt;")
                            + ". Missing required attribute(s): " + missing + ".",
                    false);
            LoggingUtil.error(AbstractUITagProcessor.class, "Tag \"" + tag + "\" doesn't have required attributes: " + missing);
            return false;
        }

        return true;
    }
}
