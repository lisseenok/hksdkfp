package ru.adaptms.quickui.handler.page;

import ru.adaptms.quickui.handler.AbstractUIHandler;

/**
 * @author ppolyakov at 23.02.2022 19:18
 */
public abstract class NotFoundPage extends AbstractUIHandler {
}
