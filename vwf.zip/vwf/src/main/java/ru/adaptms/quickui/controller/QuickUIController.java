package ru.adaptms.quickui.controller;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.UrlPathHelper;
import ru.adaptms.quickui.annotation.Authenticate;
import ru.adaptms.quickui.context.SessionState;
import ru.adaptms.quickui.exception.NotFoundException;
import ru.adaptms.quickui.exception.UnauthorizedException;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.page.ExceptionPage;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.quickui.security.QuickUISecurityManager;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.quickui.util.QuickUIControllerSupport;
import ru.adaptms.vwf.ui.action.ActionResult;
import ru.adaptms.vwf.ui.action.success.SuccessNotify;
import ru.adaptms.vwf.ui.controller.AbstractController;
import ru.adaptms.vwf.ui.form.FormData;
import ru.adaptms.vwf.ui.form.SubmissionResult;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.search.SearchFilter;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.ui.util.uri.RedirectBuilder;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.RequestUtils;

import javax.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

/**
 * @author ppolyakov at 21.02.2022 04:28
 */
@Hidden
@Controller("quickui_controller")
@RequiredArgsConstructor
public class QuickUIController extends AbstractController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    protected UrlPathHelper urlPathHelper = new UrlPathHelper();

    private final QuickUIControllerSupport support;
    private final MappingRegistry mappingRegistry;

    @GetMapping(value = {"/", "/{_:^(?!(?:static|api|ws).*).*}/**"})
    public String getPage(HttpServletRequest request,
                          HttpServletResponse response,
                          @RequestParam Map<String, String> parameters,
                          Model model) throws Exception {
        try {
            return processHandler(findMappedHandler(request, parameters, true), request, response, parameters, model);
        } catch (RedirectCommand rc) {
            var redirectTo = rc.getPageMapping();

            return "redirect:" + (redirectTo.startsWith("/") ? redirectTo : "/" + redirectTo);
        } catch (UnauthorizedException ue) {
            response.setStatus(403);
            return processHandler(mappingRegistry.getUnauthorizedPage().getConstructor().newInstance(), request, response, parameters, model);
        } catch (NotFoundException nfe) {
            response.setStatus(404);
            return processHandler(mappingRegistry.getNotFoundPage().getConstructor().newInstance(), request, response, parameters, model);
        } catch (Exception e) {
                response.setStatus(500);
            LoggingUtil.exception("Handler for mapping: \"" + resolvePureMapping(request, parameters) + "\"", e);
            LoggingUtil.debug(QuickUIController.class, "Error while executing GET on handler (mapping: \"" + resolvePureMapping(request, parameters) + "\")", e);
            AbstractUIHandler handler = mappingRegistry.getExceptionPage().getConstructor().newInstance();
            String exceptionId = UUID.randomUUID().toString();
            request.setAttribute(ExceptionPage.EXCEPTION_PARAM, e);
            parameters.put(ExceptionPage.EXCEPTION_ID, exceptionId);
            SessionState.instance().addPageToSession(AppDefines.get(AppDefines.EXCEPTION_PAGE_MAPPING) + "?quickui_exception_id=" + exceptionId, handler);
            return processHandler(handler, request, response, parameters, model);
        }
    }

    // todo проверять на конкурентные изменения? с помощью lastAction
    @PatchMapping(value = {"/", "/{_:^(?!(?:static|api|ws).*).*}/**"}, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ActionResult performPatchAction(HttpServletRequest request,
                                           HttpServletResponse response,
                                           @RequestParam Map<String, String> parameters) throws Exception {
        AbstractUIHandler handler = findMappedHandler(request, parameters, false);
        if (handler == null)
            return new ActionResult(notify(I18NService.instance().getMessage("framework.ui.errors.page-expired"), "error"));

        handler.setRequest(request);
        handler.setResponse(response);

        try {
            if (parameters.containsKey(AbstractUIHandler.PARAM_DS)) {
                SearchFilter filter = new SearchFilter(parameters.get(AbstractUIHandler.LISTENER_PREFIX + "filter"),
                        Integer.parseInt(parameters.get(AbstractUIHandler.LISTENER_PREFIX + "page")) - 1);
                return executeAndGetActionResult(handler, parameters.get(AbstractUIHandler.PARAM_DS), parameters, filter);
            } else {
                return executeAndGetActionResult(handler, parameters.get(AbstractUIHandler.PARAM_ACTION), parameters, null);
            }
        } catch (Exception e) {
            LoggingUtil.exception("Handler: \"" + handler.getClass().getCanonicalName() + "\"", e);
            LoggingUtil.debug(QuickUIController.class, "Error while executing PATCH on handler: \"" + handler.getClass().getCanonicalName() + "\")", e);
            SuccessNotify notification = new SuccessNotify(I18NService.instance().getMessage("framework.ui.errors.server"));
            notification.setType("error");
            return new ActionResult(notification);
        }
    }

    @PostMapping(value = {"/", "/{_:^(?!(?:static|api|ws).*).*}/**"},
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public SubmissionResult performPostForm(HttpServletRequest request,
                                            HttpServletResponse response,
                                            @RequestParam Map<String, String> parameters,
                                            @RequestBody FormData data) throws Exception {
        AbstractUIHandler handler = findMappedHandler(request, parameters, false);
        if (handler == null)
            return new SubmissionResult(notify(I18NService.instance().getMessage("framework.ui.errors.page-expired"), "error"));

        handler.setRequest(request);
        handler.setResponse(response);

        try {
            return (SubmissionResult) executeAndGetActionResult(handler, parameters.get(AbstractUIHandler.PARAM_FORM), parameters, data);
        } catch (Exception e) {
            LoggingUtil.exception("Handler: \"" + handler.getClass().getCanonicalName() + "\"", e);
            LoggingUtil.debug(QuickUIController.class, "Error while executing PATCH on handler: \"" + handler.getClass().getCanonicalName() + "\")", e);
            SuccessNotify notification = new SuccessNotify(I18NService.instance().getMessage("framework.ui.errors.server"));
            notification.setType("error");
            return new SubmissionResult(notification);
        }
    }

    private ActionResult executeAndGetActionResult(AbstractUIHandler rootHandler, String methodParameter, Map<String, String> parameters, @Nullable Object data) throws Exception {
        String[] methodParts = methodParameter.split("\\.");
        String handlerId = methodParts[0];
        ActionResult result;

        if (rootHandler.getHandlerId().equals(handlerId)) {
            rootHandler.getParameters().clear();
            rootHandler.getParameters().putAll(parameters);
            result = executeActionOnHandler(rootHandler, methodParts[1], data);
        } else {
            AbstractUIHandler childHandler = rootHandler.getChild(handlerId);
            childHandler.getParameters().clear();
            childHandler.getParameters().putAll(parameters);
            result = executeActionOnHandler(childHandler, methodParts[1], data);

            // trigger child events up-state (all the way)
            var currentHandler = childHandler.getParent();
            while (currentHandler != null) {
                currentHandler.onChildEventFired(result);
                currentHandler = currentHandler.getParent();
            }
        }

        return result;
    }

    private ActionResult executeActionOnHandler(AbstractUIHandler handler, String methodName, @Nullable Object data) throws Exception {
        Method methodToExecute = data != null ? handler.getClass().getDeclaredMethod(methodName, data.getClass()) : handler.getClass().getDeclaredMethod(methodName);

        if (methodToExecute.isAnnotationPresent(Authenticate.class)
                && !QuickUISecurityManager.instance().isAllowed(methodToExecute.getAnnotation(Authenticate.class).value())) {
            throw new UnauthorizedException();
        }

        ActionResult result = data != null ? (ActionResult) methodToExecute.invoke(handler, data) : (ActionResult) methodToExecute.invoke(handler);

        handler.updateTimer();
        return result;
    }

    private String processHandler(AbstractUIHandler handler,
                                  HttpServletRequest request, HttpServletResponse response,
                                  Map<String, String> parameters, Model model) throws Exception {
        handler.setRequest(request);
        handler.setResponse(response);
        handler.setModel(model);
        handler.setParameters(parameters);

        HandlerUtil.setParameters(handler, Map.copyOf(new HashMap<>(parameters)), true);

        String frame = parameters.get(AbstractUIHandler.PARAM_FRAME);
        if (!StringUtils.isBlank(frame)) {
            String[] frameParts = frame.split("\\.");
            frame = frameParts[1];

            if (!handler.getHandlerId().equals(frameParts[0])) {
                handler = handler.getChild(frameParts[0]);
            }
        } else {
            frame = "content_frame";
        }

        if (!handler.isActivated()) {
            handler.onActivation();
            handler.setActivated(true);
        }

        handler.updateTimer();
        handler.onRefresh();

        // redirect if required
        Object redirectState = handler.getAndClearRedirectState();
        if (redirectState != null) {
            if (redirectState instanceof Class<?> handlerClass) {
                throw new RedirectCommand((Class<? extends AbstractUIHandler>) handlerClass);
            } else if (redirectState instanceof RedirectBuilder redirectBuilder) {
                throw new RedirectCommand(redirectBuilder.build());
            } else {
                throw new RedirectCommand(((AbstractUIHandler) redirectState).getUriBuilder(false).build());
            }
        }

        model.addAttribute(AbstractUIHandler.HANDLER_VARIABLE, handler);

        if (RequestUtils.isXHR(request)) {
            return handler.getTemplate() + " :: #" + frame;
        } else {
            return handler.getTemplate();
        }
    }

    /**
     * Find (or create) appropriate UI handler for given mapping. Evaluates path as well as query parameters to
     * determine which instance of handler class to supply or create.
     *
     * @param request HTTP request
     * @param parameters map of incoming query params (singular)
     * @param doInitialize whether to create new instance if appropriate one wasn't found
     * @return found instance of UI handler
     * @throws InvocationTargetException if unable to inject dependencies into the constructor of handler class
     * @throws InstantiationException if unable to create an instance of handler class
     * @throws IllegalAccessException
     */
    private AbstractUIHandler findMappedHandler(HttpServletRequest request, Map<String, String> parameters, boolean doInitialize) throws InvocationTargetException, InstantiationException, IllegalAccessException {
        String mapping = resolvePureMapping(request, parameters); // remove unnecessary parameters (marked as "l_" - from listeners)

        // load existing instance of handler from user's session
        AbstractUIHandler handler = SessionState.instance().getPageFromSession(mapping);

        // if no such handler exists OR found handler is already going to be destroyed - create new instance (if allowed)
        if ((handler == null || handler.isForDestruction()) && doInitialize) {
            // find appropriate meta by mapping
            var meta = mappingRegistry.getMetaByMapping(mapping.split("\\?")[0]);
            if (meta == null)
                throw new NotFoundException(); // not found - throw an expected exception instead of an NPE

            // get handler class from found meta
            Class<? extends AbstractUIHandler> handlerClass = meta.getHandlerClass();
            if (handlerClass == null)
                throw new NotFoundException(); // highly unlikely that meta doesn't know its class, but keeping this for now

            // check access to this page
            if (handlerClass.isAnnotationPresent(Authenticate.class)
                    && !QuickUISecurityManager.instance().isAllowed(handlerClass.getAnnotation(Authenticate.class).value())) {
                throw new UnauthorizedException(); // throw an expected exception if not allowed to open
            }

            // dependency injection
            handler = support.injectDependencies(handlerClass);

            SessionState.instance().addPageToSession(mapping, handler); // add to user's session
        }

        return handler;
    }

    /**
     * Remove all parameters from query path that are not important for instance resolution
     * Using this method prevents mix-up because of variable listener parameters
     * @param request HTTP request
     * @param parameters all parameters of request
     * @return stringified mapping without unnecessary params
     */
    private String resolvePureMapping(HttpServletRequest request, Map<String, String> parameters) {
        Map<String, String> parametersCopy = HandlerUtil.getIdentifyingParams(parameters);

        String mapping = urlPathHelper.getPathWithinApplication(request);

        if (parametersCopy != null && !parametersCopy.isEmpty()) {
            // sort parameters
            Map<String, String> sortedParameters = new TreeMap<>(parametersCopy);

            mapping += "?";
            List<String> paramList = new ArrayList<>();
            for (Map.Entry<String, String> entry : sortedParameters.entrySet()) {
                paramList.add(entry.getKey() + "=" + entry.getValue());
            }

            mapping += String.join("&", paramList);
        }

        if (mapping.startsWith("/"))
            mapping = mapping.substring(1);

        return mapping;
    }

}
