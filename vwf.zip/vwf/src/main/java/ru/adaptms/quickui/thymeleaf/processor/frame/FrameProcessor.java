package ru.adaptms.quickui.thymeleaf.processor.frame;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.AttributeValueQuotes;
import org.thymeleaf.model.IModel;
import org.thymeleaf.model.IModelFactory;
import org.thymeleaf.model.IOpenElementTag;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;

import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class FrameProcessor extends AbstractElementModelProcessor {

    private static final String ELEMENT_NAME = "frame";
    private static final int PRECEDENCE = 100;

    public FrameProcessor(final String dialectPrefix) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                true,
                null,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess(ITemplateContext context,
                             IModel model,
                             IElementModelStructureHandler structureHandler) {
        final IModelFactory modelFactory = context.getModelFactory();
        final var configuration = context.getConfiguration();
        final var parser = StandardExpressions.getExpressionParser(configuration);

        AbstractUIHandler handler = (AbstractUIHandler) context.getVariable(AbstractUIHandler.HANDLER_VARIABLE);

        Map<String, String> attributeMap = ((IOpenElementTag) model.get(0)).getAttributeMap();
        attributeMap.put("id", attributeMap.get("id") + "_" + handler.getHandlerId());

        if (attributeMap.containsKey("class")) {
            attributeMap.put("class", attributeMap.get("class") + " is_qui_frame");
        } else {
            attributeMap.put("class", "is_qui_frame");
        }

        if (AppDefines.isDebug()) {
            attributeMap.put("data-debug-handler", handler.getClass().getCanonicalName());
            attributeMap.put("data-debug-handler-id", handler.getThisHandlerId());
        }

        // todo this is unused?
        if (attributeMap.containsKey("autoRefresh")) {
            attributeMap.put("data-vwf-autorefresh", attributeMap.get("autoRefresh"));
            attributeMap.put("class", attributeMap.get("class") + " auto_refresh");
            attributeMap.remove("autoRefresh");
        }

        // deferred loading of content
        if (attributeMap.containsKey("deferListener")) {
            String listener = (String) SpringELUtil.execute(attributeMap.get("deferListener"), context, parser);

            if (StringUtils.isNotBlank(listener)) {
                AbstractUIHandler topLevelHandler = handler;
                while (topLevelHandler.getParent() != null) {
                    topLevelHandler = topLevelHandler.getParent();
                }

                UriBuilder action = UriBuilder.create(topLevelHandler.getMeta().getMapping(), true);
                action.parameter(AbstractUIHandler.PARAM_ACTION, handler.getHandlerId() + "." + listener);

                Map<String, String> importantParameters = HandlerUtil.getIdentifyingParams(topLevelHandler.getParameters());
                for (Map.Entry<String, String> entry : importantParameters.entrySet()) {
                    action.parameter(entry.getKey(), entry.getValue());
                }

                ProcessorHelper.applyParams(action, attributeMap, context, parser, null);

                attributeMap.put("data-vwf-defer", action.build());
                attributeMap.put("class", attributeMap.get("class") + " qui_deferred_frame");
            }

            attributeMap.remove("deferListener");
        }

        IOpenElementTag tagOpen = modelFactory
                .createOpenElementTag("div", attributeMap,
                        AttributeValueQuotes.DOUBLE,
                        false);

        model.replace(0, tagOpen);
        model.replace(model.size() - 1, modelFactory.createCloseElementTag("div"));
    }
}
