package ru.adaptms.quickui.thymeleaf.resolver;

import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.templateresolver.AbstractConfigurableTemplateResolver;
import org.thymeleaf.templateresource.ITemplateResource;
import org.thymeleaf.templateresource.StringTemplateResource;

import java.util.HashMap;
import java.util.Map;

/**
 * @author polyakov_ps at 30.09.2023 1:21
 */
public class InMemoryStringTemplateResolver extends AbstractConfigurableTemplateResolver {
    private Map<String, String> TEMPLATES = new HashMap<>();

    @Override
    protected ITemplateResource computeTemplateResource(IEngineConfiguration configuration,
                                                        String ownerTemplate,
                                                        String template, String resourceName, String characterEncoding,
                                                        Map<String, Object> templateResolutionAttributes) {
        return new StringTemplateResource(TEMPLATES.get(template));
    }

    /**
     * Add a template to in-memory cache. Automatically prepends "in-memory:" to code (if not starts with it already)
     *
     * @param code unique template code
     * @param template template string
     * @return true if added, false if template with this code already exists
     */
    public boolean add(String code, String template) {
        if (!code.startsWith("in-memory:"))
            code = "in-memory:" + code;

        if (TEMPLATES.containsKey(code))
            return false;

        TEMPLATES.put(code, template);
        return true;
    }
}
