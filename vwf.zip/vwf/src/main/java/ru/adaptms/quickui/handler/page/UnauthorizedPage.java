package ru.adaptms.quickui.handler.page;

import ru.adaptms.quickui.handler.AbstractUIHandler;

/**
 * @author ppolyakov at 23.02.2022 19:17
 */
public abstract class UnauthorizedPage extends AbstractUIHandler {
}
