package ru.adaptms.quickui.annotation.ext;

/**
 * @author ppolyakov at 17.04.2022 15:58
 */
public enum TargetType {
    EXT_ID( "ext-id" ),
    ID( "id" );

    private final String attrName;

    TargetType( String attrName ) {
        this.attrName = attrName;
    }

    public String getAttrName() {
        return attrName;
    }
}
