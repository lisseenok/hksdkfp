package ru.adaptms.quickui.thymeleaf.dialect;

import org.thymeleaf.processor.IProcessor;
import ru.adaptms.quickui.thymeleaf.processor.component.ComponentProcessor;
import ru.adaptms.quickui.thymeleaf.processor.frame.FrameProcessor;
import ru.adaptms.vwf.ui.thymeleaf.dialect.AbstractUIDialect;

import java.util.HashSet;
import java.util.Set;

/**
 * @author ppolyakov at 27.03.2022 15:35
 */
public class QuickUIDialect extends AbstractUIDialect {

    private static final String PROCESSOR_NAME = "QuickUI dialect";
    private static final String DIALECT_PREFIX = "quick";
    private static final int PRECEDENCE = 1200;

    public QuickUIDialect() {
        super( PROCESSOR_NAME, DIALECT_PREFIX, PRECEDENCE );
    }

    @Override
    public Set<IProcessor> getProcessors( final String dialectPrefix ) {
        final Set<IProcessor> processors = new HashSet<>();

        processors.add( new FrameProcessor( dialectPrefix ) );
        processors.add( new ComponentProcessor( dialectPrefix ) );

        return processors;
    }
}
