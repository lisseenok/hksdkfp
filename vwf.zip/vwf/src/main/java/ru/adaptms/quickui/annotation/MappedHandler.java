package ru.adaptms.quickui.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author ppolyakov at 21.02.2022 04:16
 */
@Retention( RetentionPolicy.RUNTIME)
@Target( ElementType.TYPE )
public @interface MappedHandler {
    String mapping() default "#_generate_#";
}
