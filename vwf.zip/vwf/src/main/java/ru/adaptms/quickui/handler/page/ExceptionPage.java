package ru.adaptms.quickui.handler.page;

import ru.adaptms.quickui.handler.AbstractUIHandler;

/**
 * @author ppolyakov at 23.02.2022 19:21
 */
public abstract class ExceptionPage extends AbstractUIHandler {
    public static final String EXCEPTION_PARAM = "quickui_exception_param";
    public static final String EXCEPTION_ID = "quickui_exception_id";
}
