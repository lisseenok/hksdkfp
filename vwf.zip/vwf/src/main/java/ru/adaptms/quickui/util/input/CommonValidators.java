package ru.adaptms.quickui.util.input;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.routines.EmailValidator;
import ru.adaptms.vwf.ui.form.AsyncFile;
import ru.adaptms.vwf.util.FormattingUtil;

import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @author ppolyakov at 26.05.2022 14:30
 */
public interface CommonValidators {

    static boolean required( List<String> input ) {
        return input != null && !input.isEmpty() && input.stream().noneMatch( StringUtils::isBlank );
    }

    static boolean minValues( List<String> input, int min ) {
        return required( input ) && input.size() >= min;
    }

    static boolean maxValues( List<String> input, int max ) {
        return required( input ) && input.size() <= max;
    }

    static boolean valuesRange( List<String> input, int min, int max ) {
        return required( input ) && input.size() >= min && input.size() <= max;
    }

    static boolean requiredFile( List<AsyncFile> input ) {
        return input != null && !input.isEmpty() && input.stream().noneMatch( Objects::isNull );
    }

    static boolean minValuesFile( List<AsyncFile> input, int min ) {
        return requiredFile( input ) && input.size() >= min;
    }

    static boolean maxValuesFile( List<AsyncFile> input, int max ) {
        return requiredFile( input ) && input.size() <= max;
    }

    static boolean valuesRangeFile( List<AsyncFile> input, int min, int max ) {
        return requiredFile( input ) && input.size() >= min && input.size() <= max;
    }

    static boolean regex( List<String> input, String regex ) {
        if ( !required( input ) ) return true;

        Pattern pattern = Pattern.compile( regex );
        for ( String s : input )
            if ( !pattern.matcher( s ).matches() ) return false;

        return true;
    }

    static boolean minLength( List<String> input, int minLength ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( s.length() < minLength ) return false;

        return true;
    }

    static boolean maxLength( List<String> input, int maxLength ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( s.length() > maxLength ) return false;

        return true;
    }

    static boolean lengthRange( List<String> input, int minLength, int maxLength ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( s.length() < minLength || s.length() > maxLength ) return false;

        return true;
    }

    static boolean email( List<String> input ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( !EmailValidator.getInstance().isValid( s ) ) return false;

        return true;
    }

    static boolean number( List<String> input ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( !NumberUtils.isParsable( s ) ) return false;

        return true;
    }

    static boolean min( List<String> input, double min ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            double value = NumberUtils.toDouble( s );
            if ( value <  min ) return false;
        }

        return true;
    }

    static boolean max( List<String> input, double max ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            double value = NumberUtils.toDouble( s );
            if ( value > max ) return false;
        }

        return true;
    }

    static boolean range( List<String> input, double min, double max ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            double value = NumberUtils.toDouble( s );
            if ( value < min || value > max ) return false;
        }

        return true;
    }

    /** #.## */
    static boolean numberFormat( List<String> input, String format ) {
        DecimalFormat df = new DecimalFormat( format );

        for ( String s : input ) {
            double value = NumberUtils.toDouble( s );
            if ( !s.equals( df.format( value ) ) ) return false;
        }

        return true;
    }

    static boolean date( List<String> input ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( !GenericValidator.isDate( s, "dd.MM.yyyy", true ) ) return false;

        return true;
    }

    static boolean time( List<String> input ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( !GenericValidator.isDate( s, "HH:mm", true ) ) return false;

        return true;
    }

    static boolean dateTime( List<String> input ) {
        if ( !required( input ) ) return true;

        for ( String s : input )
            if ( !GenericValidator.isDate( s, "dd.MM.yyyy HH:mm", true ) ) return false;

        return true;
    }

    static boolean before( List<String> input, Date threshold ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            Date date = FormattingUtil.instance().stringToDate( s, "HH:mm" );
            if ( date != null && date.after( threshold ) ) return false;
        }

        return true;
    }

    static boolean after( List<String> input, Date threshold ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            Date date = FormattingUtil.instance().stringToDate( s, "HH:mm" );
            if ( date != null && date.before( threshold ) ) return false;
        }

        return true;
    }

    static boolean dateRange( List<String> input, Date rangeStart, Date rangeEnd ) {
        if ( !required( input ) ) return true;

        for ( String s : input ) {
            Date date = FormattingUtil.instance().stringToDate( s, "HH:mm" );
            if ( date != null && ( date.before( rangeStart ) || date.after( rangeEnd ) ) ) return false;
        }

        return true;
    }

    static boolean fileExtension( List<AsyncFile> input, String... extensions ) {
        if ( !requiredFile( input ) ) return true;

        Pattern pattern = Pattern.compile( ".*(\\." + Arrays.stream( extensions ).map( e -> e.toLowerCase( Locale.ROOT ) ).collect( Collectors.joining( "|\\." )) + ")$" );

        for ( AsyncFile file : input )
            if ( !pattern.matcher( file.getFileName().toLowerCase( Locale.ROOT ) ).matches() ) return false;

        return true;
    }

    static boolean fileSize( List<AsyncFile> input, int maxSizeInBytes ) {
        if ( !requiredFile( input ) ) return true;

        for ( AsyncFile file : input )
            if ( file.getContentAsBytes().length > maxSizeInBytes ) return false;

        return true;
    }

    static String[] fileSizeUnitKeys() {
        return new String[]{
                "framework.ui.validation.file.units.b",
                "framework.ui.validation.file.units.kb",
                "framework.ui.validation.file.units.mb",
                "framework.ui.validation.file.units.gb",
                "framework.ui.validation.file.units.tb"
        };
    }
}
