package ru.adaptms.quickui.registry.xml;

import jakarta.xml.bind.annotation.XmlAttribute;

/**
 * @author ppolyakov at 11.04.2022 14:34
 */
public class HandlerNode {

    @XmlAttribute( name = "class", required = true )
    public String handlerClass;

    @XmlAttribute( required = true )
    public String name;

}
