package ru.adaptms.quickui.thymeleaf.processor.component;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.quickui.util.QuickUIControllerSupport;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class ComponentProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "component";
    private static final int PRECEDENCE = 600;

    public ComponentProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    public ComponentProcessor(String dialectPrefix, String elementName, int precedence) {
        super(dialectPrefix, elementName, precedence);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        processInternal(incomingContext, elementTag, structureHandler, null);
    }

    protected void processInternal(ITemplateContext incomingContext,
                                   IProcessableElementTag elementTag,
                                   IElementTagStructureHandler structureHandler,
                                   String handlerName) {
        if (!requireAttributes(elementTag, structureHandler, "id")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        AbstractUIHandler handler = (AbstractUIHandler) incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE);

        String id = (String) SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser);

        AbstractUIHandler component = handler.getChild(id);
        if (null == component) {
            if (StringUtils.isBlank(handlerName)) handlerName = elementTag.getAttributeValue("handler");

            Class<? extends AbstractUIHandler> componentClass = MappingRegistry.instance().getMetaByName(handlerName).getHandlerClass();

            try {
                component = QuickUIControllerSupport.instance().injectDependencies(componentClass);
                component.setParent(handler);
                component.setHandlerId(id);
                handler.getChildren().put(id, component);
            } catch (Exception e) {
                throw new IllegalStateException("Component initialization failed. Handler: " + handler.getName()
                        + ", component ID: " + id, e);
            }
        }

        if (elementTag.hasAttribute("params")
                || elementTag.getAttributeMap().keySet().stream().anyMatch(k -> k.startsWith("p:"))) {
            var params = ProcessorHelper.getParameterMap(elementTag.getAttributeMap(), incomingContext, parser);
            HandlerUtil.setParameters(component, params, false);
        }

        if (!component.isActivated()) {
            component.onActivation();
            component.setActivated(true);
        }

        component.onRefresh();

        outgoingContext.setVariable(AbstractUIHandler.HANDLER_VARIABLE, component);

        String path = component.getClass().getCanonicalName()
                .replaceAll("\\.", "/")
                .replace(component.getClass().getSimpleName(), "Template");
        structureHandler.replaceWith(getTemplate(outgoingContext, "#" + AbstractUIHandler.CONTENT_FRAME, path), false);
    }
}
