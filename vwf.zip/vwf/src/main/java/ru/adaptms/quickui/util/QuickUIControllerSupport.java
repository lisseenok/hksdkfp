package ru.adaptms.quickui.util;

import org.springframework.stereotype.Service;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.vwf.util.SpringUtils;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * @author polyakov_ps at 13.04.2023 15:30
 */
@Service
public class QuickUIControllerSupport {
    public static QuickUIControllerSupport instance() { return SpringUtils.getInstance( QuickUIControllerSupport.class ); }

    public AbstractUIHandler injectDependencies(Class<? extends AbstractUIHandler> handlerClass)
            throws InvocationTargetException, InstantiationException, IllegalAccessException {
        Constructor<? extends AbstractUIHandler>[] constructors =
                (Constructor<? extends AbstractUIHandler>[]) handlerClass.getConstructors();
        Constructor<? extends AbstractUIHandler> constructor = null;
        if (constructors.length == 1)
            constructor = constructors[0];
        else
            // pick constructor with most parameters
            constructor = Arrays.stream(constructors)
                    .sorted(Comparator.comparing(c -> c.getParameterTypes().length, Comparator.reverseOrder()))
                    .findFirst().get();

        if (constructor.getParameterTypes().length == 0) {
            return constructor.newInstance();
        } else {
            List<Object> beansToInject = new ArrayList<>();
            for (Class<?> parameterType : constructor.getParameterTypes()) {
                beansToInject.add(SpringUtils.getApplicationContext().getBean(parameterType));
            }
            return constructor.newInstance(beansToInject.toArray());
        }
    }
}
