package ru.adaptms.quickui.context;

import org.apache.commons.lang3.time.DateUtils;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.adaptms.quickui.handler.AbstractUIHandler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Service for monitoring if handler instance has already expired
 *
 * @author ppolyakov at 22.02.2022 14:39
 */
@Service
public class ExpiryMonitoringService {
    private static List<Map<String, AbstractUIHandler>> expiryMonitoring = Collections.synchronizedList(new ArrayList<>());

    /**
     * Add session handler registry
     *
     * @param handlers map with handler registry from SessionState
     */
    public static void add(Map<String, AbstractUIHandler> handlers) {
        expiryMonitoring.add(handlers);
    }

    /**
     * Worker that crawls all instantiated handlers in all session by references given on SessionState instantiation for this session
     */
    @Scheduled(fixedDelay = 1000)
    public void checkExpiry() {
        try {
            synchronized (expiryMonitoring) {
                for (Map<String, AbstractUIHandler> stringAbstractUIHandlerMap : expiryMonitoring) {
                    expire(stringAbstractUIHandlerMap);
                }
            }
        } catch (ConcurrentModificationException e) {
            // oh wow
        }
    }

    private void expire(Map<String, AbstractUIHandler> stringAbstractPageMap) {
        for (Map.Entry<String, AbstractUIHandler> page : stringAbstractPageMap.entrySet()) {
            if (page.getValue().isForDestruction()
                || DateUtils.addMinutes(new Date(), -page.getValue().getLifePeriodInMinutes()).after(page.getValue().getLastAction())) {
                page.getValue().onDestruction();
                stringAbstractPageMap.remove(page.getKey());
            }
        }
    }
}
