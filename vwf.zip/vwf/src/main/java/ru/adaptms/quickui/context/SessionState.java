package ru.adaptms.quickui.context;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.vwf.util.SpringUtils;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component( "quickui_state" )
@Scope( value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS )
public class SessionState implements Serializable {

    public static SessionState instance() { return SpringUtils.getInstance( SessionState.class ); }

    private final Map<String, Object> sessionObjects = new HashMap<>();

    private final Map<String, AbstractUIHandler> sessionHandlers = new ConcurrentHashMap<>();

    /**
     * Add this registry to expiry monitoring worker
     */
    @PostConstruct
    public void init() {
        ExpiryMonitoringService.add( sessionHandlers );
    }

    /**
     * When session dies - gracefully destroy all the handlers
     */
    @PreDestroy
    public void destroy() {
        for ( AbstractUIHandler page : sessionHandlers.values() ) {
            page.setForDestruction( true );
        }
    }

    public void addSessionObject( String key, Object value ) {
        if ( sessionObjects.containsKey( key ) )
            throw new IllegalStateException( "Cannot add session object: store already contains key \"" + key + "\". Try addOrUpdateSessionObject() instead." );
        sessionObjects.put( key, value );
    }

    public void addOrUpdateSessionObject( String key, Object value ) {
        sessionObjects.put( key, value );
    }

    public <T> T getSessionObject( String key ) {
        return ( T ) sessionObjects.get( key );
    }

    public <T> T getSessionObject( String key, T orDefault ) {
        return ( T ) sessionObjects.getOrDefault( key, orDefault );
    }

    public void removeSessionObject(String key) {
        sessionObjects.remove(key);
    }

    public AbstractUIHandler getPageFromSession( String mapping ) {
        return sessionHandlers.get( mapping );
    }

    public void addPageToSession( String mapping, AbstractUIHandler page ) {
        sessionHandlers.put( mapping, page );
    }

    public void destroyPage( String mapping ) {
        sessionHandlers.remove( mapping );
    }
}
