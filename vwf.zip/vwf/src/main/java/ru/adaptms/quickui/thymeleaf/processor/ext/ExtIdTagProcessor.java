package ru.adaptms.quickui.thymeleaf.processor.ext;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.annotation.ext.ActionType;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerExtensionMeta;
import ru.adaptms.quickui.registry.MappingRegistry;

import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class ExtIdTagProcessor extends AbstractElementModelProcessor {

    private static final String ATTR_NAME = "ext-id";
    private static final int PRECEDENCE = 100;

    public ExtIdTagProcessor( final String dialectPrefix ) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                null,
                false,
                ATTR_NAME,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess( ITemplateContext context,
                              IModel model,
                              IElementModelStructureHandler structureHandler ) {
        final IModelFactory modelFactory = context.getModelFactory();

        if ( !( model.get( 0 ) instanceof IProcessableElementTag ) ) return;

        Map<String, String> attributeMap = ( ( IProcessableElementTag ) model.get( 0 ) ).getAttributeMap();
        attributeMap.remove( ATTR_NAME );

        IProcessableElementTag replacement = null;
        if ( model.get( 0 ) instanceof IOpenElementTag openTag ) {
            replacement = modelFactory
                    .createOpenElementTag( openTag.getElementCompleteName(), attributeMap,
                            AttributeValueQuotes.DOUBLE,
                            false );
        } else if ( model.get( 0 ) instanceof IStandaloneElementTag standaloneTag ) {
            replacement = modelFactory
                    .createStandaloneElementTag( standaloneTag.getElementCompleteName(), attributeMap,
                            AttributeValueQuotes.DOUBLE,
                            false, true );
        }

        model.replace( 0, replacement );
    }

}
