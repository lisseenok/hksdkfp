package ru.adaptms.quickui.handler.meta;

import java.io.Serializable;
import java.lang.reflect.Method;

/**
 * Static metadata for handler parameter
 *
 * @author ppolyakov at 08.04.2022 22:33
 */
public class HandlerParamMeta implements Serializable {

    private final String name;
    private final int index;
    private final Class<?> paramClass;
    private final Method setter;
    private final boolean required;
    private final String paramCode;

    public HandlerParamMeta( String name, String paramCode, int index, Class<?> paramClass, Method setter, boolean required ) {
        this.name = name;
        this.paramCode = paramCode;
        this.index = index;
        this.paramClass = paramClass;
        this.setter = setter;
        this.required = required;
    }

    public String getName() {
        return name;
    }

    public int getIndex() {
        return index;
    }

    public Class<?> getParamClass() {
        return paramClass;
    }

    public Method getSetter() {
        return setter;
    }

    public boolean isRequired() {
        return required;
    }

    public String getParamCode() {
        return paramCode;
    }
}
