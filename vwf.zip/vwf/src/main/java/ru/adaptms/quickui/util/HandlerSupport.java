package ru.adaptms.quickui.util;

import ru.adaptms.quickui.controller.RedirectCommand;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.vwf.ui.action.ActionResult;
import ru.adaptms.vwf.ui.action.success.*;
import ru.adaptms.vwf.ui.form.AsyncFile;
import ru.adaptms.vwf.ui.form.SubmissionResult;
import ru.adaptms.vwf.ui.search.SearchResult;
import ru.adaptms.vwf.ui.util.uri.RedirectBuilder;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;

import java.io.Serializable;
import java.util.Map;

/**
 * Util methods for current handler to create results.
 * Need to call methods on support for current AbstractUIHandler or IDs will be incorrect.
 *
 * @author ppolyakov at 21.02.2022 17:38
 */
public class HandlerSupport implements Serializable {

    private final AbstractUIHandler handler;

    public HandlerSupport(AbstractUIHandler handler) {
        this.handler = handler;
    }

    /**
     * Hard-core redirects for onActivation and
     *
     * @param mapping
     */
    public void redirectToPage(String mapping) {
        throw new RedirectCommand(mapping);
    }

    public void redirectToPage(Class<? extends AbstractUIHandler> page) {
        throw new RedirectCommand(page);
    }

    /**
     * Action result for returning to client - do nothing (useful for embedded components)
     *
     * @param id action ID for parent handlers
     * @return action result
     */
    public ActionResult actionResult(String id) {
        return actionResult(id, doNothing());
    }

    /**
     * Action result for returning to client
     *
     * @param action first action in chain
     * @return action result
     */
    public ActionResult actionResult(ISuccessAction action) {
        return new ActionResult(action);
    }

    /**
     * Action result for propagation from child component to parent
     *
     * @param id     identifier to find result on onChildEventFired event
     * @param action first action in chain
     * @return action result
     */
    public ActionResult actionResult(String id, ISuccessAction action) {
        ActionResult result = new ActionResult(action);
        result.setId(id);
        return result;
    }

    /**
     * Form submission result for returning to client - do nothing (useful for embedded components)
     *
     * @param id action ID for parent handlers
     * @return submission result
     */
    public SubmissionResult formResult(String id) {
        return formResult(id, doNothing());
    }

    /**
     * Form submission result for returning to client
     *
     * @param action first action in chain
     * @return submission result
     */
    public SubmissionResult formResult(ISuccessAction action) {
        return new SubmissionResult(handler.getHandlerId(), action);
    }

    /**
     * Form submission result for propagation from child component to parent
     *
     * @param id     identifier to find result on onChildEventFired event
     * @param action first action in chain
     * @return submission result
     */
    public SubmissionResult formResult(String id, ISuccessAction action) {
        SubmissionResult result = new SubmissionResult(handler.getHandlerId(), action);
        result.setId(id);
        return result;
    }

    public SearchResult searchResult() {
        return new SearchResult();
    }

    public SearchResult searchResult(String id) {
        SearchResult result = new SearchResult();
        result.setId(id);
        return result;
    }

    /**
     * Reloads root frame for current handler (e.g. for embedded components)
     *
     * @return action result
     */
    public SuccessAjaxLoadFrame reloadFrame() {
        return reloadFrame(AbstractUIHandler.CONTENT_FRAME);
    }

    /**
     * Reloads root frame for current handler (e.g. for embedded components)
     *
     * @param frame ID of frame (&lt;ui:frame id="%frame%"&gt;) to reload
     * @return action result
     */
    public SuccessAjaxLoadFrame reloadFrame(String frame) {
        return new SuccessAjaxLoadFrame(handler.getUriBuilder(false).parameter(AbstractUIHandler.PARAM_FRAME, frame(frame)).build(), frame + "_" + handler.getHandlerId());
    }

    /**
     * Reloads root frame for page (top-level &lt;ui:frame id="content_frame"&gt;")
     *
     * @return action result
     */
    public SuccessReloadRootFrame reloadRootFrame() {
        return new SuccessReloadRootFrame();
    }

    /**
     * Reloads frame of root component
     *
     * @param frame id of frame to reload
     * @return action result
     */
    public SuccessReloadRootFrame reloadRootFrame(String frame) {
        return new SuccessReloadRootFrame(frame);
    }

    public SuccessOpenModal openModal(String handlerName) {
        return new SuccessOpenModal(MappingRegistry.instance().getMetaByName(handlerName).getMapping());
    }

    public SuccessOpenModal openModal(Class<? extends AbstractUIHandler> handlerClass) {
        return new SuccessOpenModal(MappingRegistry.instance().getMetaByClass(handlerClass).getMapping());
    }

    public SuccessOpenModal openModal(Class<? extends AbstractUIHandler> handlerClass, Map<String, Object> parameters) {
        HandlerMeta meta = MappingRegistry.instance().getMetaByClass(handlerClass);
        UriBuilder builder = new UriBuilder(meta.getMapping(), true);

        for (Map.Entry<String, Object> param : parameters.entrySet()) {
            builder.parameter(meta.getParamCode(param.getKey()), param.getValue());
        }

        return new SuccessOpenModal(builder);
    }

    public SuccessCloseModal closeModal() {
        return new SuccessCloseModal();
    }

    public SuccessDownloadFile downloadFile(AsyncFile file) {
        return new SuccessDownloadFile(file);
    }

    public SuccessInsertPayload insertPayload(String targetId, String payload) {
        return new SuccessInsertPayload(targetId, payload);
    }

    public SuccessNotify notify(String message) {
        return new SuccessNotify(message);
    }

    public SuccessNotify notify(String message, String type) {
        return new SuccessNotify(message).type(type);
    }

    public SuccessNotify notify(String title, String message, String type) {
        return new SuccessNotify(message).title(title).type(type);
    }

    public SuccessRedirect redirect(UriBuilder uriBuilder) {
        if (uriBuilder instanceof RedirectBuilder redirectBuilder) {
            Object[] keys = uriBuilder.getParameters().keySet().toArray();
            HandlerMeta meta = MappingRegistry.instance().getMetaByClass(redirectBuilder.getHandlerClass());

            // replace parameter names with internal codes
            for (Object key : keys) {
                uriBuilder.getParameters().put(meta.getParamCode((String) key), uriBuilder.getParameters().get(key));

                if (!key.equals(meta.getParamCode((String) key)))
                    uriBuilder.getParameters().remove(key);
            }
        }

        return new SuccessRedirect(uriBuilder);
    }

    public SuccessRedirect redirect(String uri) {
        return new SuccessRedirect(uri);
    }

    public SuccessRedirect redirect(Class<? extends AbstractUIHandler> handlerClass) {
        return new SuccessRedirect(MappingRegistry.instance().getMetaByClass(handlerClass).getMapping());
    }

    public SuccessReloadPage reloadPage() {
        return new SuccessReloadPage();
    }

    public SuccessCallJSFunction callJSFunction(String functionName) {
        return new SuccessCallJSFunction(functionName);
    }

    public SuccessCallJSFunction callJSFunction(String functionName, Object data) {
        return new SuccessCallJSFunction(functionName).data(data);
    }

    public SuccessDoNothing doNothing() {
        return new SuccessDoNothing();
    }

    public String frame(String fragmentId) {
        return handler.getHandlerId() + "." + fragmentId;
    }

}
