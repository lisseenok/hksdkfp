package ru.adaptms.quickui.security;

/**
 * @author ppolyakov at 23.02.2022 18:48
 */
public interface IQuickUISecurityResolver {

    boolean isAllowed( String input );

}
