package ru.adaptms.quickui.fallback.unauthorized;

import ru.adaptms.quickui.annotation.Ignore;
import ru.adaptms.quickui.handler.page.UnauthorizedPage;

/**
 * @author ppolyakov at 23.02.2022 19:31
 */
@Ignore
public class FallbackUnauthorizedPage extends UnauthorizedPage {
}
