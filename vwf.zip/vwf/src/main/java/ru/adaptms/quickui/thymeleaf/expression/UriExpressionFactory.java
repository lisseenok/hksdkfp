package ru.adaptms.quickui.thymeleaf.expression;

import org.thymeleaf.context.IExpressionContext;
import org.thymeleaf.expression.IExpressionObjectFactory;

import java.util.Collections;
import java.util.Set;

/**
 * @author ppolyakov at 18.04.2022 09:52
 */
public class UriExpressionFactory implements IExpressionObjectFactory {

    public static final String TEMPORAL_EVALUATION_VARIABLE_NAME = "uri";
    private static final Set<String> ALL_EXPRESSION_OBJECT_NAMES =
            Set.copyOf( Collections.singletonList( TEMPORAL_EVALUATION_VARIABLE_NAME ) );

    @Override
    public Set<String> getAllExpressionObjectNames() {
        return ALL_EXPRESSION_OBJECT_NAMES;
    }

    @Override
    public Object buildObject( IExpressionContext context, String expressionObjectName ) {
        if ( TEMPORAL_EVALUATION_VARIABLE_NAME.equals( expressionObjectName ) ) {
            return UriResolver.instance();
        }
        return null;
    }

    @Override
    public boolean isCacheable( String expressionObjectName ) {
        return false;
    }
}
