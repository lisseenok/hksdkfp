package ru.adaptms.quickui.util;

import org.springframework.web.util.NestedServletException;
import org.thymeleaf.exceptions.TemplateEngineException;
import ru.adaptms.vwf.util.LoggingUtil;

import jakarta.servlet.*;
import java.io.IOException;

/**
 * @author ppolyakov at 22.06.2022 01:30
 */
public class ThymeleafErrorFilter implements Filter {

    @Override
    public void init( final FilterConfig filterConfig ) {

    }

    @Override
    public void doFilter( final ServletRequest servletRequest, final ServletResponse servletResponse, final FilterChain filterChain ) throws IOException, ServletException {
        try {
            filterChain.doFilter( servletRequest, servletResponse );
        } catch ( final NestedServletException nse ) {
            if ( nse.getCause() instanceof TemplateEngineException ) {
                LoggingUtil.exception( "Thymeleaf, request: " + servletRequest.getLocalAddr(), nse );
            }

            throw nse;
        }
    }

    @Override
    public void destroy() {
    }
}
