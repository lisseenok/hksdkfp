package ru.adaptms.quickui.annotation.ext;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author ppolyakov at 21.02.2022 04:16
 */
@Retention( RetentionPolicy.RUNTIME)
@Target( value = {ElementType.TYPE, ElementType.METHOD})
public @interface ExtensionTarget {
    TargetType type() default TargetType.EXT_ID;
    String value();
}
