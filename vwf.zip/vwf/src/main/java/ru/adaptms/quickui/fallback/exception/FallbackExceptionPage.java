package ru.adaptms.quickui.fallback.exception;

import org.apache.commons.lang3.exception.ExceptionUtils;
import ru.adaptms.quickui.annotation.Ignore;
import ru.adaptms.quickui.annotation.MappedHandler;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.page.ExceptionPage;
import ru.adaptms.vwf.ui.action.ActionResult;
import ru.adaptms.vwf.util.FormattingUtil;

import java.util.Date;

/**
 * @author ppolyakov at 23.02.2022 19:37
 */
@Ignore
@MappedHandler( mapping = "quickui_exception" )
public class FallbackExceptionPage extends ExceptionPage {

    private Exception exception;
    private String[] stackTrace;

    private boolean showStackTrace;

    @Override
    public void onRefresh() {
        Exception input = ( Exception ) getRequest().getAttribute( ExceptionPage.EXCEPTION_PARAM );
        if ( input == null )
            return;

        setException( input );
        setStackTrace( ExceptionUtils.getStackFrames( exception ) );
    }

    public ActionResult toggleStackTrace() {
        setShowStackTrace( !isShowStackTrace() );

        return getSupport().actionResult( getSupport().reloadFrame( "stacktrace_frame" ) );
    }

    public Exception getException() {
        return exception;
    }

    public void setException( Exception exception ) {
        this.exception = exception;
    }

    public String[] getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace( String[] stackTrace ) {
        this.stackTrace = stackTrace;
    }

    public boolean isShowStackTrace() {
        return showStackTrace;
    }

    public void setShowStackTrace( boolean showStackTrace ) {
        this.showStackTrace = showStackTrace;
    }

    public String getExceptionType() {
        return getException() != null ? getException().getClass().getCanonicalName() : "неизвестно";
    }

    public String getExceptionTime( boolean friendly ) {
        return friendly ? FormattingUtil.instance().formatDate( new Date(), "dd.MM.yyyy HH:mm" ) : new Date().toString();
    }

    public String getExceptionMessage() {
        return ExceptionUtils.getMessage( getException() );
    }

    public String getFullStackTrace() {
        return ExceptionUtils.getStackTrace( getException() );
    }
}
