package ru.adaptms.quickui.registry;

import jakarta.annotation.PostConstruct;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Service;
import ru.adaptms.quickui.annotation.HandlerParam;
import ru.adaptms.quickui.annotation.Ignore;
import ru.adaptms.quickui.annotation.MappedHandler;
import ru.adaptms.quickui.annotation.OverrideName;
import ru.adaptms.quickui.annotation.ext.Extension;
import ru.adaptms.quickui.exception.NotFoundException;
import ru.adaptms.quickui.fallback.exception.FallbackExceptionPage;
import ru.adaptms.quickui.fallback.notFound.FallbackNotFoundPage;
import ru.adaptms.quickui.fallback.unauthorized.FallbackUnauthorizedPage;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerExtensionMeta;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.handler.page.ExceptionPage;
import ru.adaptms.quickui.handler.page.NotFoundPage;
import ru.adaptms.quickui.handler.page.UnauthorizedPage;
import ru.adaptms.quickui.registry.xml.HandlerNode;
import ru.adaptms.quickui.registry.xml.HandlersNode;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.i18n.xml.MessagesNode;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.SpringUtils;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * @author ppolyakov at 21.02.2022 03:43
 */
@Service("quickui_mappings")
@RequiredArgsConstructor
@SuppressWarnings("unchecked")
public class MappingRegistry {
    public static MappingRegistry instance() { return SpringUtils.getInstance(MappingRegistry.class); }

    private final ReflectionsUtil reflectionsUtil;

    private final Map<Class<? extends AbstractUIHandler>, HandlerMeta> handlerClassToMeta = new HashMap<>();

    @Getter
    private final Map<String, HandlerMeta> handlerNameToMeta = new HashMap<>();

    @Getter
    private final Map<String, HandlerMeta> handlerMappingToMeta = new HashMap<>();

    private boolean INITIALIZED = false;

    @Getter
    private Class<? extends NotFoundPage> notFoundPage;
    @Getter
    private Class<? extends UnauthorizedPage> unauthorizedPage;
    @Getter
    private Class<? extends ExceptionPage> exceptionPage;

    public HandlerMeta getMetaByClass(Class<? extends AbstractUIHandler> handlerClass) {
        HandlerMeta output = handlerClassToMeta.get(handlerClass);
        if (output == null)
            throw new NotFoundException("Handler for class \"" + handlerClass.getCanonicalName() + "\" is not registered.");
        return output;
    }

    public HandlerMeta getMetaByMapping(String mapping) {
        HandlerMeta output = handlerMappingToMeta.get(mapping);
        if (output == null) throw new NotFoundException("Handler for mapping \"" + mapping + "\" is not registered.");
        return output;
    }

    public HandlerMeta getMetaByName(String name) {
        HandlerMeta output = handlerNameToMeta.get(name);
        if (output == null) throw new NotFoundException("Handler for name \"" + name + "\" is not registered.");
        return output;
    }

    public boolean isHandlerRegistered(String name) {
        return handlerNameToMeta.containsKey(name);
    }

    /**
     * Initialize handler classes mappings
     */
    @PostConstruct
    public void initMappings() {
        if (INITIALIZED)
            throw new IllegalStateException("Cannot initialize handlers: handlers may only be initialized once.");

        LoggingUtil.debug(MappingRegistry.class, "Creating QuickUI handlers metadata....");

        // get all existing classes that are QuickUI handlers
        Set<Class<? extends AbstractUIHandler>> configuredHandlers = reflectionsUtil.getSubclasses(AbstractUIHandler.class);

        LoggingUtil.debug(MappingRegistry.class, String.format("    Found %d UI handlers.", configuredHandlers.size()));

        // prepare local maps
        Map<Class<? extends AbstractUIHandler>, String> overriddenHandlerNames = getOverriddenNames(); // override for same names
        Map<Class<? extends AbstractUIHandler>, List<HandlerExtensionMeta>> extensions = new HashMap<>();

        // load each handler
        for (Class<? extends AbstractUIHandler> configuredHandler : configuredHandlers) {
            // check whether handler name is overridden somewhere (via annotation or XML)
            String name;
            if (configuredHandler.isAnnotationPresent(OverrideName.class)) {
                name = configuredHandler.getAnnotation(OverrideName.class).value();
            } else if (!overriddenHandlerNames.containsKey(configuredHandler)) {
                // resolve default name from class name (ClassName -> className)
                name = configuredHandler.getSimpleName().substring(0, 1).toLowerCase(Locale.ROOT) + configuredHandler.getSimpleName().substring(1);
            } else {
                name = overriddenHandlerNames.get(configuredHandler);
            }

            boolean isExtension = false;

            // check extension validity
            if (configuredHandler.isAnnotationPresent(Extension.class)) {
                if (configuredHandler.isAnnotationPresent(MappedHandler.class))
                    throw new IllegalStateException("Handler may not be both an extension and a mapped handler simultaneously. " +
                            "Remove either @Extension or @Mapped handler annotation from class \"" + configuredHandler.getCanonicalName() + "\"");

                isExtension = true;
            }

            // extensions have names with special prefix
            HandlerMeta meta = new HandlerMeta(configuredHandler, isExtension ? "ext_" + name : name);

            if (isExtension) {
                HandlerExtensionMeta extensionMeta = new HandlerExtensionMeta(configuredHandler);
                if (!extensions.containsKey(extensionMeta.getHandlerClass()))
                    extensions.put(extensionMeta.getHandlerClass(), new ArrayList<>());

                extensions.get(extensionMeta.getHandlerClass()).add(extensionMeta);
            }

            if (handlerNameToMeta.containsKey(meta.getName()))
                throw new IllegalStateException("Duplicated handler name \"" + meta.getName() + "\". Handler names must be unique. Either change the class name " +
                        "or create an overriding handler name in Handlers.xml file / add @OverrideName annotation.");

            // add or replace handler mappings (name -> class)
            addMappings(configuredHandler, meta);

            if (meta.getMapping() != null) processPage(meta);
            processMessages(meta);
            processParameters(meta);
        }

        // define tech pages
        Set<Class<? extends NotFoundPage>> notFoundPages = reflectionsUtil.getSubclasses(NotFoundPage.class);
        Set<Class<? extends UnauthorizedPage>> unauthorizedPages = reflectionsUtil.getSubclasses(UnauthorizedPage.class);
        Set<Class<? extends ExceptionPage>> exceptionPages = reflectionsUtil.getSubclasses(ExceptionPage.class);

        // remove default tech pages
        notFoundPages.remove(FallbackNotFoundPage.class);
        unauthorizedPages.remove(FallbackUnauthorizedPage.class);
        exceptionPages.remove(FallbackExceptionPage.class);

        // resolve tech pages
        if (!CollectionUtils.isEmpty(notFoundPages)) {
            if (notFoundPages.size() > 1)
                LoggingUtil.debug(MappingRegistry.class, "More than one NotFoundPage was found. Will use last.)");
            notFoundPage = notFoundPages.stream().reduce((prev, next) -> next).orElse(null);
        }

        if (!CollectionUtils.isEmpty(unauthorizedPages)) {
            if (unauthorizedPages.size() > 1)
                LoggingUtil.debug(MappingRegistry.class, "More than one UnauthorizedPage was found. Will use last.)");
            unauthorizedPage = unauthorizedPages.stream().reduce((prev, next) -> next).orElse(null);
        }

        if (!CollectionUtils.isEmpty(exceptionPages)) {
            if (exceptionPages.size() > 1)
                LoggingUtil.debug(MappingRegistry.class, "More than one ExceptionPage was found. Will use last.)");
            exceptionPage = exceptionPages.stream().reduce((prev, next) -> next).orElse(null);
        }

        // if not found - use default
        if (notFoundPage == null) notFoundPage = FallbackNotFoundPage.class;
        if (unauthorizedPage == null) unauthorizedPage = FallbackUnauthorizedPage.class;
        if (exceptionPage == null) exceptionPage = FallbackExceptionPage.class;

        AppDefines.set(AppDefines.EXCEPTION_PAGE_MAPPING, getMetaByClass(exceptionPage).getMapping());

        // add extensions
        for (Map.Entry<Class<? extends AbstractUIHandler>, List<HandlerExtensionMeta>> extension : extensions.entrySet()) {
            handlerClassToMeta.get(extension.getKey()).addExtensions(extension.getValue());
        }

        LoggingUtil.debug(MappingRegistry.class, MessageFormat.format("Done. {0} handlers found.", handlerClassToMeta.size()));

        INITIALIZED = true;
    }

    public void addMappings(Class<? extends AbstractUIHandler> configuredHandler, HandlerMeta meta) {
        handlerClassToMeta.put(configuredHandler, meta);
        handlerNameToMeta.put(meta.getName(), meta);
    }

    /**
     * Read handler meta data and add to registry
     */
    public void processPage(HandlerMeta meta) {
        boolean skip = meta.getHandlerClass().isAnnotationPresent(Ignore.class); // will skip handlers marked as such or set as error pages.

        if (meta.getHandlerClass() == FallbackNotFoundPage.class
                || meta.getHandlerClass() == FallbackUnauthorizedPage.class
                || meta.getHandlerClass() == FallbackExceptionPage.class) skip = true;

        // add or replace handler in mapping map
        if (!skip) {
            if (!handlerMappingToMeta.containsKey(meta.getMapping())) {
                handlerMappingToMeta.put(meta.getMapping(), meta);
            } else {
                throw new IllegalStateException("Duplicated QuickUI page mapping \"" + meta.getMapping() + "\"");
            }
        }
    }

    private void processMessages(HandlerMeta meta) {
        InputStream i18nStream = getClass().getClassLoader()
                .getResourceAsStream(meta.getPath() + "I18n.xml");
        if (i18nStream != null) {
            try {
                JAXBContext context = JAXBContext.newInstance(MessagesNode.class);
                System.setProperty("javax.xml.accessExternalDTD", "all");
                Unmarshaller unmarshaller = context.createUnmarshaller();
                MessagesNode messagesNode = (MessagesNode) unmarshaller.unmarshal(i18nStream);

                I18NService.processMessagesNode(meta.getMessages(), messagesNode, messagesNode.prefix != null ? messagesNode.prefix : "");
            } catch (Exception e) {
                LoggingUtil.error(MappingRegistry.class, "            Messages for handler \"" + meta.getName() + "\" couldn't be initialized.", e);
            }
        }
    }

    private Map<Class<? extends AbstractUIHandler>, String> getOverriddenNames() {
        Map<Class<? extends AbstractUIHandler>, String> output = new HashMap<>();
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(this.getClass().getClassLoader());
            Resource[] resources = resolver.getResources("classpath*:/**/Handlers.xml");

            for (Resource resource : resources) {
                InputStream is = resource.getInputStream();
                JAXBContext context = JAXBContext.newInstance(HandlersNode.class);
                System.setProperty("javax.xml.accessExternalDTD", "all");
                Unmarshaller unmarshaller = context.createUnmarshaller();
                HandlersNode handlersNode = (HandlersNode) unmarshaller.unmarshal(is);

                for (HandlerNode handlerNode : handlersNode.handlers) {
                    Class<? extends AbstractUIHandler> overriddenClass = (Class<? extends AbstractUIHandler>) Class.forName(handlerNode.handlerClass);

                    if (output.containsKey(overriddenClass))
                        throw new IllegalArgumentException("You may not override handler name more than once. Handler class: \"" + handlerNode.handlerClass + "\", " +
                                "resource: \"" + resource.getURI().getPath() + "\"");
                    output.put(overriddenClass, handlerNode.name);
                }
            }
        } catch (IOException | JAXBException | ClassNotFoundException e) {
            LoggingUtil.error(MappingRegistry.class, "Couldn't initialize overridden handler names.", e);
        }

        return output;
    }

    private void processParameters(HandlerMeta meta) {
        for (Field declaredField : meta.getHandlerClass().getDeclaredFields()) {
            if (!declaredField.isAnnotationPresent(HandlerParam.class)) continue;

            meta.addParam(declaredField);
        }
    }
}
