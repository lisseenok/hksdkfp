package ru.adaptms.quickui.thymeleaf.processor.component;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class ShorthandComponentProcessor extends ComponentProcessor {

    public ShorthandComponentProcessor(String dialectPrefix) {
        super(dialectPrefix, null, 800);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext, IProcessableElementTag elementTag, IElementTagStructureHandler structureHandler) {
        String tagName = elementTag.getElementCompleteName();
        if (!tagName.startsWith(getDialectPrefix() + ":")) return;

        tagName = tagName.replace(getDialectPrefix() + ":", "");

        super.processInternal(incomingContext, elementTag, structureHandler, tagName);
    }
}
