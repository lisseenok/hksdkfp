package ru.adaptms.quickui.handler.meta;

import lombok.Getter;
import org.apache.commons.codec.digest.DigestUtils;
import ru.adaptms.quickui.annotation.Authenticate;
import ru.adaptms.quickui.annotation.HandlerParam;
import ru.adaptms.quickui.annotation.MappedHandler;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.vwf.ui.i18n.MessageDefinition;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.reflections.MethodUtil;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Static metadata for a handler.
 *
 * @author ppolyakov at 08.04.2022 22:33
 */
public class HandlerMeta implements Serializable {
    @Getter
    private final String name;
    @Getter
    private final String mapping;
    @Getter
    private final Class<? extends AbstractUIHandler> handlerClass;
    @Getter
    private final String auth;
    @Getter
    protected String path; // path to class (package with handler)
    @Getter
    protected Map<String, MessageDefinition> messages = new HashMap<>();

    @Getter
    private List<HandlerParamMeta> params = new ArrayList<>();
    private Map<String, String> paramNamesToCodes = new HashMap<>();

    @Getter
    private List<HandlerExtensionMeta> extensions = new ArrayList<>();

    public HandlerMeta(Class<? extends AbstractUIHandler> handlerClass, String name) {
        this.name = name;
        this.mapping = resolveMapping(handlerClass);
        this.handlerClass = handlerClass;
        this.auth = handlerClass.isAnnotationPresent(Authenticate.class) ? handlerClass.getAnnotation(Authenticate.class).value() : null;
        path = this.handlerClass.getCanonicalName().replaceAll("\\.", "/").replace(this.handlerClass.getSimpleName(), "");
    }

    /**
     * Adds param meta for future static metadata access (i.e. setting params on handlers)
     *
     * @param field field from handler class to add param from
     */
    public void addParam(Field field) {
        int index = params.size() + 1;
        try {
            String paramName = !"#_generate_#".equals(field.getAnnotation(HandlerParam.class).name()) ? field.getAnnotation(HandlerParam.class).name() : field.getName();
            String paramCode;
            if (field.getAnnotation(HandlerParam.class).showName()) {
                paramCode = paramName;
            } else {
                paramCode = "p" + index;
            }

            HandlerParamMeta meta = new HandlerParamMeta(paramName, paramCode, index, field.getType(),
                    MethodUtil.getSetter(handlerClass, field), field.getAnnotation(HandlerParam.class).required());
            params.add(meta);

            paramNamesToCodes.put(meta.getName(), meta.getParamCode());
        } catch (NoSuchMethodException nsme) {
            LoggingUtil.error(HandlerMeta.class, "Couldn't find setter for parameter \"" + field.getName() + "\" of handler \"" + handlerClass.getCanonicalName() + "\"");
        }
    }

    /**
     * Resolve param code for internal param name
     *
     * @param paramName internal name of a param (field name)
     * @return resolved code
     * @throws IllegalArgumentException if parameter with given name is not marked with annotation {@link HandlerParam} on handler (or not present at all).
     * @apiNote We use this to obfuscate url forging (replacing parameter values with some others)
     */
    public String getParamCode(String paramName) {
        if (!paramNamesToCodes.containsKey(paramName))
            throw new IllegalArgumentException("Parameter \"" + paramName + "\" is not present on handler \"" + getName() + "\" and therefore cannot be used.");

        return paramNamesToCodes.get(paramName);
    }

    public void addExtensions(List<HandlerExtensionMeta> extensionMetas) {
        extensions.addAll(extensionMetas);
        extensions.sort(Comparator.comparing(HandlerExtensionMeta::getPriority));
    }

    /**
     * Resolve page mapping (either from annotation - as is or from class name - removes "Page" at the end)
     *
     * @param pageClass page class to resolve
     * @return resolved page mapping
     */
    protected String resolveMapping(Class<? extends AbstractUIHandler> pageClass) {
        String mapping;
        if (pageClass.isAnnotationPresent(MappedHandler.class)) {
            if ("#_generate_#".equals(pageClass.getAnnotation(MappedHandler.class).mapping())) {
                mapping = DigestUtils.md5Hex(pageClass.getCanonicalName());
            } else {
                mapping = pageClass.getAnnotation(MappedHandler.class).mapping();
            }

            if (mapping.startsWith("/"))
                mapping = mapping.substring(1);
        } else {
            mapping = null;
        }

        return mapping;
    }
}
