package ru.adaptms.vwf.util.file;

import com.github.amr.mimetypes.MimeType;
import com.github.amr.mimetypes.MimeTypes;

import java.util.Locale;

public class MimeTypeUtil {
    public static final String RTF = "text/rtf";
    public static final String DOC = "application/msword";
    public static final String DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    public static final String PDF = "application/pdf";
    public static final String PPT = "application/vnd.ms-powerpoint";
    public static final String PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
    public static final String XLS = "application/vnd.ms-excel";
    public static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static final String TXT = "text/plain";
    public static final String ZIP = "application/zip";
    public static final String RAR = "application/vnd.rar";
    public static final String JPEG = "image/jpeg";
    public static final String BMP = "image/bmp";
    public static final String PNG = "image/png";
    public static final String ICO = "image/x-icon";
    public static final String JS = "text/javascript";
    public static final String JSON = "application/json";
    public static final String CSS = "text/css";
    public static final String TTF = "font/ttf";
    public static final String WOFF = "font/woff";
    public static final String WOFF2 = "font/woff2";
    public static final String EOT = "application/vnd.ms-fontobject";
    public static final String SVG = "image/svg+xml";
    public static final String WEBP = "image/webp";
    public static final String HTML = "text/html";
    public static final String XML = "application/xml";

    static {
        MimeTypes.getInstance().register(new MimeType("font/woff2", new String[]{"woff2"}));
        MimeTypes.getInstance().register(new MimeType("text/plain", new String[]{"map"}));
    }

    public static String getMimeType( String fileName ) {
        return MimeTypes.getInstance().getByExtension(fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT)).getMimeType();
    }

    public static String getMimeType( String fileName, boolean iAmAnIdiotAndWantLegacyBehavior ) {
        if ( fileName == null ) return "";

        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".rtf" ) ) return RTF;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".doc" ) ) return DOC;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".docx" ) ) return DOCX;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".pdf" ) ) return PDF;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".ppt" ) ) return PPT;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".pptx" ) ) return PPTX;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".xls" ) ) return XLS;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".xlsx" ) ) return XLSX;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".txt" ) ) return TXT;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".zip" ) ) return ZIP;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".rar" ) ) return RAR;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".jpg" )
                || fileName.toLowerCase( Locale.ROOT ).endsWith( ".jpeg" ) ) return JPEG;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".bmp" ) ) return BMP;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".png" ) ) return PNG;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".ico" ) ) return ICO;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".ttf" ) ) return TTF;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".woff" ) ) return WOFF;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".woff2" ) ) return WOFF2;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".eot" ) ) return EOT;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".js" ) ) return JS;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".json" ) ) return JSON;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".css" ) ) return CSS;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".svg" ) ) return SVG;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".webp" ) ) return WEBP;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".html" ) ) return HTML;
        if ( fileName.toLowerCase( Locale.ROOT ).endsWith( ".xml" ) ) return XML;

        throw new IllegalArgumentException( "Extension of file \"" + fileName + "\" is not bound with mime type." );
    }

}
