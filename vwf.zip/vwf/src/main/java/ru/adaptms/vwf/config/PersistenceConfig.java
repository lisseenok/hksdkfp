package ru.adaptms.vwf.config;

import com.zaxxer.hikari.HikariDataSource;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import ru.adaptms.vwf.persistence.migration.types.DBType;
import ru.adaptms.vwf.util.LoggingUtil;

import javax.sql.DataSource;

/**
 * @author polyakov_ps at 04.07.2023 9:12
 */
@Getter @Setter
@Configuration("framework_persistenceConfig")
@EnableTransactionManagement
@ConfigurationProperties(prefix = "db")
public class PersistenceConfig {

    private String url;

    private String type;

    private String username;

    private String password;

    private String schema;

    @Bean(name = "dataSource")
    public DataSource dataSource() {
        var ds = new HikariDataSource();
        ds.setDriverClassName(getDriverClassName());
        ds.setJdbcUrl(url);
        ds.setUsername(username);
        ds.setPassword(password);
        return new TransactionAwareDataSourceProxy(ds);
    }

    /**
     * @return SessionFactory для работы Hibernate и обработки транзакций
     */
    @Bean(name = {"sessionFactory", "entityManagerFactory"})
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean localSessionFactoryBean = new LocalSessionFactoryBean();
        localSessionFactoryBean.setDataSource(dataSource());
        localSessionFactoryBean.setConfigLocation(new ClassPathResource("hibernate.cfg.xml")); // файл конфигурации Hibernate
        String[] packagesToScan = new String[]{"ru.adaptms", "ru"};
        localSessionFactoryBean.setPackagesToScan(packagesToScan); // будем сканировать все такие пакеты во всех модулях

        var defaultSchema = getDataSourceDefaultSchema();
        if (defaultSchema != null)
            localSessionFactoryBean.getHibernateProperties().setProperty("hibernate.default_schema", defaultSchema);

        return localSessionFactoryBean;
    }

    /**
     * @return Менеджер транзакций к БД
     */
    @Bean
    public HibernateTransactionManager transactionManager() {
        HibernateTransactionManager transactionManager = new HibernateTransactionManager();
        transactionManager.setSessionFactory(sessionFactory().getObject());
        return transactionManager;
    }

    public String getDriverClassName() {
        if (type.matches(DBType.MYSQL_5)) return "com.mysql.cj.jdbc.Driver";
        else if (type.matches(DBType.MYSQL_8)) return "com.mysql.cj.jdbc.Driver";
        else if (type.matches(DBType.MSSQL)) return  "com.microsoft.sqlserver.jdbc.SQLServerDriver";
        else if (type.matches(DBType.PSQL)) return "org.postgresql.Driver";

        LoggingUtil.error(PersistenceConfig.class, "Couldn't resolve DB type \"" + type + "\".");
        throw new IllegalStateException("DB property initialization failed.");
    }

    public String getDataSourceDefaultSchema() {
        if (StringUtils.isNotBlank(schema)) return schema;
        if (type.matches(DBType.MYSQL_5) || type.matches(DBType.MYSQL_8)) return url.split("/|\\?")[3];
        else if (type.matches(DBType.MSSQL)) return "dbo";
        else if (type.matches(DBType.PSQL)) return "public";

        LoggingUtil.error(FrameworkMvcConfig.class, "Couldn't resolve DB type \"" + type + "\".");
        throw new IllegalStateException("DB property initialization failed.");
    }
}
