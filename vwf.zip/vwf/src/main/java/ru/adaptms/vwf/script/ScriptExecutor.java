package ru.adaptms.vwf.script;

import groovy.lang.GroovyClassLoader;
import ru.adaptms.vwf.script.groovy.GroovyScript;

import javax.script.*;
import java.util.Locale;
import java.util.Map;

/**
 * @author ppolyakov at 29.01.2022 17:24
 */
public class ScriptExecutor {

    private ScriptExecutor() {}

    public static Object execute( String script, String language, Map<String, Object> parameters ) throws Exception {
        Bindings bindings = new SimpleBindings();

        if ( parameters != null && !parameters.isEmpty() )
            bindings.putAll( parameters );

        if ( "javascript".equals( language.toLowerCase( Locale.ROOT ) ) ) {
            ScriptEngine engine = new ScriptEngineManager().getEngineByName( "js" );
            CompiledScript compiledScript = ( ( Compilable ) engine ).compile( script );
            return compiledScript.eval( bindings ); // in groovy scripts bindings may be used like return (name);
        } else if ( "groovy".equals( language.toLowerCase( Locale.ROOT ) ) ) {
            GroovyClassLoader gcl = new GroovyClassLoader();
            Class<? extends GroovyScript> cls = gcl.parseClass( script );
            GroovyScript instantiatedClass = cls.getDeclaredConstructor( Bindings.class ).newInstance( bindings );
            Object result = instantiatedClass.execute();
            gcl.close();
            return result;
        }

        return null;
    }
}
