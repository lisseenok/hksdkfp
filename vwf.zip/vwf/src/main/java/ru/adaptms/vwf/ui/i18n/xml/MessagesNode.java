package ru.adaptms.vwf.ui.i18n.xml;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

/**
 * @author ppolyakov at 25.08.2021 16:37
 */
@XmlRootElement( name = "messages" )
public class MessagesNode {

    @XmlAttribute
    public String prefix;

    @XmlElement( name = "message" )
    public List<MessageNode> messages;

    @XmlElement( name = "messages" )
    public List<MessagesNode> blocks;

    public MessagesNode() {
    }
}
