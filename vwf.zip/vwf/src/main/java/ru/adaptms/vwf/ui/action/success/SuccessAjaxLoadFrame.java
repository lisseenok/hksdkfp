package ru.adaptms.vwf.ui.action.success;

import ru.adaptms.vwf.ui.util.uri.UriUtil;
import ru.adaptms.vwf.util.SpringUtils;

/**
 * Load frame by url.
 *
 * @author ppolyakov at 07.01.2022 00:54
 */
public class SuccessAjaxLoadFrame implements ISuccessAction {
    private final UriUtil uriUtil = ( UriUtil ) SpringUtils.getBeanByName( "uriUtil" );

    private String uri;
    private String targetId;

    public SuccessAjaxLoadFrame( String url, String targetId ) {
        this.uri = uriUtil.prependContextPath( url );
        this.targetId = targetId;
    }

    public String getUri() {
        return uri;
    }

    public void setUri( String uri ) {
        this.uri = uri;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId( String targetId ) {
        this.targetId = targetId;
    }

    @Override
    public String getAction() {
        return "loadFragment";
    }
}
