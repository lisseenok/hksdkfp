package ru.adaptms.vwf.persistence.migration.structure.db;

import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;
import ru.adaptms.vwf.persistence.migration.types.ColumnType;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Колонка таблицы
 *
 * @author ppolyakov at 05.12.2021 15:35
 */
public class DBTableColumn {
    private String name;
    private ColumnType type;
    private Integer length;
    private boolean pk = false;
    private boolean autoIncrement = false;
    private boolean notNull = false;
    private boolean unique = false;
    private Object defaultValue;

    private List<DBConstraint> constraints = new LinkedList<>();

    /**
     * @param name имя колонки
     */
    public DBTableColumn( String name ) {
        this.name = name;
    }

    /**
     * @param name имя колонки
     * @param type тип
     */
    public DBTableColumn( String name, ColumnType type ) {
        this.name = name;
        this.type = type;
    }

    /** установить тип */
    public DBTableColumn type( ColumnType type ) {
        this.type = type;
        return this;
    }

    /** установить тип и длину хранимых данных */
    public DBTableColumn type( ColumnType type, Integer length ) {
        this.type = type;
        this.length = length;
        return this;
    }

    /** установить длину хранимых данных */
    public DBTableColumn length( Integer length ) {
        this.length = length;
        return this;
    }

    /** эта колонка - первичный ключ */
    public DBTableColumn primaryKey() {
        this.pk = true;
        return this;
    }

    /** эта колонка с автогенерируемыми значениями */
    public DBTableColumn autoIncrement() {
        this.autoIncrement = true;
        return this;
    }

    /** эта колонка - не NULL */
    public DBTableColumn notNull() {
        this.notNull = true;
        return this;
    }

    /** эта колонка содержит уникальные значения */
    public DBTableColumn unique() {
        this.unique = true;
        return this;
    }

    /** Задать ограничения колонки */
    public DBTableColumn constraints( DBConstraint... constraints ) {
        if ( constraints != null )
            this.constraints.addAll( Arrays.asList( constraints ) );
        return this;
    }

    /** установить значение по умолчанию */
    public DBTableColumn defaultValue( Object defaultValue ) {
        if ( !( defaultValue.getClass() == type.getDefaultValueType()
                || defaultValue.getClass().isAssignableFrom( type.getDefaultValueType() ) ) )
            throw new IllegalStateException( "Incorrect default value type." );
        this.defaultValue = defaultValue;
        return this;
    }

    public String getName() {
        return name;
    }

    public ColumnType getType() {
        return type;
    }

    public Integer getLength() {
        return length;
    }

    public boolean isPk() {
        return pk;
    }

    public boolean isAutoIncrement() {
        return autoIncrement;
    }

    public boolean isNotNull() {
        return notNull;
    }

    public boolean isUnique() {
        return unique;
    }

    public Object getDefaultValue() {
        return defaultValue;
    }

    public List<DBConstraint> getConstraints() {
        return constraints;
    }
}
