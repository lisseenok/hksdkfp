package ru.adaptms.vwf.ui.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 02.01.2022 23:13
 */
public class AppDefines {

    public static final String APP_PROPERTIES = "app.properties";
    public static final String CONFIG_PATH_PROPERTY = "configPathProperty";
    public static final String DATA_PATH = "dataPath";
    public static final String STORAGE_PATH = "storagePathPath";
    public static final String BASE_URL = "baseUrl";
    public static final String MINIO_ACCESS_KEY = "minioAccessKey";
    public static final String MINIO_SECRET_KEY = "minioSecretKey";
    public static final String MINIO_BUCKET = "minioBucket";
    public static final String KAFKA_URL = "kafkaUrl";
    public static final String NAVBAR_LOGO_URL = "navbarLogoUrl";
    public static final String NAVBAR_FAVICON_URL = "navbarFaviconUrl";
    public static final String NAVBAR_ADDITIONAL_TEXT = "navbarAdditionalText";
    public static final String APP_MODE = "mode";
    public static final String LOG_LEVEL = "log.level";
    public static final String FIXED_LOCALE = "fixedLocale";
    public static final String EXCEPTION_PAGE_MAPPING = "exceptionPageMapping";
    public static final String VERSION = "version";
    public static final String FIRST_LAUNCH = "isFirstLaunch";
    public static final String HANDLER_LIFE = "handlerLife";
    public static final String LAYOUT_TEMPLATE = "layoutTemplate";
    public static final String LAYOUT_LOGO = "layoutLogo";
    public static final String AUTH_SECRET_KEY = "authSecretKey";
    public static final String GELF_HOST = "gelfHost";
    public static final String GELF_PORT = "gelfPort";
    public static final String APP_NAME = "appName";

    public static final String REDIS_HOST = "redisHost";
    public static final String REDIS_PORT = "redisPort";
    public static final String REDIS_PASSWORD = "redisPassword";

    private static final Map<String, Object> appParameters = new HashMap<>();

    public static void set( String name, Object value ) {
        appParameters.put( name, value );
    }

    public static <T> T get( String name ) {
        return (T) appParameters.get( name );
    }

    public static boolean isDebug() {
        return "debug".equals( get( APP_MODE ) );
    }
}
