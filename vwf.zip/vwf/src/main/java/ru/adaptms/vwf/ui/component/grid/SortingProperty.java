package ru.adaptms.vwf.ui.component.grid;

import org.adaptms.hqlbuilder.property.EntityPath;
import ru.adaptms.vwf.ui.component.select.SimpleOption;

import java.io.Serializable;

/**
 * @author ppolyakov at 23.01.2022 18:11
 */
public class SortingProperty implements Serializable {
    private EntityPath path;
    private String title;
    private OrderDirection currentDirection;
    private int order = 0;

    public SortingProperty( EntityPath path, String title ) {
        this.path = path;
        this.title = title;
    }

    public SortingProperty set(OrderDirection currentDirection) {
        this.currentDirection = currentDirection;
        return this;
    }

    public String getStringPath() {
        return path.getPath();
    }

    public EntityPath getPath() {
        return path;
    }

    public void setPath( EntityPath path ) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle( String title ) {
        this.title = title;
    }

    public OrderDirection getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection( OrderDirection currentDirection ) {
        this.currentDirection = currentDirection;
    }

    public Integer getOrder() {
        return order;
    }

    public void setOrder( int order ) {
        this.order = order;
    }

    public SimpleOption getOrderAsOption() {
        return new SimpleOption( order == 0 ? "none" : String.valueOf( order ), "" );
    }
}
