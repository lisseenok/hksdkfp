package ru.adaptms.vwf.util.registry;

import java.util.Map;

/**
 * @author ppolyakov at 14.03.2022 16:23
 */
public interface IMapExtender {
    void execute( ExtendableHashMap<String, ExtendableHashMap<String, Object>> registry );
}
