package ru.adaptms.vwf.util.conversion.standard;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author ppolyakov at 04.01.2022 22:07
 */
@Component
public class BooleanObjConversion extends BooleanConversion {
    @Override
    public Class<?> getTargetClass() {
        return Boolean.class;
    }

    @Override
    public Object doConvert( String input ) {
        if ( StringUtils.isBlank( input ) )
            return null;
        return !( "false".equals( input ) || "off".equals( input ) );
    }
}
