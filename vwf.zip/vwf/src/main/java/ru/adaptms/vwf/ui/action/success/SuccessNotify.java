package ru.adaptms.vwf.ui.action.success;

/**
 * Show notification
 *
 * @author ppolyakov at 07.01.2022 00:54
 */
public class SuccessNotify implements ISuccessAction {
    private String title;
    private String message;
    private String type = "success";

    public SuccessNotify( String message ) {
        this.message = message;
    }

    public SuccessNotify type( String type ) {
        this.type = type;
        return this;
    }

    public SuccessNotify title( String title ) {
        this.title = title;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle( String title ) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage( String message ) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType( String type ) {
        this.type = type;
    }

    @Override
    public String getAction() {
        return "notify";
    }
}
