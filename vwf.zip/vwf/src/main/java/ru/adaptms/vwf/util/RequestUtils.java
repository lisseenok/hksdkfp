package ru.adaptms.vwf.util;

import org.springframework.web.bind.annotation.RequestMethod;

import jakarta.servlet.http.HttpServletRequest;

/**
 * @author ppolyakov at 07.01.2022 02:17
 */
public class RequestUtils {
    public static boolean isXHR( HttpServletRequest request ) {
        return "XMLHttpRequest".equals( request.getHeader( "X-Requested-With" ) );
    }

    public static boolean isMethod( HttpServletRequest request, RequestMethod method ) {
        return request.getMethod().equals( method.name() );
    }
}
