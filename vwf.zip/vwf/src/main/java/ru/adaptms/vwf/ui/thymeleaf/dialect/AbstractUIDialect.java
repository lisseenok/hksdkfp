package ru.adaptms.vwf.ui.thymeleaf.dialect;

import org.thymeleaf.dialect.AbstractProcessorDialect;

/**
 * @author ppolyakov at 10.03.2022 00:25
 */
public abstract class AbstractUIDialect extends AbstractProcessorDialect {
    protected AbstractUIDialect( String name, String prefix, int processorPrecedence ) {
        super( name, prefix, processorPrecedence );
    }
}
