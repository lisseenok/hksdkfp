package ru.adaptms.vwf.util.ldap;

import lombok.Getter;
import org.apache.commons.lang3.tuple.Pair;
import ru.adaptms.vwf.util.LoggingUtil;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static javax.naming.directory.SearchControls.SUBTREE_SCOPE;

//******************************************************************************
//**  ActiveDirectory
//*****************************************************************************/

/**
 * Provides static methods to authenticate users, change passwords, etc.
 * <p>
 * Solution from <a href="https://www.javaxt.com/wiki/Tutorials/Windows/How_to_Authenticate_Users_with_Active_Directory">here</a>
 ******************************************************************************/

public class ActiveDirectory {
    public static final String DISTINGUISHED_NAME = "distinguishedName";
    public static final String CN = "cn";
    public static final String NAME = "name";
    public static final String UID = "uid";
    public static final String USER_ACCOUNT_CONTROL = "userAccountControl";
    public static final String SN = "sn";
    public static final String GIVEN_NAME = "givenName";
    public static final String MEMBER_OF = "memberOf";
    public static final String SAM_ACCOUNT_NAME = "samaccountname";
    public static final String USER_PRINCIPAL_NAME = "userPrincipalName";
    public static final String MAIL = "mail";
    public static final String DISPLAY_NAME = "displayName";
    public static final String OBJECT_SID = "objectSid";
    public static final String LOCKOUT_TIME = "lockoutTime";

    public static String[] userAttributes = {
            DISTINGUISHED_NAME, CN, NAME, UID, USER_ACCOUNT_CONTROL,
            SN, GIVEN_NAME, MEMBER_OF, SAM_ACCOUNT_NAME,
            USER_PRINCIPAL_NAME
    };

    private ActiveDirectory() {
    }


    //**************************************************************************
    //** getConnection
    //*************************************************************************/

    /**
     * Used to authenticate a user given a username/password. Domain name is
     * derived from the fully qualified domain name of the host machine.
     */
    public static LdapContext getConnection(String username, String password, boolean useSsl) throws NamingException {
        return getConnection(username, password, null, null, useSsl);
    }

    public static LdapContext getConnection(String username, String password) throws NamingException {
        return getConnection(username, password, null, null, false);
    }


    //**************************************************************************
    //** getConnection
    //*************************************************************************/

    /**
     * Used to authenticate a user given a username/password and domain name.
     */
    public static LdapContext getConnection(String username, String password, String domainName, boolean useSsl) throws NamingException {
        return getConnection(username, password, domainName, null, useSsl);
    }

    public static LdapContext getConnection(String username, String password, String domainName) throws NamingException {
        return getConnection(username, password, domainName, null, false);
    }


    //**************************************************************************
    //** getConnection
    //*************************************************************************/

    /**
     * Used to authenticate a user given a username/password and domain name.
     * Provides an option to identify a specific Active Directory server.
     */
    public static LdapContext getConnection(String username, String password, String domainName, String serverName, boolean useSsl) throws NamingException {

        if (domainName == null) {
            try {
                String fqdn = java.net.InetAddress.getLocalHost().getCanonicalHostName();
                if (fqdn.split("\\.").length > 1) domainName = fqdn.substring(fqdn.indexOf(".") + 1);
            } catch (java.net.UnknownHostException e) {
            }
        }

        //System.out.println("Authenticating " + username + "@" + domainName + " through " + serverName);

        if (password != null) {
            password = password.trim();
            if (password.length() == 0) password = null;
        }

        //bind by using the specified username/password
        Hashtable<String, String> props = new Hashtable<>();
        String principalName = username.contains("@") ? username : (username + "@" + domainName);
        props.put(Context.SECURITY_PRINCIPAL, principalName);
        if (password != null) props.put(Context.SECURITY_CREDENTIALS, password);


        String ldapURL = "ldap" + (useSsl ? "s" : "") + "://" + ((serverName == null) ? domainName : serverName + "." + domainName) + (useSsl ? ":636" : "") + '/';
        props.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        props.put(Context.PROVIDER_URL, ldapURL);
//        props.put( Context.REFERRAL, "follow" );

        if (useSsl)
            props.put(Context.SECURITY_PROTOCOL, "ssl");

        try {
            return new InitialLdapContext(props, null);
        } catch (javax.naming.CommunicationException e) {
            LoggingUtil.error(ActiveDirectory.class, e);
            throw new NamingException("Failed to connect to " + domainName + ((serverName == null) ? "" : " through " + serverName));
        } catch (NamingException e) {
            // истек срок действия пароля
            if (e.getMessage() != null && e.getMessage().contains("data 532"))
                throw new PasswordExpiredException();

            // требуется сменить пароль
            if (e.getMessage() != null && e.getMessage().contains("data 773"))
                throw new PasswordMustBeChangedException();

            // пользователь заблокирован
            if (e.getMessage() != null && e.getMessage().contains("data 775"))
                throw new UserBlockedException();
            throw new NamingException("Failed to authenticate " + username + "@" + domainName + ((serverName == null) ? "" : " through " + serverName));
        }
    }


    //**************************************************************************
    //** getUser
    //*************************************************************************/

    /**
     * Used to check whether a username is valid.
     *
     * @param username A username to validate (e.g. "peter", "peter@acme.com",
     *                 or "ACME\peter").
     */
    public static User getUser(String username, LdapContext context) {
        try {
            String domainName = null;

            Pair<String, String> usernameAndDomain = resolveUsernameAndDomain(username);
            if (usernameAndDomain != null) {
                username = usernameAndDomain.getLeft();
                domainName = usernameAndDomain.getRight();
            } else {
                String authenticatedUser = (String) context.getEnvironment().get(Context.SECURITY_PRINCIPAL);
                if (authenticatedUser.contains("@")) {
                    domainName = authenticatedUser.substring(authenticatedUser.indexOf("@") + 1);
                }
            }

            if (domainName != null) {
//                String principalName = username + "@" + domainName;
                SearchControls controls = new SearchControls();
                controls.setSearchScope(SUBTREE_SCOPE);
                controls.setReturningAttributes(userAttributes);
                NamingEnumeration<SearchResult> answer = context.search(toDC(domainName), "(& (sAMAccountName=" + username + ")(objectClass=user))", controls); //userPrincipalName
                if (answer.hasMore()) {
                    Attributes attr = answer.next().getAttributes();
                    Attribute user = attr.get("userPrincipalName");
                    if (user != null) return new User(attr);
                }
            }
        } catch (NamingException e) {
            //e.printStackTrace();
        }
        return null;
    }

    /**
     * Split username and domain
     */
    public static Pair<String, String> resolveUsernameAndDomain(String username) {
        String domainName;
        if (username.contains("@")) {
            domainName = username.substring(username.indexOf("@") + 1);
            username = username.substring(0, username.indexOf("@"));
        } else if (username.contains("\\")) {
            domainName = username.substring(0, username.indexOf("\\"));
            username = username.substring(username.indexOf("\\") + 1);
        } else {
            return Pair.of(null, null);
        }

        return Pair.of(username, domainName);
    }


    //**************************************************************************
    //** getUsers
    //*************************************************************************/

    /**
     * Returns a list of users in the domain.
     */
    public static User[] getUsers(LdapContext context) throws NamingException {
        List<User> users = new ArrayList<>();
        String authenticatedUser = (String) context.getEnvironment().get(Context.SECURITY_PRINCIPAL);
        if (authenticatedUser.contains("@")) {
            String domainName = authenticatedUser.substring(authenticatedUser.indexOf("@") + 1);
            SearchControls controls = new SearchControls();
            controls.setSearchScope(SUBTREE_SCOPE);
            controls.setReturningAttributes(userAttributes);
            NamingEnumeration<SearchResult> answer = context.search(toDC(domainName), "(objectClass=user)", controls);
            try {
                while (answer.hasMore()) {
                    Attributes attr = ((SearchResult) answer.next()).getAttributes();
                    Attribute user = attr.get("userPrincipalName");
                    if (user != null) {
                        users.add(new User(attr));
                    }
                }
            } catch (Exception e) {
            }
        }
        return users.toArray(new User[users.size()]);
    }

    public static String toDC(String domainName) {
        StringBuilder buf = new StringBuilder();
        for (String token : domainName.split("\\.")) {
            if (token.length() == 0) continue;   // defensive check
            if (buf.length() > 0) buf.append(",");
            buf.append("DC=").append(token);
        }
        return buf.toString();
    }

    public static byte[] getPassword(String password) {
        char[] unicodePwd = ('"' + password + '"').toCharArray();
        byte[] pwdArray = new byte[unicodePwd.length * 2];
        for (int i = 0; i < unicodePwd.length; i++) {
            pwdArray[i * 2 + 1] = (byte) (unicodePwd[i] >>> 8);
            pwdArray[i * 2] = (byte) (unicodePwd[i] & 0xff);
        }
        return pwdArray;
    }

    public static String convertSid(byte[] sid) {
        final StringBuilder strSid = new StringBuilder("S-");
        final int revision = sid[0];
        strSid.append(revision);
        final int countSubAuths = sid[1] & 0xFF;
        long authority = 0;
        for (int i = 2; i <= 7; i++) {
            authority |= ((long) sid[i]) << (8 * (5 - (i - 2)));
        }
        strSid.append("-");
        strSid.append(Long.toHexString(authority));
        int offset = 8;
        int size = 4; //4 bytes for each sub auth
        for (int j = 0; j < countSubAuths; j++) {
            long subAuthority = 0;
            for (int k = 0; k < size; k++) {
                subAuthority |= (long) (sid[offset + k] & 0xFF) << (8 * k);
            }
            strSid.append("-");
            strSid.append(subAuthority);
            offset += size;
        }
        return strSid.toString();
    }

    //**************************************************************************
    //** User Class
    //*************************************************************************/

    /**
     * Used to represent a User in Active Directory
     */
    @Getter
    public static class User {
        private final String distinguishedName;
        private final String userPrincipal;
        private final String commonName;
        private final Set<String> memberOf = new HashSet<>();
        private final Map<String, String> systemUids = new HashMap<>();
        private final UserAccountControl userAccountControl;

        public User(Attributes attr) throws NamingException {

            userPrincipal = (String) attr.get(USER_PRINCIPAL_NAME).get();
            commonName = (String) attr.get(CN).get();
            distinguishedName = (String) attr.get(DISTINGUISHED_NAME).get();
            NamingEnumeration<String> groups = (NamingEnumeration<String>) attr.get(MEMBER_OF).getAll();
            if (groups != null) {
                while (groups.hasMore()) {
                    memberOf.add(groups.next());
                }
            }
            Attribute uidAttr = attr.get(UID);
            if (uidAttr != null) {
                NamingEnumeration<String> uids = (NamingEnumeration<String>) uidAttr.getAll();
                if (uids != null) {
                    while (uids.hasMore()) {
                        String[] parts = uids.next().split(":");
                        systemUids.put(parts[0], parts[1]);
                    }
                }
            }

            userAccountControl = new UserAccountControl((String) attr.get(USER_ACCOUNT_CONTROL).get());
        }

        @Getter
        public static class UserAccountControl {
            public static final int ACCOUNT_DISABLED = 2;
            public static final int PASSWD_CANT_CHANGE = 64;
            public static final int NORMAL_ENABLED = 512;
            public static final int NORMAL_DISABLED = 514;
            public static final int DONT_EXPIRE_PASSWORD = 65536;
            public static final int PASSWORD_EXPIRED = 8388608;

            private Integer value;
            private boolean canChangePassword = true;
            private boolean passwordExpired;
            private boolean accountDisabled;

            public UserAccountControl(String input) {
                value = Integer.parseInt(input);

                if (value == NORMAL_ENABLED + ACCOUNT_DISABLED
                        || value == NORMAL_ENABLED + DONT_EXPIRE_PASSWORD + ACCOUNT_DISABLED
                        || value == NORMAL_ENABLED + PASSWD_CANT_CHANGE + ACCOUNT_DISABLED
                        || value == NORMAL_ENABLED + PASSWD_CANT_CHANGE + ACCOUNT_DISABLED + PASSWORD_EXPIRED
                        || value == NORMAL_ENABLED + PASSWD_CANT_CHANGE + DONT_EXPIRE_PASSWORD + ACCOUNT_DISABLED)
                    accountDisabled = true;

                if (value == NORMAL_ENABLED + PASSWORD_EXPIRED
                        || value == NORMAL_ENABLED + PASSWORD_EXPIRED + ACCOUNT_DISABLED
                        || value == NORMAL_ENABLED + PASSWD_CANT_CHANGE + PASSWORD_EXPIRED
                        || value == NORMAL_ENABLED + PASSWD_CANT_CHANGE + ACCOUNT_DISABLED + PASSWORD_EXPIRED)
                    passwordExpired = true;

                if (value == NORMAL_ENABLED + PASSWD_CANT_CHANGE
                        || value == NORMAL_ENABLED + ACCOUNT_DISABLED + PASSWORD_EXPIRED
                        || value == NORMAL_ENABLED + ACCOUNT_DISABLED + PASSWD_CANT_CHANGE)
                    canChangePassword = false;
            }
        }

        @Override
        public String toString() {
            return getDistinguishedName();
        }

        /**
         * Used to change the user password. Throws an IOException if the Domain
         * Controller is not LDAPS enabled.
         */
        public void changePassword(String newPass, LdapContext context)
                throws java.io.IOException, NamingException {
            String dn = getDistinguishedName();

            //Change password
            try {
                ModificationItem[] modificationItems = new ModificationItem[1];
                modificationItems[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("unicodePwd", getPassword(newPass)));

                context.modifyAttributes(dn, modificationItems);
            } catch (javax.naming.directory.InvalidAttributeValueException e) {
                throw new NamingException("account.change-password.errors.requirements");
            } catch (NamingException e) {
                throw e;
            }
        }

        private static final HostnameVerifier DO_NOT_VERIFY = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        private static TrustManager[] TRUST_ALL_CERTS = new TrustManager[]{
                new X509TrustManager() {
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return null;
                    }

                    public void checkClientTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }

                    public void checkServerTrusted(
                            java.security.cert.X509Certificate[] certs, String authType) {
                    }
                }
        };

    }

    public static class PasswordExpiredException extends RuntimeException {

    }

    public static class PasswordMustBeChangedException extends RuntimeException {

    }

    public static class UserBlockedException extends RuntimeException {

    }
}
