package ru.adaptms.vwf.util.conversion.standard;

import org.springframework.stereotype.Component;
import ru.adaptms.vwf.util.conversion.ConversionType;

/**
 * @author ppolyakov at 04.01.2022 22:07
 */
@Component
public class StringConversion extends ConversionType {
    @Override
    public Class<?> getTargetClass() {
        return String.class;
    }

    @Override
    public Object doConvert( String input ) {
        return input;
    }
}
