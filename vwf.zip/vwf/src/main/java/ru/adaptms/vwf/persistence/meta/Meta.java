package ru.adaptms.vwf.persistence.meta;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author ppolyakov at 26.01.2022 00:11
 */
@Retention( RetentionPolicy.RUNTIME)
@Target( {ElementType.TYPE, ElementType.FIELD, ElementType.METHOD} )
public @interface Meta {
    String title();
    String comment() default "";
    boolean censored() default false;
    boolean ignoreChanges() default false;
}
