package ru.adaptms.vwf.util.reflections;

import org.reflections.Reflections;
import org.reflections.util.ConfigurationBuilder;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.SpringUtils;

import java.lang.annotation.Annotation;
import java.util.Set;

/**
 * @author polyakov_ps at 06.04.2023 13:04
 */
@Service
public class ReflectionsUtil {
    public static ReflectionsUtil instance() { return SpringUtils.getInstance( ReflectionsUtil.class ); }

    private Reflections cache;

    public <T> Set<Class<? extends T>> getSubclasses(Class<T> type) {
        return cache.getSubTypesOf( type );
    }

    public <T> Set<Class<?>> getWithAnnotation(Class<? extends Annotation> annotation) {
        return cache.getTypesAnnotatedWith( annotation );
    }

    public void load(String... roots) {
        cache = new Reflections( new ConfigurationBuilder().forPackages( roots ) );
    }

    public Reflections get() {
        return cache;
    }
}
