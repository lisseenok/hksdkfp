package ru.adaptms.vwf.ui.thymeleaf.processor.loader;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.component.tabpanel.TabPanel;
import ru.adaptms.vwf.ui.util.SpringELUtil;

import java.util.Locale;

/**
 * @author ppolyakov at 02.11.2023 21:04
 */
public class LoaderProcessor extends AbstractUITagProcessor {
    public static final String LISTENER_PARAM_TAB = TabPanel.LISTENER_PARAM;

    private static final String ELEMENT_NAME = "loader";
    private static final int PRECEDENCE = 1000;

    public LoaderProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        Type type;

        if (elementTag.hasAttribute("type"))
            type = Type.valueOf(elementTag.getAttributeValue("type").toUpperCase(Locale.ROOT));
        else
            type = Type.PROGRESS;

        if (elementTag.hasAttribute("id"))
            outgoingContext.setVariable("id", SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser));

        if (elementTag.hasAttribute("class"))
            outgoingContext.setVariable("class", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));

        if (elementTag.hasAttribute("style"))
            outgoingContext.setVariable("style", SpringELUtil.execute(elementTag.getAttributeValue("style"), incomingContext, parser));

        structureHandler.replaceWith(getTemplate(outgoingContext, "type_" + type.name()), false);
    }

    public enum Type {
        PROGRESS,
        SPINNER
    }

}
