package ru.adaptms.vwf.ui.component.grid;

import lombok.Getter;

import java.io.Serializable;
import java.util.List;

/**
 * Abstract parent of all list datasources
 *
 * @author ppolyakov at 27.01.2022 14:15
 */
public abstract class AbstractDataSource<TYPE> implements Serializable {

    @Getter
    protected List<TYPE> result; // result of preparing data (by any method)

    /**
     * Prepare and return current data
     * Should process it with current IOutputTransformation set in #transformOutput
     */
    public abstract List<TYPE> execute();

    /**
     * Set the interface that will process execution result for customization purposes
     */
    public void doTransformOutput(IOutputTransformation<TYPE> transformation) {
        result = transformation.transform(result);
    }

    /**
     * Info whether this datasource is pageable or not
     */
    public boolean isPageable() {
        return false; // by default = not pageable
    }

    /**
     * Info whether this datasource is sortable or not
     */
    public boolean isSortable() {
        return false; // by default = not sortable
    }

    /**
     * Interface that defines some processing of datasource result list
     */
    public interface IOutputTransformation<T> {
        List<T> transform(List<T> result);
    }
}
