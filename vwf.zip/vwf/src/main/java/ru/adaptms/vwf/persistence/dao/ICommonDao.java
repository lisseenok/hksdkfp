package ru.adaptms.vwf.persistence.dao;

import org.adaptms.hqlbuilder.builder.HQLBuilder;
import org.adaptms.hqlbuilder.property.EntityPath;
import ru.adaptms.vwf.persistence.entity.IEntity;
import ru.adaptms.vwf.persistence.entity.ISoftDeletable;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Стандартный DAO для всех необходимых операций
 *
 * @author polyakov_ps
 */
public interface ICommonDao extends IBaseDao {

    /**
     * Soft delete (set 'deleted' property) for entity
     * @param entity entity to soft delete
     * @param <T> type (extends {@link ISoftDeletable})
     */
    <T extends ISoftDeletable> T softDelete( T entity );

    <T extends IEntity, PK extends Serializable> void delete(Class<T> type, PK id);

    <T> T list( String hql, Map<String,Object> params, Class<T> expectedType );

    /**
     * Execute HQL query from string
     * @param hql query
     * @param params parameters that are mentioned in query
     * @param list expected result type (is a list?)
     * @param <T> expected result type
     * @return request result
     */
    <T> T list( String hql, Map<String,Object> params, boolean list );

    List<Object> list( String hql );

    <T> T executeHQL( String hql, boolean list );

    <T> T executeSelect( org.adaptms.hqlbuilder.builder.HQLBuilder builder, Class<T> expectedType );

    /**
     * Execute select from HQLBuilder
     * @param builder билдер
     * @param list is expected type a list
     * @param <T> type
     * @return builder execution result
     */
    <T> T executeSelect( org.adaptms.hqlbuilder.builder.HQLBuilder builder, boolean list );

    <T> int executeUpdate( HQLBuilder builder );

    /**
     * Get list by HQLBuilder
     * @param builder builder
     * @param <T> expected type (List)
     * @return resulting list
     */
    <T> List<T> list( org.adaptms.hqlbuilder.builder.HQLBuilder builder );

    long count( org.adaptms.hqlbuilder.builder.HQLBuilder builder, EntityPath countProperty );

    /**
     * Get paginated list from builder
     * @param builder builder
     * @param max maximum elements in result (rows on page)
     * @param offset offset of the first element (page number from 0)
     * @param <T> expected type (List)
     * @return resulting list
     */
    <T> List<T> list( org.adaptms.hqlbuilder.builder.HQLBuilder builder, int max, int offset );

    /**
     * Get first result by builder (useful when looking for unique rows)
     * @param builder builder
     * @param <T> expected type (singleton)
     * @return first found result
     */
    <T> T first( org.adaptms.hqlbuilder.builder.HQLBuilder builder );
}
