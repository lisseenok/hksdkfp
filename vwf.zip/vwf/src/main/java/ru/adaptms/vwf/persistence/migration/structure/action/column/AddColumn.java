package ru.adaptms.vwf.persistence.migration.structure.action.column;

import ru.adaptms.vwf.persistence.migration.structure.action.util.DBActionUtil;
import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;

/**
 * Добавление колонки в таблицу
 *
 * @author ppolyakov at 11.12.2021 18:47
 */
public class AddColumn extends MigrationAction {

    private String tableName;
    private DBTableColumn column;

    /**
     * @param tableName название таблицы, в которую будем добавлять колонку
     * @param columnToAdd дефиниция колонки
     */
    public AddColumn( String tableName, DBTableColumn columnToAdd ) {
        this.tableName = tableName;
        this.column = columnToAdd;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder();

        builder.append( "ALTER TABLE " )
                .append( tableName )
                .append( " ADD " );

        DBActionUtil.applyColumn( dbType, builder, column );

        return builder.toString();
    }
}
