package ru.adaptms.vwf.ui.component.grid;

/**
 * Grid column descriptor
 *
 * @author ppolyakov at 23.01.2022 00:35
 */
public class HeaderColumn {
    private String title; // visible title
    private String style; // additional styles may be applied

    public HeaderColumn() {
        title = "";
    }


    public HeaderColumn(String title) {
        this.title = title;
    }

    public HeaderColumn style(String style) {
        this.style = style;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

}
