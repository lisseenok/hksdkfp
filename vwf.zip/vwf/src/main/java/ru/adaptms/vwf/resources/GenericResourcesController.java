package ru.adaptms.vwf.resources;

import io.swagger.v3.oas.annotations.Hidden;
import org.apache.commons.io.IOUtils;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.util.UrlPathHelper;
import ru.adaptms.vwf.util.file.MimeTypeUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Standard handler for web resources that are located in /resources/public of the modules
 *
 * @author ppolyakov at 05.01.2022 03:46
 */
@Hidden
@Controller
public class GenericResourcesController {
    private Map<String, byte[]> registry = new HashMap<>();
    protected UrlPathHelper urlPathHelper = new UrlPathHelper();

    /**
     * Get resource by file name
     * @param request recieved HTTP request
     * @param response prepared HTTP response
     * @throws IOException
     */
    @GetMapping(value = "/resources/**")
    public void getResource(HttpServletRequest request,
                            HttpServletResponse response) throws IOException {
        String pathToResource = urlPathHelper.getPathWithinApplication(request).replace("/resources", "");
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(this.getClass().getClassLoader());

        byte[] bytes;
        if (registry.containsKey(pathToResource)) {
            bytes = registry.get(pathToResource);
        } else {
            Resource resource = resolver.getResource("classpath:/public" + pathToResource);
            if (resource.exists()) {
                bytes = resource.getInputStream().readAllBytes();
                registry.put(pathToResource, bytes);
            } else {
                // return correct status and break execution
                response.setStatus(404);
                return;
//                throw new FileNotFoundException( "Resource \"" + pathToResource + "\" not found." );
            }
        }

        String[] pathToResourceParts = pathToResource.split("/");
        response.setContentType(MimeTypeUtil.getMimeType(pathToResourceParts[pathToResourceParts.length - 1]));
        response.setContentLength(bytes.length);
        IOUtils.copy(new ByteArrayInputStream(bytes), response.getOutputStream());
    }
}
