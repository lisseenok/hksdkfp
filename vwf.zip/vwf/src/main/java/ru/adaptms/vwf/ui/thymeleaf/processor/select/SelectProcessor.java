package ru.adaptms.vwf.ui.thymeleaf.processor.select;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.vwf.ui.component.select.SimpleOption;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;

import java.util.Arrays;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class SelectProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "select";
    private static final int PRECEDENCE = 900;

    public SelectProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "id", "name")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        String type = elementTag.hasAttribute("type") ? elementTag.getAttributeValue("type") : "default";

        String id = (String) SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser);

        AbstractUIHandler handler = (AbstractUIHandler) incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE);
        if (handler != null) {
            id += "_" + handler.getHandlerId();
        }

        outgoingContext.setVariable("handler", handler);
        outgoingContext.setVariable("id", id);
        outgoingContext.setVariable("name", SpringELUtil.execute(elementTag.getAttributeValue("name"), incomingContext, parser));
        outgoingContext.setVariable("label", SpringELUtil.execute(elementTag.getAttributeValue("label"), incomingContext, parser));
        outgoingContext.setVariable("classes", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));
        outgoingContext.setVariable("styles", SpringELUtil.execute(elementTag.getAttributeValue("style"), incomingContext, parser));
        outgoingContext.setVariable("outerClasses", SpringELUtil.execute(elementTag.getAttributeValue("outerClasses"), incomingContext, parser));
        outgoingContext.setVariable("help", SpringELUtil.execute(elementTag.getAttributeValue("help"), incomingContext, parser));
        outgoingContext.setVariable("value", SpringELUtil.execute(elementTag.getAttributeValue("value"), incomingContext, parser));

        String formId = (String) SpringELUtil.execute(elementTag.getAttributeValue("form"), incomingContext, parser);
        if (!StringUtils.isBlank(formId) && handler != null)
            formId = formId + "_" + handler.getHandlerId();

        outgoingContext.setVariable("form", formId);

        outgoingContext.setVariable("optionExpression", SpringELUtil.execute(elementTag.getAttributeValue("optionExpression"), incomingContext, parser));
        outgoingContext.setVariable("optionProperty", SpringELUtil.execute(elementTag.getAttributeValue("optionProperty"), incomingContext, parser));
        outgoingContext.setVariable("valueExpression", SpringELUtil.execute(elementTag.getAttributeValue("valueExpression"), incomingContext, parser));
        outgoingContext.setVariable("valueProperty", SpringELUtil.execute(elementTag.getAttributeValue("valueProperty"), incomingContext, parser));
        outgoingContext.setVariable("disabledExpression", SpringELUtil.execute(elementTag.getAttributeValue("disabledExpression"), incomingContext, parser));
        outgoingContext.setVariable("disabledProperty", SpringELUtil.execute(elementTag.getAttributeValue("disabledProperty"), incomingContext, parser));
        outgoingContext.setVariable("emptyOption", SpringELUtil.execute(elementTag.getAttributeValue("emptyOption"), incomingContext, parser));
        if (elementTag.hasAttribute("source")) {
            if (elementTag.getAttributeValue("source").startsWith("literal:")) {
                String[] opts = elementTag.getAttributeValue("source").replace("literal:", "").split(",");
                outgoingContext.setVariable("source", Arrays.stream(opts).map(opt -> new SimpleOption(opt, opt)).collect(Collectors.toList()));
                outgoingContext.setVariable("valueProperty", "id");
                outgoingContext.setVariable("optionProperty", "value");
            } else {
                outgoingContext.setVariable("source", SpringELUtil.execute(elementTag.getAttributeValue("source"), incomingContext, parser));
            }
        }

        String autoSubmitFormId = (String) SpringELUtil.execute(elementTag.getAttributeValue("autoSubmit"), incomingContext, parser);
        if (!StringUtils.isBlank(autoSubmitFormId) && handler != null)
            autoSubmitFormId = autoSubmitFormId + "_" + handler.getHandlerId();

        outgoingContext.setVariable("autoSubmit", autoSubmitFormId);

        if (elementTag.hasAttribute("search")) {
            outgoingContext.setVariable("search", SpringELUtil.execute(elementTag.getAttributeValue("search"), incomingContext, parser));
        } else if (elementTag.hasAttribute("searchListener") && handler != null) {
            AbstractUIHandler topLevelHandler = handler;
            while (topLevelHandler.getParent() != null) {
                topLevelHandler = topLevelHandler.getParent();
            }

            UriBuilder builder = UriBuilder.create(MappingRegistry.instance().getMetaByClass(topLevelHandler.getClass()).getMapping(), true);
            builder.parameter(AbstractUIHandler.PARAM_DS, handler.getHandlerId() + "."
                    + SpringELUtil.execute(elementTag.getAttributeValue("searchListener"), incomingContext, parser));

            Map<String, String> importantParameters = HandlerUtil.getIdentifyingParams(topLevelHandler.getParameters());
            for (Map.Entry<String, String> entry : importantParameters.entrySet()) {
                builder.parameter(entry.getKey(), entry.getValue());
            }

            ProcessorHelper.applyParams(builder, elementTag.getAttributeMap(), incomingContext, parser, null);

            outgoingContext.setVariable("search", builder.build());
        }

        Object required = SpringELUtil.execute(elementTag.getAttributeValue("required"), incomingContext, parser);
        outgoingContext.setVariable("required", elementTag.hasAttribute("required")
                && (elementTag.getAttributeValue("required") == null
                || ("true".equals(required) || "required".equals(required))
                || (required instanceof Boolean && (boolean) required)));

        String asterisk = (String) SpringELUtil.execute(elementTag.getAttributeValue("asterisk"), incomingContext, parser);
        if (StringUtils.isBlank(asterisk)) asterisk = "REQUIRED";
        outgoingContext.setVariable("asterisk", asterisk.toUpperCase(Locale.ROOT));

        applyBooleanField(outgoingContext, elementTag, "disabled", SpringELUtil.execute(elementTag.getAttributeValue("disabled"), incomingContext, parser));
        applyBooleanField(outgoingContext, elementTag, "multiple", SpringELUtil.execute(elementTag.getAttributeValue("multiple"), incomingContext, parser));
        applyBooleanField(outgoingContext, elementTag, "noMarginBottom", SpringELUtil.execute(elementTag.getAttributeValue("noMarginBottom"), incomingContext, parser));

        // add variables to context
        for (Map.Entry<String, String> attr : elementTag.getAttributeMap().entrySet()) {
            if (!attr.getKey().startsWith("ctx:")) continue;

            outgoingContext.setVariable(attr.getKey().replace("ctx:", ""), SpringELUtil.execute(attr.getValue(), incomingContext, parser));
        }

        structureHandler.replaceWith(getTemplate(outgoingContext, type), false);
    }
}
