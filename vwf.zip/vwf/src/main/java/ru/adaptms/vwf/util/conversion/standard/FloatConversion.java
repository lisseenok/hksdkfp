package ru.adaptms.vwf.util.conversion.standard;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.adaptms.vwf.util.conversion.ConversionType;

/**
 * @author ppolyakov at 04.01.2022 22:07
 */
@Component
public class FloatConversion extends ConversionType {
    @Override
    public Class<?> getTargetClass() {
        return float.class;
    }

    @Override
    public Object doConvert( String input ) {
        if ( StringUtils.isBlank( input ) )
            return 0f;
        return Float.parseFloat( input );
    }
}
