package ru.adaptms.vwf.ui.search;

import java.io.Serializable;

/**
 * @author ppolyakov at 21.01.2022 03:03
 */
public class ResultElement implements Serializable {
    private String id;
    private String text;

    public ResultElement( Object id, String text ) {
        this.id = id instanceof String ? ( String ) id : String.valueOf( id );
        this.text = text;
    }

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText( String text ) {
        this.text = text;
    }
}
