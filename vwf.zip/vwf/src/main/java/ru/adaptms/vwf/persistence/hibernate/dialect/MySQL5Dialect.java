package ru.adaptms.vwf.persistence.hibernate.dialect;

//import org.hibernate.dialect.MySQLDialect;

/**
 * @author ppolyakov at 03.10.2021 23:47
 */
//MySQLDialect
public class MySQL5Dialect extends org.hibernate.dialect.MySQLDialect {
    /*public MySQL5Dialect() {
        super( 500 );
    }*/
}
