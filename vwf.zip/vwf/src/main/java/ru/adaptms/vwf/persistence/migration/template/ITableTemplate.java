package ru.adaptms.vwf.persistence.migration.template;

import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;

import java.util.List;

/**
 * @author ppolyakov at 05.12.2021 15:27
 */
public interface ITableTemplate {

    List<DBTableColumn> getColumns();

}
