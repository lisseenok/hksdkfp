package ru.adaptms.vwf.util.encryption;

import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.SpringUtils;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

/**
 * @author ppolyakov at 30.01.2022 02:30
 */
@Service
public class EncryptionUtil {
    public static EncryptionUtil instance() {
        return SpringUtils.getInstance(EncryptionUtil.class);
    }

    private static final String CIPHER_KEY = "_674kf-AE-sy259_";

    public String encryptString(String source, String key) {
        if (source == null) return null;
        try {
            Cipher aes = Cipher.getInstance("AES/ECB/PKCS5Padding");
            aes.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES"));
            byte[] encryptedParams = aes.doFinal(source.getBytes());
            return Base64.encodeBase64URLSafeString(encryptedParams);
        } catch (NoSuchPaddingException | IllegalBlockSizeException | NoSuchAlgorithmException | BadPaddingException |
                 InvalidKeyException e) {
            LoggingUtil.error(EncryptionUtil.class, "Cannot encrypt parameters.", e);
            throw new IllegalStateException(e);
        }
    }

    public String encryptString(String source) {
        return encryptString(source, CIPHER_KEY);
    }

    public String decryptString(String source, String key) {
        if (source == null) return null;
        try {
            Cipher aes = Cipher.getInstance("AES/ECB/PKCS5Padding");
            aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key.getBytes(StandardCharsets.UTF_8), "AES"));
            return new String(aes.doFinal(Base64.decodeBase64(source)));
        } catch (NoSuchPaddingException | IllegalBlockSizeException | NoSuchAlgorithmException | BadPaddingException |
                 InvalidKeyException e) {
            LoggingUtil.error(EncryptionUtil.class, "Cannot decrypt parameters.", e);
            throw new IllegalStateException(e);
        }
    }

    public String decryptString(String source) {
        return decryptString(source, CIPHER_KEY);
    }
}
