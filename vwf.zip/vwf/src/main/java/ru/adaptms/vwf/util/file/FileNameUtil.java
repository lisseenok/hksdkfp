package ru.adaptms.vwf.util.file;

import com.ibm.icu.text.Transliterator;

public class FileNameUtil {
    private static String LATIN_TO_CYRILLIC = "Latin-Russian/BGN";
    private static String CYRILLIC_TO_LATIN = "Russian-Latin/BGN";

    public static String transliterateRuEn( String source ) {
        Transliterator transliterator = Transliterator.getInstance( CYRILLIC_TO_LATIN );
        return transliterator.transliterate( source );
    }

    public static String transliterateEnRu( String source ) {
        Transliterator transliterator = Transliterator.getInstance( LATIN_TO_CYRILLIC );
        return transliterator.transliterate( source );
    }
}
