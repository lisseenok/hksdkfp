package ru.adaptms.vwf.ui.component.tabpanel;

/**
 * @author ppolyakov at 17.03.2022 15:05
 */
public class SpelTab extends TextTab {
    public SpelTab() {
    }

    public SpelTab( String id, String label, int order ) {
        super( id, label, order );
    }

    @Override
    public boolean isSpel() {
        return true;
    }
}
