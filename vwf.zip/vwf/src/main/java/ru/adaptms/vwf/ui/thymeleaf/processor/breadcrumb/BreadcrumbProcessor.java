package ru.adaptms.vwf.ui.thymeleaf.processor.breadcrumb;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.vwf.ui.component.breadcrumb.Breadcrumb;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.util.SpringELUtil;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class BreadcrumbProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "breadcrumb";
    private static final int PRECEDENCE = 1000;

    public BreadcrumbProcessor( String dialectPrefix ) {
        super( dialectPrefix, ELEMENT_NAME, PRECEDENCE );
    }

    @Override
    protected void doProcess( ITemplateContext incomingContext,
                              IProcessableElementTag elementTag,
                              IElementTagStructureHandler structureHandler ) {
        if ( !requireAttributes( elementTag, structureHandler, "source" ) ) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser( incomingContext );

        Breadcrumb breadcrumb = ( Breadcrumb ) SpringELUtil.execute( elementTag.getAttributeValue( "source" ), incomingContext, parser );
        outgoingContext.setVariable( "breadcrumb", breadcrumb );

        outgoingContext.setVariable( AbstractUIHandler.HANDLER_VARIABLE, incomingContext.getVariable( AbstractUIHandler.HANDLER_VARIABLE ) );

        structureHandler.replaceWith( getTemplate( outgoingContext ), false );
    }
}
