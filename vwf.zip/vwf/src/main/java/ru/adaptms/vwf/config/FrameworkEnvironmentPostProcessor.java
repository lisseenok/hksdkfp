package ru.adaptms.vwf.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import ru.adaptms.vwf.persistence.migration.version.PlatformVersion;
import ru.adaptms.vwf.project.ProjectMeta;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Environment post-processing to read properties
 */
public class FrameworkEnvironmentPostProcessor implements EnvironmentPostProcessor {

    @Override
    public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
        try {
            ProjectMeta.init();

            var applicationProperties = new Properties();
            try (InputStream fileStream = getClass().getClassLoader().getResourceAsStream("application.properties")) {
                applicationProperties.load(fileStream);
            } catch (IOException e) {
                throw new IllegalStateException(e);
            }

            var applicationPropertySource = new PropertiesPropertySource("application-properties", applicationProperties);
            environment.getPropertySources().addLast(applicationPropertySource);

            var jvmConfigProperty = ProjectMeta.getJvmConfigPathProperty();
            if (StringUtils.isBlank(jvmConfigProperty))
                jvmConfigProperty = applicationProperties.getProperty("jvm.config.property"); // fall back to default

            var filePath = System.getProperty(jvmConfigProperty);
            if (!filePath.endsWith("/")) filePath += "/";

            var dbConfigFilePath = filePath + "db.properties";
            var dbPropertyResource = new FileSystemResource(dbConfigFilePath);
            var dbProperties = PropertiesLoaderUtils.loadProperties(dbPropertyResource);
            var dbPropertySource = new PropertiesPropertySource("db-properties", dbProperties);
            environment.getPropertySources().addLast(dbPropertySource);

            var appConfigFilePath = filePath + "app.properties";
            var appPropertyResource = new FileSystemResource(appConfigFilePath);
            var appProperties = PropertiesLoaderUtils.loadProperties(appPropertyResource);
            var appPropertySource = new PropertiesPropertySource("app-properties", appProperties);
            environment.getPropertySources().addLast(appPropertySource);


            AppDefines.set(AppDefines.CONFIG_PATH_PROPERTY, jvmConfigProperty);
            AppDefines.set(AppDefines.APP_MODE, appProperties.containsKey(AppDefines.APP_MODE) ? appProperties.getProperty(AppDefines.APP_MODE) : "production");
            AppDefines.set(AppDefines.LOG_LEVEL, appProperties.containsKey(AppDefines.LOG_LEVEL) ? appProperties.getProperty(AppDefines.LOG_LEVEL) : (AppDefines.isDebug() ? LoggingUtil.LEVEL_DEBUG : LoggingUtil.LEVEL_ERROR));
            AppDefines.set(AppDefines.HANDLER_LIFE, Integer.parseInt(String.valueOf(appProperties.getOrDefault("quickui.handler.life", "30"))));

            if (applicationProperties.containsKey("vwf.locale"))
                AppDefines.set(AppDefines.FIXED_LOCALE, applicationProperties.getProperty("vwf.locale"));

            AppDefines.set(AppDefines.APP_PROPERTIES, appProperties);

            AppDefines.set(AppDefines.STORAGE_PATH, appProperties.getOrDefault("storage.path", filePath + File.separator + "storage"));
            AppDefines.set(AppDefines.MINIO_ACCESS_KEY, appProperties.get("minio.access-key"));
            AppDefines.set(AppDefines.MINIO_SECRET_KEY, appProperties.get("minio.secret-key"));
            AppDefines.set(AppDefines.AUTH_SECRET_KEY, appProperties.get("auth.secret-key"));
            AppDefines.set(AppDefines.MINIO_BUCKET, appProperties.get("minio.bucket"));
            AppDefines.set(AppDefines.NAVBAR_LOGO_URL, appProperties.get("navbar.logo.url"));
            AppDefines.set(AppDefines.NAVBAR_FAVICON_URL, appProperties.get("navbar.favicon.url"));
            AppDefines.set(AppDefines.NAVBAR_ADDITIONAL_TEXT, appProperties.get("navbar.additional-text"));
            AppDefines.set(AppDefines.BASE_URL, appProperties.get("base.url"));
            AppDefines.set(AppDefines.GELF_HOST, appProperties.get("gelf.host"));
            AppDefines.set(AppDefines.GELF_PORT, appProperties.get("gelf.port"));
            AppDefines.set(AppDefines.APP_NAME, appProperties.get("app.name"));
            AppDefines.set(AppDefines.KAFKA_URL, appProperties.get("kafka.url"));

            AppDefines.set(AppDefines.VERSION, new PlatformVersion(applicationProperties.getProperty("app.version"), false));

        } catch (IOException e) {
            throw new RuntimeException("Failed to load properties from ", e);
        }
    }
}

