package ru.adaptms.vwf.ui.i18n;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import ru.adaptms.vwf.ui.i18n.xml.MessagesNode;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * @author ppolyakov at 24.01.2022 22:47
 */
public class XmlMessageSource implements MessageSource {

    private Map<String, MessageDefinition> messages = new HashMap<>();

    public XmlMessageSource() {
        try {
            LoggingUtil.debug(XmlMessageSource.class, "Starting messages initialization...");

            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(this.getClass().getClassLoader());
            Resource[] resources = resolver.getResources("classpath*:/**/*Messages.xml");

            LoggingUtil.debug(XmlMessageSource.class, String.format("    Found %d Message Sources.", resources.length));

            for (Resource resource : resources) {
                InputStream is = resource.getInputStream();
                JAXBContext context = JAXBContext.newInstance(MessagesNode.class);
                System.setProperty("javax.xml.accessExternalDTD", "all");
                Unmarshaller unmarshaller = context.createUnmarshaller();
                MessagesNode messagesNode = (MessagesNode) unmarshaller.unmarshal(is);

                I18NService.processMessagesNode(this.messages, messagesNode, null);
            }

            LoggingUtil.debug(XmlMessageSource.class, "Done.");
        } catch (IOException | JAXBException ioe) {
            LoggingUtil.error(XmlMessageSource.class, ioe);
            throw new IllegalStateException("Couldn't initialize messages, " + ioe.getClass().getSimpleName() + ": " + ExceptionUtils.getMessage(ioe), ioe);
        }
    }

    @Override
    public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
        MessageDefinition definition = messages.get(code);
        if (definition == null)
            return defaultMessage;

        return AppDefines.get(AppDefines.FIXED_LOCALE) == null ? definition.getTranslation(locale.getLanguage()) : definition.getTranslation((String) AppDefines.get(AppDefines.FIXED_LOCALE));
    }

    @Override
    public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
        MessageDefinition definition = messages.get(code);
        if (definition == null)
            return null;

        return AppDefines.get(AppDefines.FIXED_LOCALE) == null ? definition.getTranslation(locale.getLanguage()) : definition.getTranslation((String) AppDefines.get(AppDefines.FIXED_LOCALE));
    }

    @Override
    public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException {
        return null;
    }

    public Map<String, MessageDefinition> getMessages() {
        return messages;
    }
}
