package ru.adaptms.vwf.swagger;

import io.swagger.v3.oas.annotations.Hidden;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.util.UrlPathHelper;
import ru.adaptms.vwf.util.file.MimeTypeUtil;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Standard handler for web resources that are located in /resources/public of the modules
 *
 * @author ppolyakov at 05.01.2022 03:46
 */
@Hidden
@Controller
public class SwaggerController {
    @Value("#{servletContext.contextPath}")
    private String servletContextPath;

    private Map<String, byte[]> registry = new HashMap<>();
    protected UrlPathHelper urlPathHelper = new UrlPathHelper();

    /**
     * Get swagger file
     * @param request recieved HTTP request
     * @param response prepared HTTP response
     * @throws IOException
     */
    @GetMapping(value = {"/swagger-ui", "/swagger-ui/**"})
    public void getResource(HttpServletRequest request,
                            HttpServletResponse response) throws IOException {
        String pathToResource = urlPathHelper.getPathWithinApplication(request)
                .replace("/swagger-ui/", "");

        if (StringUtils.isBlank(pathToResource)
                || "/swagger-ui".equals(pathToResource))
            pathToResource = "index.html";

        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(this.getClass().getClassLoader());

        byte[] bytes;
        if (registry.containsKey(pathToResource)) {
            bytes = registry.get(pathToResource);
        } else {
            Resource resource = resolver.getResource("classpath:/META-INF/resources/webjars/swagger-ui/5.13.0/" + pathToResource);
            if (resource.exists()) {
                bytes = resource.getInputStream().readAllBytes();

                if ("swagger-initializer.js".equals(pathToResource)) {
                    var uri = servletContextPath != null ? servletContextPath : "";

                    if (!uri.endsWith("/"))
                        uri += "/";

                    uri += "v3/api-docs";

                    // replace with another file
                    bytes = """
window.onload = function() {
  window.ui = SwaggerUIBundle({
    url: "%s",
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout"
  });
};""".formatted(uri).getBytes(StandardCharsets.UTF_8);
                }

                registry.put(pathToResource, bytes);
            } else {
                // return correct status and break execution
                response.setStatus(404);
                return;
            }
        }

        String[] pathToResourceParts = pathToResource.split("/");
        response.setContentType(MimeTypeUtil.getMimeType(pathToResourceParts[pathToResourceParts.length - 1]));
        response.setContentLength(bytes.length);
        IOUtils.copy(new ByteArrayInputStream(bytes), response.getOutputStream());
    }
}
