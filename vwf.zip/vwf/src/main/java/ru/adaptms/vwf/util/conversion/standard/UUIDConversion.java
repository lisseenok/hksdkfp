package ru.adaptms.vwf.util.conversion.standard;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.adaptms.vwf.util.conversion.ConversionType;

import java.util.UUID;

/**
 * @author ppolyakov at 09.02.2025 22:07
 */
@Component
public class UUIDConversion extends ConversionType {
    @Override
    public Class<?> getTargetClass() {
        return UUID.class;
    }

    @Override
    public Object doConvert(String input) {
        if (StringUtils.isBlank(input))
            return null;
        return UUID.fromString(input);
    }
}
