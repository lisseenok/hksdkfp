package ru.adaptms.vwf.ui.component.select;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author ppolyakov at 22.01.2022 22:29
 */
public class SimpleOption implements Serializable {
    private String id;
    private String value;

    public SimpleOption( Object id, String displayedName ) {
        this.id = id instanceof String ? ( String ) id : String.valueOf( id );
        this.value = displayedName;
    }

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public String getValue() {
        return value;
    }

    public void setValue( String value ) {
        this.value = value;
    }

    public String getDisplayedName() {
        return getValue();
    }

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof SimpleOption ) ) return false;
        SimpleOption that = ( SimpleOption ) o;
        return Objects.equals( getId(), that.getId() );
    }

    @Override
    public int hashCode() {
        return Objects.hash( getId() );
    }

    @Override
    public String toString() {
        return value;
    }
}
