package ru.adaptms.vwf.persistence.entity;

/**
 * @author ppolyakov at 28.11.2021 16:37
 */
public class SimpleIdentifiable implements IIdentifiable {
    private Long id;

    public SimpleIdentifiable( long id ) {
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }
}
