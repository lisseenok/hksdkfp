package ru.adaptms.vwf.ui.action.success;

/**
 * Close the modal (only one modal can be open so no identifier required)
 *
 * @author ppolyakov at 03.02.2022 01:46
 */
public class SuccessCloseModal implements ISuccessAction {
    @Override
    public String getAction() {
        return "closeModal";
    }
}
