package ru.adaptms.vwf.persistence.meta;

import lombok.Getter;
import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.persistence.entity.IEntity;
import ru.adaptms.vwf.persistence.entity.listener.EntityEventListener;
import ru.adaptms.vwf.persistence.entity.listener.EventType;
import ru.adaptms.vwf.persistence.entity.listener.SuppressEntityEventListener;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * @author ppolyakov at 13.04.2022 18:24
 */
public class EntityMeta {

    @Getter
    private final Class<? extends BaseEntity> entityClass;
    @Getter
    private final String name;
    @Getter
    private final String tableName;
    @Getter
    private String title;
    @Getter
    private String comment;

    @Getter
    private final List<EntityFieldMeta> fields = new ArrayList<>();
    @Getter
    private final List<IncomingReference> incomingReferences = new ArrayList<>();

    @Getter
    private final Map<String, List<Method>> eventListeners = new HashMap<>();

    public EntityMeta(Class<? extends BaseEntity> entityClass, List<IncomingReference> references) {
        this.entityClass = entityClass;
        this.name = entityClass.getSimpleName().substring(0, 1).toLowerCase(Locale.ROOT) + entityClass.getSimpleName().substring(1);
        this.tableName = entityClass.getAnnotation(Table.class).name();
        if (entityClass.isAnnotationPresent(Meta.class)) {
            this.title = entityClass.getAnnotation(Meta.class).title();
            this.comment = entityClass.getAnnotation(Meta.class).comment();
        }

        registerFields(entityClass, references);
        registerMethods(entityClass);
    }

    private void registerFields(Class<?> entityClass, List<IncomingReference> references) {
        if (entityClass != BaseEntity.class && entityClass.getSuperclass() != null)
            registerFields(entityClass.getSuperclass(), references);

        for (Field field : entityClass.getDeclaredFields()) {
            int modifiers = field.getModifiers();
            if (field.isSynthetic() || Modifier.isStatic(modifiers)) continue;

            this.fields.add(new EntityFieldMeta(field));

            if (IEntity.class.isAssignableFrom(field.getType())
                    && (field.isAnnotationPresent(ManyToOne.class)
                    || (field.isAnnotationPresent(OneToOne.class)
                    && "".equals(field.getAnnotation(OneToOne.class).mappedBy())))) {
                references.add(new IncomingReference(field.getName(), (Class<? extends BaseEntity>) field.getType(), this));
            }
        }
    }

    private void registerMethods(Class<?> entityClass) {
        if (entityClass != BaseEntity.class && entityClass.getSuperclass() != null)
            registerMethods(entityClass.getSuperclass());

        for (Method method : entityClass.getDeclaredMethods()) {
            if (method.isAnnotationPresent(EntityEventListener.class)) {
                // skip listener if it's defined as suppressed
                if (entityClass.isAnnotationPresent(SuppressEntityEventListener.class)
                        && Arrays.stream(entityClass.getAnnotation(SuppressEntityEventListener.class).value())
                        .anyMatch(s -> s.equals(method.getName())))
                    continue;

                EventType[] eventTypes = method.getAnnotation(EntityEventListener.class).value();

                for (EventType eventType : eventTypes) {
                    eventListeners.computeIfAbsent(eventType.name(), k -> new ArrayList<>());
                    eventListeners.get(eventType.name()).add(method);
                }
            }
        }
    }
}
