package ru.adaptms.vwf.ui.action.success;

import ru.adaptms.vwf.ui.util.uri.UriBuilder;
import ru.adaptms.vwf.ui.util.uri.UriUtil;
import ru.adaptms.vwf.util.SpringUtils;

/**
 * Redirect to another address within application
 *
 * @author ppolyakov at 07.01.2022 00:54
 */
public class SuccessRedirect implements ISuccessAction {
    private final UriUtil uriUtil = ( UriUtil ) SpringUtils.getBeanByName( "uriUtil" );

    private String uri;

    public SuccessRedirect( UriBuilder uriBuilder ) {
        this.uri = uriBuilder.build();
    }

    public SuccessRedirect( String uri ) {
        this.uri = uriUtil.prependContextPath( uri );
    }

    public String getUri() {
        return uri;
    }

    public void setUri( String uri ) {
        this.uri = uri;
    }

    @Override
    public String getAction() {
        return "redirect";
    }
}
