package ru.adaptms.vwf.ui.action.success;

/**
 * Action that is performed on front-end after listener on handler was executed
 *
 * @author ppolyakov at 07.01.2022 00:51
 */
public interface ISuccessAction {

    /**
     * Identifier of an action. JS frontend must recognize it (in success cascade)
     * @return action identifier
     */
    String getAction();
}
