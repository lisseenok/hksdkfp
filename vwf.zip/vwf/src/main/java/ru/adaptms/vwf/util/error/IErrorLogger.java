package ru.adaptms.vwf.util.error;

/**
 * @author ppolyakov at 22.06.2022 00:11
 */
public interface IErrorLogger {
    void logError( String source, Throwable throwable );
}
