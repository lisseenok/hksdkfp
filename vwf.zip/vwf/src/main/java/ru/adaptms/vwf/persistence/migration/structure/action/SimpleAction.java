package ru.adaptms.vwf.persistence.migration.structure.action;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;

import java.sql.Connection;

/**
 * @author ppolyakov at 26.01.2022 00:43
 */
public class SimpleAction extends MigrationAction {

    ActionDefinition action;

    public SimpleAction( ActionDefinition action ) {
        this.action = action;
    }

    public void execute( Connection connection ) {
        action.execute( connection );
    }

    @Override
    public String generateSQL( String dbType ) {
        return null;
    }

    public interface ActionDefinition {
        void execute( Connection connection );
    }
}
