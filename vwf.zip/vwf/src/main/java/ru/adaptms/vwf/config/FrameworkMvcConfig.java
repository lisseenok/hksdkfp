package ru.adaptms.vwf.config;

import jakarta.servlet.MultipartConfigElement;
import nz.net.ultraq.thymeleaf.layoutdialect.LayoutDialect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.web.firewall.HttpStatusRequestRejectedHandler;
import org.springframework.security.web.firewall.RequestRejectedHandler;
import org.springframework.util.unit.DataSize;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.extras.springsecurity5.dialect.SpringSecurityDialect;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import ru.adaptms.quickui.thymeleaf.dialect.ExpressionDialect;
import ru.adaptms.quickui.thymeleaf.resolver.InMemoryStringTemplateResolver;
import ru.adaptms.quickui.util.ThymeleafErrorFilter;
import ru.adaptms.vwf.persistence.migration.MigrationService;
import ru.adaptms.vwf.project.ProjectMeta;
import ru.adaptms.vwf.ui.i18n.XmlMessageSource;
import ru.adaptms.vwf.ui.thymeleaf.dialect.AbstractUIDialect;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.util.List;
import java.util.Set;

/**
 * Базовая конфигурация Spring контекста MVC-приложения
 */
@Configuration("framework_springConfig")
@EnableScheduling
@EnableCaching
@EnableMethodSecurity(securedEnabled = true)
@DependsOn("framework_persistenceConfig")
public class FrameworkMvcConfig implements WebMvcConfigurer {

    private List<HandlerInterceptor> interceptors;

    public FrameworkMvcConfig(ReflectionsUtil reflectionsUtil, @Autowired MigrationService migrationService) {
        // set up correct resource loading for Spring Boot running
        try {
            org.apache.catalina.webresources.TomcatURLStreamHandlerFactory.getInstance();
        } catch (Exception e) {
        }

        reflectionsUtil.load(ProjectMeta.reflectionsRoots.toArray(new String[0]));
        migrationService.migrate();
    }

    /**
     * @return Шаблонизатор для формирования представлений (Thymeleaf)
     */
    @Bean
    public SpringTemplateEngine templateEngine() {
        var templateEngine = new SpringTemplateEngine();
        templateEngine.addTemplateResolver(thymeleafTemplateResolver());
        templateEngine.addTemplateResolver(inMemoryTemplateResolver());
        templateEngine.addDialect(new LayoutDialect());
        templateEngine.addDialect(new SpringSecurityDialect());
        templateEngine.addDialect(new ExpressionDialect());

        Set<Class<? extends AbstractUIDialect>> dialects = ReflectionsUtil.instance().getSubclasses(AbstractUIDialect.class);
        if (dialects != null) {
            for (Class<? extends AbstractUIDialect> dialect : dialects) {
                try {
                    templateEngine.addDialect(dialect.getConstructor().newInstance());
                } catch (Exception e) {
                    LoggingUtil.error(FrameworkMvcConfig.class, "Couldn't add dialect \"" + dialect.getSimpleName() + "\"", e);
                }
            }
        }

        return templateEngine;
    }

    /**
     * @return Default class loader Thymeleaf template resolver
     */
    @Bean
    public ClassLoaderTemplateResolver thymeleafTemplateResolver() {
        var templateResolver = new ClassLoaderTemplateResolver();
        templateResolver.setSuffix(".html");
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setCharacterEncoding("UTF-8");
        templateResolver.setCheckExistence(true);
        return templateResolver;
    }

    /**
     * @return In-memory template resolver for dynamic handler template addition
     */
    @Bean
    public InMemoryStringTemplateResolver inMemoryTemplateResolver() {
        var templateResolver = new InMemoryStringTemplateResolver();
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setCharacterEncoding("UTF-8");
        templateResolver.setCheckExistence(true);

        if (AppDefines.isDebug()) templateResolver.setCacheable(false);

        return templateResolver;
    }

    /**
     * @return Multipart request configuration
     */
    @Bean
    public MultipartConfigElement multipartConfigElement() {
        var factory = new MultipartConfigFactory();
        factory.setMaxFileSize(DataSize.ofMegabytes(15L)); // максимальный размер одного файла 15 Мб (в мультипарт-запросах!)
        factory.setMaxRequestSize(DataSize.ofMegabytes(100L)); // максимальный суммарный размер запроса 100 Мб
        return factory.createMultipartConfig();
    }

    @Bean
    public FilterRegistrationBean thymeleafErrorFilter() {
        var thymeleafErrorFilter = new FilterRegistrationBean();
        thymeleafErrorFilter.setName("thymeleafErrorFilter");
        thymeleafErrorFilter.setFilter(new ThymeleafErrorFilter());
        thymeleafErrorFilter.addUrlPatterns("/*");
        return thymeleafErrorFilter;
    }

    @Bean
    public RequestRejectedHandler requestRejectedHandler() {
        return new HttpStatusRequestRejectedHandler();
    }

    /**
     * Registering of interceptors
     *
     * @param registry automatically passed to Spring
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        for (HandlerInterceptor interceptor : interceptors) {
            registry.addInterceptor(interceptor);
        }
    }

    @Bean
    public MessageSource messageSource() {
        return new XmlMessageSource();
    }

    /*@Override //CORS - в данном варианте запрещаем
    public void addCorsMappings( CorsRegistry registry ) {
        registry.addMapping("/**")
                .allowedMethods("HEAD", "GET", "PUT", "POST", "DELETE", "PATCH");
    }*/

    @Bean
    public ThreadPoolTaskScheduler threadPoolTaskScheduler() {
        ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
        threadPoolTaskScheduler.setPoolSize(20);
        threadPoolTaskScheduler.setThreadNamePrefix("ThreadPoolTaskScheduler");
        return threadPoolTaskScheduler;
    }

    @Autowired(required = false)
    public void setInterceptors(List<HandlerInterceptor> interceptors) {
        this.interceptors = interceptors;
    }
}
