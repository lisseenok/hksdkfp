package ru.adaptms.vwf.ui.util.uri;

import lombok.Getter;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 21.02.2022 16:04
 */
public class UriBuilder implements Serializable {

    private String baseUri;
    private boolean prepend;
    @Getter private Map<String, String> parameters = new HashMap<>();

    public UriBuilder() {
    }

    public UriBuilder( String baseUri, boolean prepend ) {
        this.baseUri = baseUri;
        this.prepend = prepend;
    }

    public static UriBuilder create( String baseUri, boolean prepend ) {
        return new UriBuilder( baseUri, prepend );
    }

    public UriBuilder parameter( String name, Object value ) {
        parameters.put( name, value instanceof String strValue ? strValue : value.toString() );
        return this;
    }

    public String build() {
        if ( !parameters.isEmpty() ) {
            List<String> parameterEntries = new ArrayList<>();
            for ( Map.Entry<String, String> entry : parameters.entrySet() ) {
                parameterEntries.add( entry.getKey() + "=" + entry.getValue() );
            }
            baseUri = wrap( baseUri );
            baseUri += "?" + String.join( "&", parameterEntries );
        }

        if ( prepend )
            return UriUtil.instance().prependContextPath( baseUri );
        else
            return baseUri;
    }

    public static String wrap( String uri ) {
        return !uri.startsWith( "/" ) ? "/" + uri : uri;
    }
}
