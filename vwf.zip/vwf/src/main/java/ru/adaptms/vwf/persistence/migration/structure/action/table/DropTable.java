package ru.adaptms.vwf.persistence.migration.structure.action.table;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;

/**
 * Удалить таблицу
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropTable extends MigrationAction {

    private String tableName;

    /**
     * @param tableName имя таблицы, которую надо удалить
     */
    public DropTable( String tableName ) {
        this.tableName = tableName;
    }

    @Override
    public String generateSQL( String dbType ) {
        return "DROP TABLE IF EXISTS " + tableName;
    }
}
