package ru.adaptms.vwf.persistence.migration.structure.action.table;

import ru.adaptms.vwf.persistence.migration.structure.action.util.DBActionUtil;
import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTable;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;
import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;
import ru.adaptms.vwf.persistence.migration.types.DBType;

import java.util.ArrayList;
import java.util.List;

/**
 * Создать таблицу
 *
 * @author ppolyakov at 05.12.2021 16:17
 */
public class CreateTable extends MigrationAction {

    private DBTable table;

    /**
     * @param table дефиниция создаваемой таблицы
     */
    public CreateTable( DBTable table ) {
        this.table = table;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder( "CREATE TABLE " );
        builder.append( table.getName() )
                .append( " (" );

        String primaryKeyMySQL = null;
        List<DBConstraint> constraints = new ArrayList<>();

        // работаем с каждой колонкой
        for ( DBTableColumn column : table.getColumns() ) {
            // добавляем ограничения колонки в общий набор
            if ( !column.getConstraints().isEmpty() ) {
                for ( DBConstraint constraint : column.getConstraints() ) {
                    constraints.add( constraint.baseColumn( column.getName() ) );
                }
            }

            // в MySQL первичный ключ задается после колонок
            if ( column.isPk() && ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) ) )
                primaryKeyMySQL = column.getName();

            // стандартно вписываем дефиницию колонки
            DBActionUtil.applyColumn( dbType, builder, column );

            // если не последняя - ставим запятую
            if ( table.getColumns().indexOf( column ) != table.getColumns().size() - 1 )
                builder.append( ", " );
        }

        // создаем первичный ключ в мускл
        if ( ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) )
                && primaryKeyMySQL != null )
            builder.append( ", PRIMARY KEY (" ).append( primaryKeyMySQL ).append( ")" );

        // если есть отдельные ограничения, заданные на таблицу - добавляем в общую кучу
        if ( table.getConstraints() != null )
            constraints.addAll( table.getConstraints() );

        // и приделываем все стартовые ограничения
        if ( !constraints.isEmpty() ) {
            for ( DBConstraint constraint : constraints ) {
                builder.append( ", CONSTRAINT " );
                constraint.apply( dbType, builder );
            }
        }

        builder.append( "); " );
        return builder.toString();
    }

}
