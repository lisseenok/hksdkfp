package ru.adaptms.vwf.persistence.migration.template;

import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;
import ru.adaptms.vwf.persistence.migration.types.ColumnType;

import java.util.LinkedList;
import java.util.List;

/**
 * @author ppolyakov at 05.12.2021 19:30
 */
public class SimpleEntityTable implements ITableTemplate {

    protected List<DBTableColumn> columns = new LinkedList<>();

    public SimpleEntityTable() {
        columns.add(new DBTableColumn("id", ColumnType.LONG).unique().autoIncrement().primaryKey().notNull());
        columns.add(new DBTableColumn("entity_created", ColumnType.DATETIME).notNull());
        columns.add(new DBTableColumn("entity_updated", ColumnType.DATETIME));
        columns.add(new DBTableColumn("entity_uuid", ColumnType.UUID));
    }

    @Override
    public List<DBTableColumn> getColumns() {
        return columns;
    }
}
