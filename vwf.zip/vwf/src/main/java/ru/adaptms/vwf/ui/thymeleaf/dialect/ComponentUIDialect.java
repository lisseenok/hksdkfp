package ru.adaptms.vwf.ui.thymeleaf.dialect;

import org.thymeleaf.processor.IProcessor;
import ru.adaptms.quickui.thymeleaf.processor.component.ComponentProcessor;
import ru.adaptms.quickui.thymeleaf.processor.component.ShorthandComponentProcessor;
import ru.adaptms.quickui.thymeleaf.processor.frame.FrameProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.block.BlockProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.breadcrumb.BreadcrumbProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.download.DownloadProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.form.FormProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.grid.GridProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.icon.IconProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.input.InputProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.logicOutput.LogicOutputProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.notification.NotificationProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.select.SelectProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.tabpanel.TabpanelProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.trigger.ActionProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.trigger.LinkProcessor;

import java.util.HashSet;
import java.util.Set;

/**
 * @author ppolyakov at 01.01.2022 21:00
 */
public class ComponentUIDialect extends AbstractUIDialect {
    private static final String PROCESSOR_NAME = "Adapt Component UI dialect";
    private static final String DIALECT_PREFIX = "uic";
    private static final int PRECEDENCE = 1100;

    public ComponentUIDialect() {
        super(PROCESSOR_NAME, DIALECT_PREFIX, PRECEDENCE);
    }

    @Override
    public Set<IProcessor> getProcessors(final String dialectPrefix) {
        final Set<IProcessor> processors = new HashSet<IProcessor>();
        processors.add(new ShorthandComponentProcessor(DIALECT_PREFIX));
        return processors;
    }
}
