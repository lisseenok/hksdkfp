package ru.adaptms.vwf.ui.component.grid;

import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

/**
 * Basic datasource for entries of any kind
 * @author ppolyakov at 27.01.2022 16:33
 */
public class SimpleDS<T> extends AbstractDataSource<T> {
    protected IOutputTransformation<T> outputTransformation = null;

    @Getter
    private List<HeaderColumn> header = new ArrayList<>();

    public SimpleDS() {
        result = new ArrayList<>();
    }

    /**
     * Add singular row to output for customization purposes
     */
    public SimpleDS<T> addRow(T row) {
        this.result.add(row);
        return this;
    }

    /**
     * Add multiple rows to output for customization purposes
     */
    public SimpleDS<T> addRows(List<T> rows) {
        this.result.addAll(rows);
        return this;
    }

    /**
     * Set the interface that will process execution result for customization purposes
     */
    public SimpleDS<T> transformOutput(IOutputTransformation<T> transformation) {
        this.outputTransformation = transformation;
        return this;
    }

    /**
     * Builder-style column add (as HeaderColumn object for customizations)
     */
    public SimpleDS<T> column(HeaderColumn column) {
        header.add(column);
        return this;
    }

    /**
     * Builder-style column add (as String title for shorthand access)
     */
    public SimpleDS<T> column(String title) {
        return column(new HeaderColumn(title));
    }

    /**
     * Get current result. Processes it with current IOutputTransformation set in #transformOutput
     */
    @Override
    public List<T> execute() {
        if (outputTransformation != null)
            doTransformOutput(outputTransformation);
        return this.result;
    }

    @Override
    public boolean isPageable() {
        return false; // simple DS is not supposed to be pageable
    }
}
