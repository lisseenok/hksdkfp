package ru.adaptms.vwf.persistence.meta;

import lombok.Getter;

import jakarta.persistence.Column;
import java.lang.reflect.Field;

/**
 * @author ppolyakov at 13.04.2022 18:45
 */
public class EntityFieldMeta {

    @Getter private final String name;
    @Getter private final String columnName;
    @Getter private String title;
    @Getter private String comment;
    @Getter private Field field;

    public EntityFieldMeta( Field field ) {
        name = field.getName();
        columnName = field.isAnnotationPresent( Column.class ) ? field.getAnnotation( Column.class ).name() : field.getName();
        this.field = field;
        if ( field.isAnnotationPresent( Meta.class ) ) {
            title = field.getAnnotation( Meta.class ).title();
            comment = field.getAnnotation( Meta.class ).comment();
        } else {
            title = name;
        }
    }
}
