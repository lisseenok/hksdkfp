package ru.adaptms.vwf.util.registry;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 14.03.2022 16:55
 */
public class ExtendableHashMap<K, V> extends HashMap<K, V> {

    private Map<K, Integer> currentPriorities = new HashMap<>();

    public V put( K key, V value, int extensionPriority ) {
        if ( !currentPriorities.containsKey( key ) || currentPriorities.get( key ) < extensionPriority ) {
            currentPriorities.put( key, extensionPriority );
            return this.put( key, value );
        } else {
            return this.get( key );
        }
    }

    public V getOrCreate( K key, V defaultValue ) {
        if ( !this.containsKey( key ) )
            this.put( key, defaultValue );

        return this.get( key );
    }
}
