package ru.adaptms.vwf.util.conversion.standard;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.adaptms.vwf.util.conversion.ConversionType;

/**
 * @author ppolyakov at 04.01.2022 22:07
 */
@Component
public class BooleanConversion extends ConversionType {
    @Override
    public Class<?> getTargetClass() {
        return boolean.class;
    }

    @Override
    public Object doConvert( String input ) {
        if ( StringUtils.isBlank( input ) )
            return false;
        return !( "false".equals( input ) || "off".equals( input ) );
    }
}
