package ru.adaptms.vwf.persistence.migration.structure.action.util;


import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;
import ru.adaptms.vwf.persistence.migration.types.ColumnType;
import ru.adaptms.vwf.persistence.migration.types.DBType;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Утилита для reusable действий с миграциями
 *
 * @author ppolyakov at 11.12.2021 18:53
 */
public class DBActionUtil {
    private static final SimpleDateFormat DF = new SimpleDateFormat( "yyyy-MM-dd" );
    private static final SimpleDateFormat TF = new SimpleDateFormat( "HH:mm:ss" );
    private static final SimpleDateFormat DTF = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss" );

    /**
     * Собрать дефиницию колонки
     *
     * @param dbType  тип СУБД
     * @param builder билдер, в который включать
     * @param column  сама дефиниция
     */
    public static void applyColumn(String dbType, StringBuilder builder, DBTableColumn column) {
        applyColumn(dbType, builder, column, false);
    }

    /**
     * Собрать дефиницию колонки
     *
     * @param dbType  тип СУБД
     * @param builder билдер, в который включать
     * @param column  сама дефиниция
     * @param modify использовать синтаксис изменения колонки
     */
    public static void applyColumn(String dbType, StringBuilder builder, DBTableColumn column, boolean modify) {
        // сначала всегда имя колонки
        builder.append(column.getName())
                .append(" ");

        if (modify)
            builder.append("TYPE ");

        builder.append(column.getType().getType(dbType));

        // потом длина хранимых данных
        // если не указана - устанавливаем стандартную
        if ( column.getLength() == null )
            column.length( column.getType().getDefaultLength( dbType ) );

        // конвертируем длину в текст
        if ( column.getLength() != null ) {
            if ( dbType.matches( DBType.PSQL ) )
                builder.append( " " ); // на всякий случай пробел в постгресе

            // если -1 - пишем "max", иначе - то, что сказано
            builder.append( "(" ).append( column.getLength() == -1 ? "max" : column.getLength() ).append( ")" );
        }

        // автоинкремент значений
        if ( column.isAutoIncrement() ) {
            if ( dbType.matches( DBType.MSSQL ) )
                builder.append( " IDENTITY(1,1)" ); // настраивать так просто можно только в T-SQL, поэтому ставим стандартные
            else if ( dbType.matches( DBType.MYSQL_5 )
                    || column.isAutoIncrement() && dbType.matches( DBType.MYSQL_8 ) )
                builder.append( " AUTO_INCREMENT" );
            else if ( dbType.matches( DBType.PSQL ) )
                //builder.append( " SERIAL" );
                builder.append( " GENERATED ALWAYS AS IDENTITY" );
        }

        // не NULL
        if ( column.isNotNull() )
            builder.append( " NOT NULL" );

        // уникальное, не может быть вместе с PK
        if ( column.isUnique() && !column.isPk() )
            builder.append( " UNIQUE" );

        // задаем первичный ключ в T-SQL и постгресе
        if ( column.isPk() && !( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) ) ) {
            builder.append( " PRIMARY KEY" );
        }

        // устанавливаем дефолтное значение в зависимости от типа данных
        if ( column.getDefaultValue() != null ) {
            builder.append( " DEFAULT " );
            if ( String.class.isAssignableFrom( column.getType().getDefaultValueType() ) ) {
                builder.append( "'" ).append( ( String ) column.getDefaultValue() ).append( "'" );
            } else if ( Boolean.class.isAssignableFrom( column.getType().getDefaultValueType() ) ) {
                if ( dbType.matches( DBType.PSQL ) ) {
                    builder.append( convertBoolean( dbType, ( boolean ) column.getDefaultValue() ) );
//                            .append( "CAST (" )
//                            .append( ( ( boolean ) column.getDefaultValue() ) ? "1" : "0" )
//                            .append( " AS BIT)" );
                } else {
                    builder.append( ( ( boolean ) column.getDefaultValue() ) ? "1" : "0" );
                }
            } else if ( Short.class.isAssignableFrom( column.getType().getDefaultValueType() )
                    || Integer.class.isAssignableFrom( column.getType().getDefaultValueType() )
                    || Long.class.isAssignableFrom( column.getType().getDefaultValueType() ) ) {
                builder.append( column.getDefaultValue().toString() );
            } else if ( Date.class.isAssignableFrom( column.getType().getDefaultValueType() ) ) {
                builder.append( convertDate( dbType, column.getType(), ( Date ) column.getDefaultValue() ) );
            }
        }
    }

    public static String convertBoolean( String dbType, boolean value ) {
        if ( dbType.matches( DBType.PSQL ) ) {
            return value ? "'1'" : "'0'";
        } else {
            return value ? "1" : "0";
        }

        // return "CAST (" + value ? "1" : "0" + "AS BIT)";
    }

    /**
     * Конверсия даты в формат, подходящий для типа СУБД и колонки
     * @param dbType тип СУБД
     * @param type тип колонки
     * @param date дата
     * @return строка с корректной датой
     */
    public static String convertDate( String dbType, ColumnType type, Date date ) {
        StringBuilder builder = new StringBuilder();

        String formatted;
        if ( type == ColumnType.DATE )
            formatted = DF.format( date );
        else if ( type == ColumnType.TIME )
            formatted = TF.format( date );
        else
            formatted = DTF.format( date );

        if ( dbType.matches( DBType.MYSQL_5 )
                || dbType.matches( DBType.MYSQL_8 )
                || dbType.matches( DBType.PSQL ) ) {
            builder.append( "'" ).append( formatted ).append( "'" );
        } else {
            if ( type == ColumnType.DATE )
                builder.append( "CAST('" ).append( formatted ).append( "' AS DATE)" );
            else if ( type == ColumnType.TIME )
                builder.append( "CAST('" ).append( formatted ).append( "' AS TIME)" );
            else if ( type == ColumnType.DATETIME )
                builder.append( "CAST('" ).append( formatted ).append( "' AS DATETIME)" );
            else
                builder.append( "CAST('" ).append( formatted ).append( "' AS TIMESTAMP)" );
        }
        return builder.toString();
    }
}
