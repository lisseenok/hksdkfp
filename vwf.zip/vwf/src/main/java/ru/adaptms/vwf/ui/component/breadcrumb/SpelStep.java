package ru.adaptms.vwf.ui.component.breadcrumb;

/**
 * @author ppolyakov at 17.03.2022 10:06
 */
public class SpelStep extends TextStep {
    public SpelStep( String title ) {
        super( title );
    }

    public SpelStep( String title, String uri ) {
        super( title, uri );
    }

    @Override
    public boolean isSpel() {
        return true;
    }
}
