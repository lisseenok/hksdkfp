package ru.adaptms.vwf.project;

import lombok.Getter;

import java.util.Locale;

/**
 * @author ppolyakov at 11.04.2022 18:41
 */
public class ModuleMeta {

    @Getter private final String code;
    @Getter private final String codeShort;
    @Getter private final String title;

    public ModuleMeta( String code, String codeShort, String title ) {
        this.code = code.toLowerCase( Locale.ROOT );
        this.codeShort = codeShort.toLowerCase( Locale.ROOT );
        this.title = title;
    }
}
