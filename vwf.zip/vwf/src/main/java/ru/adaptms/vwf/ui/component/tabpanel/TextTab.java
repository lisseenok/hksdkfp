package ru.adaptms.vwf.ui.component.tabpanel;

import ru.adaptms.quickui.util.ParameterMap;
import ru.adaptms.vwf.ui.thymeleaf.processor.tabpanel.TabpanelProcessor;

import java.io.Serializable;

/**
 * @author ppolyakov at 12.03.2022 16:05
 */
public class TextTab implements Serializable {

    private String id;
    private String label;
    private int order;
    private String classes;
    private String styles;
    private boolean disabled = false;

    public TextTab() {
    }

    public TextTab( String id, String label, int order ) {
        setId( id );
        setLabel( label );
        setOrder( order );
    }

    public TextTab disabled() {
        setDisabled( true );
        return this;
    }

    public TextTab disabled( boolean disabled ) {
        setDisabled( disabled );
        return this;
    }

    public TextTab classes( String classes ) {
        setClasses( classes );
        return this;
    }

    public TextTab styles( String styles ) {
        setStyles( styles );
        return this;
    }

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel( String label ) {
        this.label = label;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder( int order ) {
        this.order = order;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses( String classes ) {
        this.classes = classes;
    }

    public String getStyles() {
        return styles;
    }

    public void setStyles( String styles ) {
        this.styles = styles;
    }

    public boolean isDisabled() {
        return disabled;
    }

    public void setDisabled( boolean disabled ) {
        this.disabled = disabled;
    }

    public ParameterMap getParams() {
        return ParameterMap.create( TabpanelProcessor.LISTENER_PARAM_TAB, getId() );
    }

    public boolean isSpel() {
        return false;
    }
}
