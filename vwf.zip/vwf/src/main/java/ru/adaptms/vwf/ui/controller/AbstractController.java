package ru.adaptms.vwf.ui.controller;

import org.springframework.ui.Model;
import ru.adaptms.vwf.ui.action.success.*;
import ru.adaptms.vwf.ui.form.*;

/**
 * Base for controllers
 *
 * @author ppolyakov at 01.01.2022 21:56
 */
public abstract class AbstractController {
    protected String template( String name ) {
        return template( name, null );
    }

    protected String template( String name, String fragment ) {
        return getTemplatePath() + name
                + ( fragment != null && !fragment.isEmpty() ? " :: " + fragment : "" );
    }

    protected String modal( Model model, String template ) {
        return modal( model, template, "content" );
    }

    protected String modal( Model model, String template, String fragment ) {
        model.addAttribute( "layoutModalOpen", true );
        model.addAttribute( "layoutModalTemplate", template );
        model.addAttribute( "layoutModalFragment", fragment );

        return "templates/layout :: #vwf_layout_modal_zone";
    }

    protected String page() {
        return page( null );
    }

    protected String page( String fragment ) {
        return getTemplatePath() + "Page"
                + ( fragment != null && !fragment.isEmpty() ? " :: " + fragment : "" );
    }

    protected String getTemplatePath() {
        return this.getClass().getCanonicalName().replaceAll( "\\.", "/" )
                .replace( this.getClass().getSimpleName(), "" );
    }

    protected String redirect( String to ) {
        return "redirect:" + to;
    }

    protected SubmissionResult createResult( String successRedirect ) {
        return new SubmissionResult( new SuccessRedirect( successRedirect ) );
    }

    protected SubmissionResult createResult( ISuccessAction action ) {
        return new SubmissionResult( action );
    }

    protected SuccessNotify notify( String message ) {
        return new SuccessNotify( message );
    }

    protected SuccessNotify notify( String message, String type ) {
        return new SuccessNotify( message ).type( type );
    }

    protected SuccessAjaxLoadFrame loadFragment( String uri ) {
        return loadFragment( uri, "content_zone" );
    }

    protected SuccessAjaxLoadFrame loadFragment( String uri, String targetId ) {
        return new SuccessAjaxLoadFrame( uri, targetId );
    }

    protected SuccessInsertPayload insertPayload( String targetId, String payload ) {
        return new SuccessInsertPayload( targetId, payload );
    }

    protected SuccessCloseModal closeModal() {
        return new SuccessCloseModal();
    }
}
