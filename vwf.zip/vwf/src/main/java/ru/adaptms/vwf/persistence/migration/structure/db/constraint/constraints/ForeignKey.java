package ru.adaptms.vwf.persistence.migration.structure.db.constraint.constraints;

import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;
import ru.adaptms.vwf.persistence.migration.structure.db.constraint.ForeignKeyAction;

import jakarta.persistence.Table;

/**
 * Внешний ключ
 *
 * @author ppolyakov at 05.12.2021 19:36
 */
public class ForeignKey extends DBConstraint {

    private String referencedTableName;
    private String referencedColumnName = "id";
    private ForeignKeyAction onUpdateAction;
    private ForeignKeyAction onDeleteAction;

    /**
     * @param constraintName      имя ограничения
     * @param referencedTableName имя таблицы, на которую ссылаемся
     */
    public ForeignKey(String constraintName, String referencedTableName) {
        super(constraintName);
        this.referencedTableName = referencedTableName;
    }

    /**
     * @param constraintName      имя ограничения
     * @param referencedTableName имя таблицы, на которую ссылаемся
     * @param baseColumnName      имя колонки, на которую навешиваем ограничение
     */
    public ForeignKey(String constraintName, String referencedTableName, String baseColumnName) {
        super(constraintName);
        super.baseColumn(baseColumnName);
        this.referencedTableName = referencedTableName;
    }

    /**
     * @param constraintName        имя ограничения
     * @param referencedEntityClass класс сущности с аннотацией @Table, на которую ссылаемся
     */
    public ForeignKey(String constraintName, Class<?> referencedEntityClass) {
        super(constraintName);
        if (!referencedEntityClass.isAnnotationPresent(Table.class))
            throw new IllegalStateException("Cannot resolve table name from class " + referencedEntityClass.getSimpleName() + " for constraint creation because " +
                    "it doesn't have the @java.persistence.Table annotation. Try adding the annotation or specify table name as a string.");
        this.referencedTableName = referencedEntityClass.getAnnotation(Table.class).name();
    }

    /**
     * @param constraintName        имя ограничения
     * @param referencedEntityClass класс сущности с аннотацией @Table, на которую ссылаемся
     * @param baseColumnName        имя колонки, на которую навешиваем ограничение
     */
    public ForeignKey(String constraintName, Class<?> referencedEntityClass, String baseColumnName) {
        super(constraintName);
        super.baseColumn(baseColumnName);
        if (!referencedEntityClass.isAnnotationPresent(Table.class))
            throw new IllegalStateException("Cannot resolve table name from class " + referencedEntityClass.getSimpleName() + " for constraint creation because " +
                    "it doesn't have the @java.persistence.Table annotation. Try adding the annotation or specify table name as a string.");
        this.referencedTableName = referencedEntityClass.getAnnotation(Table.class).name();
    }

    /**
     * Задать колонку в таблице, на которую ссылаемся. По умолчанию это "id"
     *
     * @param columnName имя колонки в таблице, на которую ссылаемся
     */
    public ForeignKey referencesColumn(String columnName) {
        this.referencedColumnName = columnName;
        return this;
    }

    /**
     * @param action действие при обновлении
     */
    public ForeignKey onUpdate(ForeignKeyAction action) {
        this.onUpdateAction = action;
        return this;
    }

    /**
     * @param action действие при удалении
     */
    public ForeignKey onDelete(ForeignKeyAction action) {
        this.onDeleteAction = action;
        return this;
    }

    @Override
    public void apply(String dbType, StringBuilder builder) {
        builder.append(constraintName)
                .append(" FOREIGN KEY (")
                .append(baseColumn).append(")")
                .append(" REFERENCES ")
                .append(referencedTableName)
                .append("(").append(referencedColumnName).append(")");

        if (onUpdateAction != null)
            builder.append(" ON UPDATE ").append(onUpdateAction.getExpression(dbType));

        if (onDeleteAction != null)
            builder.append(" ON DELETE ").append(onDeleteAction.getExpression(dbType));
    }


}
