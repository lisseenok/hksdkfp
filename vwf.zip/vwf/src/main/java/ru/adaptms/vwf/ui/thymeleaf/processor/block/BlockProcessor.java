package ru.adaptms.vwf.ui.thymeleaf.processor.block;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.AbstractElementTagProcessor;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.templatemode.TemplateMode;

/**
 * @author ppolyakov at 14.03.2022 21:40
 */
public class BlockProcessor extends AbstractElementTagProcessor {

    public static final int PRECEDENCE = 100000;
    public static final String ELEMENT_NAME = "block";

    public BlockProcessor( final String dialectPrefix ) {
        super( TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                ( dialectPrefix != null ),
                null,
                false,
                PRECEDENCE );
    }

    @Override
    protected void doProcess( final ITemplateContext context,
                              final IProcessableElementTag tag,
                              final IElementTagStructureHandler structureHandler ) {

        // We are just removing the "<th:block>", leaving whichever contents (body) it might have generated.
        structureHandler.removeTags();

    }
}
