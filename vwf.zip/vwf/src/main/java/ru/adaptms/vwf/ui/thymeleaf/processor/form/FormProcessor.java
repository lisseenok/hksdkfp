package ru.adaptms.vwf.ui.thymeleaf.processor.form;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;
import ru.adaptms.vwf.util.RandomUtils;

import java.util.*;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class FormProcessor extends AbstractElementModelProcessor {

    private static final String ELEMENT_NAME = "form";
    private static final int PRECEDENCE = 800;

    public FormProcessor(final String dialectPrefix) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                true,
                null,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess(ITemplateContext context,
                             IModel model,
                             IElementModelStructureHandler structureHandler) {
        final IModelFactory modelFactory = context.getModelFactory();
        IEngineConfiguration configuration = context.getConfiguration();
        IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);

        Map<String, String> attributes = new HashMap<>();
        final ITemplateEvent formEvent = model.get(0);
        if (formEvent instanceof IOpenElementTag) {
            IOpenElementTag formElement = (IOpenElementTag) formEvent;
            Map<String, String> incomingAttrs = formElement.getAttributeMap();

            AbstractUIHandler handler = (AbstractUIHandler) context.getVariable(AbstractUIHandler.HANDLER_VARIABLE);
            String id = (String) SpringELUtil.execute(incomingAttrs.get("id"), context, parser);
            if (StringUtils.isBlank(id))
                id = RandomUtils.instance().randomString(8);

            if (handler != null && incomingAttrs.containsKey("listener")) {
                id += "_" + handler.getHandlerId();

                AbstractUIHandler topLevelHandler = handler;
                while (topLevelHandler.getParent() != null) {
                    topLevelHandler = topLevelHandler.getParent();
                }

                UriBuilder action = UriBuilder.create(MappingRegistry.instance().getMetaByClass(topLevelHandler.getClass()).getMapping(), true);
                action.parameter(AbstractUIHandler.PARAM_FORM, handler.getHandlerId() + "." + SpringELUtil.execute(incomingAttrs.get("listener"), context, parser));
                Map<String, String> importantParameters = HandlerUtil.getIdentifyingParams(topLevelHandler.getParameters());
                for (Map.Entry<String, String> entry : importantParameters.entrySet()) {
                    action.parameter(entry.getKey(), entry.getValue());
                }

                ProcessorHelper.applyParams(action, incomingAttrs, context, parser, null);

                /*if ( incomingAttrs.containsKey( "params" ) ) {
                    Map<String, Object> params = ( Map<String, Object> ) SpringELUtil.execute( incomingAttrs.get( "params" ), context, parser );
                    for ( Map.Entry<String, Object> entry : params.entrySet() ) {
                        action.parameter( entry.getKey(), entry.getValue() );
                    }
                }*/

                attributes.put("action", action.build());
            } else {
                if (incomingAttrs.containsKey("action")) {
                    attributes.put("action", incomingAttrs.get("action"));
                } else {
                    attributes.put("th:action", incomingAttrs.get("th:action"));
                }
            }

            attributes.put("id", id);
            attributes.put("data-vwf-csrf", UUID.randomUUID().toString());

            if (!incomingAttrs.containsKey("sync")) {
                attributes.put("data-vwf-async", "true");
                attributes.put("novalidate", null);
            }

            if (incomingAttrs.containsKey("enctype"))
                attributes.put("enctype", (String) SpringELUtil.execute(incomingAttrs.get("enctype"), context, parser));

            if (incomingAttrs.containsKey("method")) {
                attributes.put("method", (String) SpringELUtil.execute(incomingAttrs.get("method"), context, parser));
            } else {
                attributes.put("method", "post");
            }

            if (incomingAttrs.containsKey("class"))
                attributes.put("class", (String) SpringELUtil.execute(incomingAttrs.get("class"), context, parser));
        }

        IOpenElementTag formOpen = modelFactory
                .createOpenElementTag("form", attributes,
                        AttributeValueQuotes.DOUBLE,
                        false);

        model.replace(0, formOpen);
        model.replace(model.size() - 1, modelFactory.createCloseElementTag("form"));
    }
}
