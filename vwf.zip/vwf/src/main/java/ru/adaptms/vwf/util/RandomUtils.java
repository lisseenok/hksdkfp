package ru.adaptms.vwf.util;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Service;

/**
 * @author ppolyakov at 19.02.2022 02:01
 */
@Service
public class RandomUtils {
    public static RandomUtils instance() { return SpringUtils.getInstance( RandomUtils.class ); }

    public String randomString( int length ) {
        return RandomStringUtils.random( length, true, true );
    }

    public int randomInt() {
        return org.apache.commons.lang3.RandomUtils.nextInt();
    }

}
