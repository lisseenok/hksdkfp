package ru.adaptms.vwf.config.websocket;

public interface IWebsocketResource {
}
