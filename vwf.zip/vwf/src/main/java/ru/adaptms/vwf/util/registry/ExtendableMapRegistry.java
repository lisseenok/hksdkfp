package ru.adaptms.vwf.util.registry;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.SpringUtils;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.util.Map;
import java.util.Set;

/**
 * TODO remove
 *
 * @author ppolyakov at 14.03.2022 16:19
 */
@Service
@RequiredArgsConstructor
public class ExtendableMapRegistry {
    private ExtendableHashMap<String, ExtendableHashMap<String, Object>> registry = new ExtendableHashMap<>();

    private final ReflectionsUtil reflectionsUtil;

    public static ExtendableMapRegistry instance() {
        return SpringUtils.getInstance(ExtendableMapRegistry.class);
    }

    public <T> Map<String, T> get(String key) {
        return (Map<String, T>) registry.get(key);
    }

    @PostConstruct
    public void init() {
        Set<Class<? extends IMapExtender>> mapExtenders = reflectionsUtil.getSubclasses(IMapExtender.class);
        if (mapExtenders != null) {
            for (Class<? extends IMapExtender> mapExtender : mapExtenders) {
                try {
                    IMapExtender extender = mapExtender.getConstructor().newInstance();
                    extender.execute(this.registry);
                } catch (Exception e) {
                    LoggingUtil.error(ExtendableMapRegistry.class, "Couldn't extend map via extender \"" + mapExtender.getCanonicalName() + "\": ", e);
                }
            }
        }
    }
}
