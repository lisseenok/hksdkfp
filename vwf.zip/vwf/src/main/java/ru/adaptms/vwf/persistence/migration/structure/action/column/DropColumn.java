package ru.adaptms.vwf.persistence.migration.structure.action.column;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Удалить колонку из таблицы
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropColumn extends MigrationAction {

    private String tableName;
    private String column;

    /**
     * @param tableName название таблицы, из которой надо удалить
     * @param columnToDrop колонка, которая будет удалена
     */
    public DropColumn( String tableName, String columnToDrop ) {
        this.tableName = tableName;
        this.column = columnToDrop;
    }

    @Override
    public String generateSQL( String dbType ) {
        return "ALTER TABLE " + tableName + " DROP COLUMN "
                + (dbType.matches(DBType.MYSQL_8) || dbType.matches(DBType.MYSQL_5) ? "" : "IF EXISTS ")
                + column;
    }
}
