package ru.adaptms.vwf.persistence.entity.browsing;

import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.persistence.entity.IEntity;
import ru.adaptms.vwf.persistence.meta.Meta;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.util.reflections.MethodUtil;

import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * @author ppolyakov at 29.01.2022 23:18
 */
public class EntityFieldReader {

    public static <T extends BaseEntity> List<EntityField> readFields( T entity ) {
        List<EntityField> output = new ArrayList<>();

        Class<? extends BaseEntity> entityClass = entity.getClass();

        try {
            output.add( new EntityField( "id" )
                    .title( I18NService.instance().getMessage( "framework.grid.browsing.id" ) )
                    .value( entity.getId() )
                    .field( entity.getClass().getField( "id" ) ) );
            output.add( new EntityField( "created" )
                    .title( I18NService.instance().getMessage( "framework.grid.browsing.created" ) )
                    .value( entity.getCreated() )
                    .field( entity.getClass().getField( "created" ) ) );
        } catch ( Exception e ) {
            //
        }

        while ( entityClass != BaseEntity.class ) {
            for ( Field field : entityClass.getDeclaredFields() ) {
                if ( Modifier.isStatic( field.getModifiers() )
                        || field.isAnnotationPresent( Transient.class )
                        || field.isAnnotationPresent( OneToMany.class )
                        || field.isAnnotationPresent( ManyToMany.class )
                        || Collection.class.isAssignableFrom( field.getType() ) )
                        //|| IEntity.class.isAssignableFrom( field.getType() ) )
                    continue;

                try {
                    Object value = ( field.isAnnotationPresent( Meta.class ) && field.getAnnotation( Meta.class ).censored() ) ? null
                            : MethodUtil.getGetter( entityClass, field ).invoke( entity );
                    output.add( new EntityField( field ).value( value ) );
                } catch ( NoSuchMethodException | IllegalAccessException | InvocationTargetException e ) {
                    output.add( new EntityField( field.getName() ).value( new IllegalStateException( e ) ) );
                }
            }

            if ( entityClass.getSuperclass() != null ) {
                entityClass = ( Class<? extends BaseEntity> ) entityClass.getSuperclass();
            } else {
                break;
            }
        }

        return output;
    }

    public static String buildEntityClassName( Class<? extends BaseEntity> entityClass ) {
        if ( entityClass.isAnnotationPresent( Meta.class ) ) {
            return entityClass.getAnnotation( Meta.class ).title() + " (" + entityClass.getSimpleName() + ")";
        } else {
            return entityClass.getSimpleName();
        }
    }

}
