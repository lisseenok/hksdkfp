package ru.adaptms.vwf.persistence.migration.structure.action.column;

import ru.adaptms.vwf.persistence.migration.structure.action.util.DBActionUtil;
import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;
import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Изменить параметры колонки
 *
 * @author ppolyakov at 11.12.2021 18:47
 */
public class ModifyColumn extends MigrationAction {

    private String tableName;
    private DBTableColumn column;

    /**
     * @param tableName название таблицы, в которой будем работать
     * @param columnToModify новая дефиниция колонки (название должно соответствовать меняемой)
     */
    public ModifyColumn( String tableName, DBTableColumn columnToModify ) {
        this.tableName = tableName;
        this.column = columnToModify;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder();

        builder.append( "ALTER TABLE " )
                .append( tableName )
                .append( dbType.matches( DBType.MSSQL ) || dbType.matches( DBType.PSQL ) ? " ALTER COLUMN " : " MODIFY COLUMN " );

        DBActionUtil.applyColumn(dbType, builder, column, true);

        return builder.toString();
    }
}
