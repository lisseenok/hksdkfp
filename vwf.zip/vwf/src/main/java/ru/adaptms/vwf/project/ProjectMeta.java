package ru.adaptms.vwf.project;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 * @author ppolyakov at 11.04.2022 18:41
 */
public class ProjectMeta {

    @Getter
    private static String code;
    @Getter
    private static String title;
    @Getter
    private static String jvmConfigPathProperty;
    @Getter
    private static boolean noPersistence;
    @Getter
    private static List<ModuleMeta> modules = new ArrayList<>();
    @Getter
    private static Set<String> moduleCodes = new HashSet<>();
    @Getter
    private static Map<String, List<String>> ignoredEntries = new HashMap<>();
    @Getter
    private static Set<String> disabledFeatures = new HashSet<>();
    @Getter
    public static final Set<String> reflectionsRoots = new HashSet<>();

    public static void init() {
        try {
            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver(ProjectMeta.class.getClassLoader());
            Resource[] projectPropertiesFile = resolver.getResources("classpath*:/**/project.properties");

            if (projectPropertiesFile.length == 0)
                throw new IllegalArgumentException("No project.properties file found. This cannot be. Create one.");

            if (projectPropertiesFile.length > 1)
                throw new IllegalArgumentException("More than one project.properties file found. This cannot be.");

            Properties projectProperties = new Properties();
            projectProperties.load(projectPropertiesFile[0].getInputStream());

            code = projectProperties.getProperty("code").toLowerCase(Locale.ROOT);
            title = projectProperties.getProperty("title");
            jvmConfigPathProperty = projectProperties.getProperty("config.path.property");
            noPersistence = "disabled".equals(projectProperties.getProperty("persistence", "enabled"));

            @SuppressWarnings("unchecked")
            Enumeration<String> propertyNames = (Enumeration<String>) projectProperties.propertyNames();
            while (propertyNames.hasMoreElements()) {
                String key = propertyNames.nextElement();
                String values = projectProperties.getProperty(key);

                if (StringUtils.isBlank(values)) continue;

                if (key.startsWith("ignore.")) {
                    String ignoredKey = key.replace("ignore.", "");
                    getIgnoredEntries().computeIfAbsent(ignoredKey, k -> new ArrayList<>());

                    List<String> ignoredValues = getIgnoredEntries().get(ignoredKey);
                    for (String ignoredValue : values.split(",")) {
                        String stripped = ignoredValue.strip();

                        if (!ignoredValues.contains(stripped))
                            ignoredValues.add(stripped);
                    }
                } else if (key.equals("disabled")) {
                    for (String disabledFeature : values.split(",")) {
                        String stripped = disabledFeature.strip();
                        disabledFeatures.add(stripped);
                    }
                }
            }

            AppDefines.set(AppDefines.LAYOUT_TEMPLATE, projectProperties.containsKey("layout-template") ? projectProperties.getProperty("layout-template") : "templates/layout");
            AppDefines.set(AppDefines.LAYOUT_LOGO, projectProperties.containsKey("layout-logo") ? projectProperties.getProperty("layout-logo") : "/resources/img/logo.svg");

            Resource[] modulePropertiesFiles = resolver.getResources("classpath*:/**/module.properties");
            for (Resource modulePropertiesFile : modulePropertiesFiles) {
                Properties moduleProperties = new Properties();
                moduleProperties.load(modulePropertiesFile.getInputStream());

                String moduleCode = moduleProperties.getProperty("code");
                String moduleCodeShort = moduleProperties.getProperty("code.short");
                String moduleTitle = moduleProperties.getProperty("title");
                String reflectionsRoot = moduleProperties.getProperty("reflections.root");

                if (StringUtils.isNotBlank(reflectionsRoot))
                    reflectionsRoots.add(reflectionsRoot);

                if (StringUtils.isBlank(moduleCodeShort))
                    moduleCodeShort = moduleCode;

                ModuleMeta moduleMeta = new ModuleMeta(moduleCode, moduleCodeShort, moduleTitle);
                modules.add(moduleMeta);
                moduleCodes.add(moduleMeta.getCode());
            }

        } catch (IOException e) {
            LoggingUtil.error(ProjectMeta.class, "Couldn't read project structure.", e);
            throw new IllegalStateException(e);
        }
    }

    public static boolean isModuleLoaded(String name) {
        return moduleCodes.contains(name);
    }

    public static boolean isModulesLoaded(String[] names) {
        return moduleCodes.containsAll(Arrays.asList(names));
    }

    public static ModuleMeta getModule(String name) {
        return modules.stream().filter(m -> m.getCode().equals(name.toLowerCase(Locale.ROOT))).findFirst().orElse(null);
    }

}
