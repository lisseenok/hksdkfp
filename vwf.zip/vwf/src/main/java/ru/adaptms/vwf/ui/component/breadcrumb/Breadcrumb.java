package ru.adaptms.vwf.ui.component.breadcrumb;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * @author ppolyakov at 01.01.2022 21:25
 */
public class Breadcrumb implements Serializable {
    private List<TextStep> steps = new LinkedList<>();

    public Breadcrumb() {
    }

    public Breadcrumb step( TextStep step ) {
        steps.add( step );
        return this;
    }

    public Breadcrumb replaceLastStep( TextStep step ) {
        getSteps().remove( getSteps().size() - 1 );
        return step( step );
    }

    public List<TextStep> getSteps() {
        return steps;
    }
}
