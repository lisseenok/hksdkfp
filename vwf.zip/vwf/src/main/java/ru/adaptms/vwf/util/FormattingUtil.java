package ru.adaptms.vwf.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * @author ppolyakov at 01.02.2022 17:44
 */
@Service("format")
public class FormattingUtil {
    public static FormattingUtil instance() {
        return SpringUtils.getInstance(FormattingUtil.class);
    }

    public static ObjectMapper MAPPER = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    public static List<String> months = List.of("января", "февраля", "марта", "апреля",
            "мая", "июня", "июля", "августа",
            "сентября", "октября", "ноября", "декабря");

    private static final String MONTH_TOKEN = "month";

    Map<String, SimpleDateFormat> dateFormatters = new HashMap<>();
    Map<String, DecimalFormat> decimalFormatters = new HashMap<>();

    public String defaultFormatDate(Date source) {
        return formatDate(source, "dd.MM.yyyy");
    }

    public String defaultFormatDateTime(Date source) {
        return formatDate(source, "dd.MM.yyyy HH:mm");
    }

    public String formatDate(Date source, String format) {
        if (source == null) return "";

        if (format.contains(MONTH_TOKEN)) {
            var cal = Calendar.getInstance();
            cal.setTime(source);
            format = format.replace(MONTH_TOKEN, months.get(cal.get(Calendar.MONTH)));
        }

        var sdf = getDateFormat(format);
        return sdf.format(source);
    }

    public String formatDate(LocalDate source, String format) {
        if (source == null) return "";

        if (format.contains(MONTH_TOKEN))
            format = format.replace(MONTH_TOKEN, months.get(source.getMonthValue() - 1));

        var formatter = DateTimeFormatter.ofPattern(format);
        return source.format(formatter);
    }

    public String formatDate(LocalDateTime source, String format) {
        if (source == null) return "";

        if (format.contains(MONTH_TOKEN))
            format = format.replace(MONTH_TOKEN, months.get(source.getMonthValue() - 1));

        var formatter = DateTimeFormatter.ofPattern(format);
        return source.format(formatter);
    }

    public Date stringToDate(String source, String format) {
        if (StringUtils.isBlank(source)) return null;

        SimpleDateFormat sdf = getDateFormat(format);
        try {
            return sdf.parse(source);
        } catch (ParseException pe) {
            return null;
        }
    }

    public Date stringToDate(String source) {
        return stringToDate(source, "dd.MM.yyyy");
    }

    public LocalDate stringToLocalDate(String source) {
        var formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        return LocalDate.parse(source, formatter);
    }

    public LocalDateTime stringToLocalDateTime(String source) {
        var formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        return LocalDateTime.parse(source, formatter);
    }

    public String formatString(String source, Object... arguments) {
        return String.format(source, arguments);
    }

    /**
     * @param source  input double
     * @param pattern #.##
     * @return formatted decimal
     */
    public String formatDecimal(double source, String pattern) {
        return getDecimalFormat(pattern).format(source);
    }

    public String formatMessage(String source, Object... arguments) {
        return MessageFormat.format(source, arguments);
    }

    /**
     * backwards compatibility
     */
    public SimpleDateFormat getFormat(String format) {
        return getDateFormat(format);
    }

    public SimpleDateFormat getDateFormat(String format) {
        String code = format;
        if (!dateFormatters.containsKey(code)) {
            Locale locale = null;
            if (format.startsWith("ru:") || format.startsWith("en:")) {
                locale = new Locale(format.substring(0, 2));
                format = format.substring(3);
            }

            dateFormatters.put(code, locale != null ? new SimpleDateFormat(format, locale) : new SimpleDateFormat(format));
        }

        return dateFormatters.get(code);
    }

    public DecimalFormat getDecimalFormat(String format) {
        decimalFormatters.computeIfAbsent(format, DecimalFormat::new);
        return decimalFormatters.get(format);
    }

    public <T> List<T> toList(T... objects) {
        if (objects == null || objects.length == 0) return Lists.newArrayList();
        return Arrays.asList(objects);
    }

    public String sanitizeString(String input, int maxLength) {
        if (input == null) return null;

        input = input.trim().replaceAll("\s+", " ");

        if (input.length() > maxLength)
            input = input.substring(0, maxLength - 1);

        return input;
    }

    public String formatDateInEnglish(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("d MMMM yyyy", new Locale("en"));
        return sdf.format(date);
    }

    public String formatDateInRussian(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy 'г.'", new Locale("ru", "RU"));
        return sdf.format(date);
    }

    public String formatMoney(Double money) {
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.FRANCE);
        symbols.setGroupingSeparator(' ');
        DecimalFormat df = new DecimalFormat("#,##0.00", symbols);
        return df.format(money);
    }
}
