package ru.adaptms.vwf.util.file;

import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.Unmarshaller;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ppolyakov at 25.04.2022 09:43
 */
public class XmlUtil {
    private static final String CLASSPATH_PREFIX = "classpath*:";

    /**
     * Load all XML files by given path pattern and transform them into their node objects
     * @param classPath pattern to match
     * @param expectedClass expected root node class
     * @param <T>
     * @return
     */
    public static <T> List<T> loadAll( String classPath, Class<T> expectedClass ) {
        try {
            if ( !expectedClass.isAnnotationPresent( XmlRootElement.class ) )
                throw new IllegalArgumentException( "Class \"" + expectedClass.getSimpleName() + "\" is not an XML root element." );

            if ( classPath.startsWith( "classpath:" ) ) {
                classPath = classPath.replace( "classpath:", "" );
            } else if ( classPath.startsWith( CLASSPATH_PREFIX ) ) {
                classPath = classPath.replace( CLASSPATH_PREFIX, "" );
            }

            PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver( XmlUtil.class.getClassLoader() );
            Resource[] resources = resolver.getResources( CLASSPATH_PREFIX + classPath );

            List<T> output = new ArrayList<>();
            for ( Resource resource : resources ) {
                InputStream is = resource.getInputStream();
                JAXBContext context = JAXBContext.newInstance( expectedClass );
                System.setProperty( "javax.xml.accessExternalDTD", "all" );
                Unmarshaller unmarshaller = context.createUnmarshaller();
                output.add( ( T ) unmarshaller.unmarshal( is ) );
            }

            return output;
        } catch ( Exception e ) {
            throw new IllegalStateException( e );
        }
    }

}
