package ru.adaptms.vwf.ui.thymeleaf.processor.grid;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.util.ParameterMap;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.util.SpringELUtil;

import java.text.MessageFormat;

/**
 * DataGrid (table for automatically displaying structured data)
 *
 * Available attributes:
 * -
 *
 * @author ppolyakov at 01.01.2022 21:04
 */
public class GridProcessor extends AbstractUITagProcessor {
    public static final String ACTION_PARAM = "pagination";
    public static final String GRID_ID_PARAM = "vwf_grid_id"; // to distinguish on pagination/filter

    private static final String ELEMENT_NAME = "grid";
    private static final int PRECEDENCE = 700;

    private static final ParameterMap firstListenerParameters = ParameterMap.create(ACTION_PARAM, "-2");
    private static final ParameterMap backListenerParameters = ParameterMap.create(ACTION_PARAM, "-1");
    private static final ParameterMap forwardListenerParameters = ParameterMap.create(ACTION_PARAM, "1");
    private static final ParameterMap lastListenerParameters = ParameterMap.create(ACTION_PARAM, "2");

    public GridProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "id", "ds", "title", "contentFragment")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        String type = elementTag.getAttributeValue("type");

        AbstractUIHandler handler = (AbstractUIHandler) incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE);

        outgoingContext.setVariable("filterListener", SpringELUtil.execute(elementTag.getAttributeValue("filterListener"), incomingContext, parser));
        outgoingContext.setVariable("paginationListener", SpringELUtil.execute(elementTag.getAttributeValue("paginationListener"), incomingContext, parser));

        String id = (String) SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser);

        outgoingContext.setVariable("handler", handler);
        outgoingContext.setVariable("firstListenerParameters", firstListenerParameters.addOrUpdate(GRID_ID_PARAM, id));
        outgoingContext.setVariable("backListenerParameters", backListenerParameters.addOrUpdate(GRID_ID_PARAM, id));
        outgoingContext.setVariable("forwardListenerParameters", forwardListenerParameters.addOrUpdate(GRID_ID_PARAM, id));
        outgoingContext.setVariable("lastListenerParameters", lastListenerParameters.addOrUpdate(GRID_ID_PARAM, id));

        outgoingContext.setVariable("id", id);
        outgoingContext.setVariable("ds", SpringELUtil.execute(elementTag.getAttributeValue("ds"), incomingContext, parser));
        outgoingContext.setVariable("title", SpringELUtil.execute(elementTag.getAttributeValue("title"), incomingContext, parser));
        outgoingContext.setVariable("classes", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));

        if (elementTag.hasAttribute("filterFragment") && !"none".equals(elementTag.getAttributeValue("filterElement")))
            outgoingContext.setVariable("filterFragment", handler.getTemplate() + "::" + SpringELUtil.execute(elementTag.getAttributeValue("filterFragment"), incomingContext, parser));

        if (elementTag.hasAttribute("headerFragment") && !"none".equals(elementTag.getAttributeValue("headerFragment")))
            outgoingContext.setVariable("headerFragment", handler.getTemplate() + "::" + SpringELUtil.execute(elementTag.getAttributeValue("headerFragment"), incomingContext, parser));

        outgoingContext.setVariable("contentFragment", handler.getTemplate() + "::" + SpringELUtil.execute(elementTag.getAttributeValue("contentFragment"), incomingContext, parser));

        if (elementTag.hasAttribute("additionalFragment") && !"none".equals(elementTag.getAttributeValue("additionalFragment")))
            outgoingContext.setVariable("additionalFragment", handler.getTemplate() + "::" + SpringELUtil.execute(elementTag.getAttributeValue("additionalFragment"), incomingContext, parser));

        if (elementTag.hasAttribute("sortMessage")) {
            outgoingContext.setVariable("sortMessage", SpringELUtil.execute(elementTag.getAttributeValue("sortMessage"), incomingContext, parser));
        } else {
            outgoingContext.setVariable("sortMessage", I18NService.instance().getMessage("framework.grid.sort"));
        }

        if (elementTag.hasAttribute("hideSettings")
                && (StringUtils.isBlank(elementTag.getAttributeValue("hideSettings"))
                || "true".equals(elementTag.getAttributeValue("hideSettings")))) {
            outgoingContext.setVariable("hideSettings", true);
        }

        if (elementTag.hasAttribute("bodyHeight")) {
            outgoingContext.setVariable("bodyStyle", MessageFormat.format(
                    "display: block; overflow-y: scroll; max-height: {0};",
                    SpringELUtil.execute(elementTag.getAttributeValue("bodyHeight"), incomingContext, parser)
            ));
        }

        structureHandler.replaceWith(getTemplate(outgoingContext, type), false);
    }
}
