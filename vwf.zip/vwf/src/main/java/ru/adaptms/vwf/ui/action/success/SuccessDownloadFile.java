package ru.adaptms.vwf.ui.action.success;

import ru.adaptms.vwf.ui.form.AsyncFile;

/**
 * Download file. Must provide a file {@link AsyncFile}
 *
 * @author ppolyakov at 07.01.2022 00:54
 */
public class SuccessDownloadFile implements ISuccessAction {
    private AsyncFile file;

    public SuccessDownloadFile( AsyncFile file ) {
        this.file = file;
    }

    public AsyncFile getFile() {
        return file;
    }

    public void setFile( AsyncFile file ) {
        this.file = file;
    }

    @Override
    public String getAction() {
        return "downloadFile";
    }
}
