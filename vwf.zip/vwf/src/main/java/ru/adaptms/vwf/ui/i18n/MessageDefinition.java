package ru.adaptms.vwf.ui.i18n;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 24.01.2022 22:56
 */
public class MessageDefinition implements Serializable {
    private String code;
    private Map<String, String> translations = new HashMap<>();

    public MessageDefinition( String code ) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public MessageDefinition translation( String lang, String value ) {
        translations.put( lang, value );
        return this;
    }

    public String getTranslation( String lang ) {
        return translations.get( lang );
    }

    public Map<String, String> getTranslations() {
        return translations;
    }
}
