package ru.adaptms.vwf.ui.search;

import ru.adaptms.vwf.ui.action.ActionResult;

import java.util.ArrayList;
import java.util.List;

/**
 * @author ppolyakov at 21.01.2022 03:02
 */
public class SearchResult extends ActionResult {
    private List<ResultElement> results;
    private Pagination pagination = new Pagination();

    public SearchResult() {
        results = new ArrayList<>();
    }

    public SearchResult( List<ResultElement> results ) {
        this.results = results;
    }

    public SearchResult hasMore() {
        pagination.setMore( true );
        return this;
    }

    public SearchResult hasMore( boolean hasMore ) {
        pagination.setMore( hasMore );
        return this;
    }

    public void applyPagination( long count, int page, int maxResults ) {
        if ( count - ( page * maxResults ) > maxResults ) getPagination().setMore( true );
    }

    public List<ResultElement> getResults() {
        return results;
    }

    public void setResults( List<ResultElement> results ) {
        this.results = results;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination( Pagination pagination ) {
        this.pagination = pagination;
    }
}
