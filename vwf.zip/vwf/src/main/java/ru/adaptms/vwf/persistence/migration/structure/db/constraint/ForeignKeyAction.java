package ru.adaptms.vwf.persistence.migration.structure.db.constraint;

import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Действия со ссылкой при удалении/обновлении
 *
 * @author ppolyakov at 11.12.2021 20:20
 */
public enum ForeignKeyAction {
    NO_ACTION( "NO ACTION", "NO ACTION", "NO ACTION" ),
    SET_NULL( "SET NULL", "SET NULL", "SET NULL" ),
    SET_DEFAULT( "SET DEFAULT", "SET DEFAULT", "SET DEFAULT" ),
    CASCADE( "CASCADE", "CASCADE", "CASCADE" );

    private final String mySQL;
    private final String msSQL;
    private final String pSQL;

    ForeignKeyAction( String mySQL, String msSQL, String pSQL ) {
        this.mySQL = mySQL;
        this.msSQL = msSQL;
        this.pSQL = pSQL;
    }

    public String getMySQL() {
        return mySQL;
    }

    public String getMsSQL() {
        return msSQL;
    }

    public String getpSQL() {
        return pSQL;
    }

    public String getExpression( String dbType ) {
        if ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) )
            return getMySQL();
        else if ( dbType.matches( DBType.MSSQL ) )
            return getMsSQL();
        else if ( dbType.matches( DBType.PSQL ) )
            return getpSQL();
        else
            throw new IllegalStateException( "No such DB type: " + dbType );
    }
}
