package ru.adaptms.vwf.ui.util.uri;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.SpringUtils;

/**
 * @author ppolyakov at 01.01.2022 22:18
 */
@Service
public class UriUtil {
    public static UriUtil instance() { return SpringUtils.getInstance( UriUtil.class ); }

    @Value("#{servletContext.contextPath}")
    private String servletContextPath;

    public String prependContextPath( String uri ) {
        if ( !uri.startsWith( "/" ) ) uri = "/" + uri;
        String contextPath = servletContextPath;
        if ( !contextPath.startsWith( "/" ) && !"".equals( contextPath ) ) contextPath = "/" + contextPath;
        return contextPath + uri;
    }

    public String appendContextPath( String host ) {
        String contextPath = servletContextPath;
        if ( !contextPath.startsWith( "/" ) && !host.endsWith( "/" ) ) contextPath = "/" + contextPath;
        return host + contextPath;
    }
}
