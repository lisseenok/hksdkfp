package ru.adaptms.vwf.persistence.migration.structure;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author ppolyakov at 23.05.2022 13:40
 */
@Target( ElementType.TYPE )
@Retention( RetentionPolicy.RUNTIME )
public @interface ExecuteAfter {
    Class<? extends AbstractMigration>[] value();
}
