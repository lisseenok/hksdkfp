package ru.adaptms.vwf.persistence.entity.browsing;

import ru.adaptms.vwf.persistence.entity.IEntity;
import ru.adaptms.vwf.persistence.meta.Meta;
import ru.adaptms.vwf.util.encryption.EncryptionUtil;

import java.lang.reflect.Field;
import java.util.Locale;

/**
 * @author ppolyakov at 29.01.2022 23:20
 */
public class EntityField {
    private String name;
    private String type;
    private String typeFull;
    private String title;
    private String comment;
    private Object value;
    private Field field;

    public EntityField( Field field ) {
        this.field = field;
        name = field.getName();
        if ( field.isAnnotationPresent( Meta.class ) ) {
            title = field.getAnnotation( Meta.class ).title();
            comment = field.getAnnotation( Meta.class ).comment();
        }
        type = field.getType().getSimpleName();
        typeFull = field.getType().getCanonicalName();
    }

    public EntityField( String name ) {
        this.name = name;
    }

    public EntityField title( String title ) {
        this.title = title;
        return this;
    }

    public EntityField comment( String comment ) {
        this.comment = comment;
        return this;
    }

    public EntityField value( Object value ) {
        this.value = value;
        return this;
    }

    public EntityField field( Field field ) {
        this.field = field;
        return this;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getTypeFull() {
        return typeFull;
    }

    public String getTitle() {
        return title;
    }

    public String getComment() {
        return comment;
    }

    public Field getField() {
        return field;
    }

    public Object getValue() {
        return value;
    }

    public void setValue( Object value ) {
        this.value = value;
    }

    public boolean isValueOfType( String type ) {
        if ( value == null )
            return false;

        return value.getClass().getSimpleName().toLowerCase( Locale.ROOT ).equals( type );
    }

    public boolean isEntity() {
        if ( value == null )
            return false;
        return value instanceof IEntity;
    }

}
