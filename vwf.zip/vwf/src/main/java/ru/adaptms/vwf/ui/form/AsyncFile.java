package ru.adaptms.vwf.ui.form;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.apache.commons.codec.digest.DigestUtils;
import ru.adaptms.vwf.persistence.entity.IFile;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.file.MimeTypeUtil;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Base64;

/**
 * @author ppolyakov at 08.01.2022 17:57
 */
public class AsyncFile implements Serializable {
    private String fileName;
    private String contentType;
    private String content; // base64

    @JsonIgnore
    private byte[] contentCache = new byte[]{};

    public AsyncFile() {
    }

    public AsyncFile(IFile source, byte[] content) {
        setFileName(source.getFileName());
        setContentType(source.getMimeType());
        setContentFromBytes(content);
    }

    public AsyncFile(String fileName) {
        this.fileName = fileName;
        this.contentType = MimeTypeUtil.getMimeType(fileName);
    }

    @JsonIgnore
    public byte[] getContentAsBytes() {
        if (contentCache.length == 0) refreshCache();
        return contentCache;
    }

    public void setContentFromBytes(byte[] input) {
        content = Base64.getEncoder().encodeToString(input);
        refreshCache();
    }

    @JsonIgnore
    public InputStream getContentAsStream() {
        if (contentCache.length == 0) refreshCache();
        return new ByteArrayInputStream(contentCache);
    }

    public void setContentFromStream(ByteArrayInputStream input) {
        content = Base64.getEncoder().encodeToString(input.readAllBytes());
        refreshCache();
    }

    @JsonIgnore
    public int getSizeInBytes() {
        if (contentCache.length == 0) refreshCache();
        return contentCache.length;
    }

    private void refreshCache() {
        try {
            if (content.contains("base64,")) {
                var parts = content.split("base64,");
                content = parts[1];
            }
            contentCache = Base64.getDecoder().decode(content);
        } catch (IllegalArgumentException iae) {
            LoggingUtil.error(AsyncFile.class, "Couldn't decode Base64 file \"" + fileName + "\"", iae);
        }
    }

    public String getExtension() {
        int lastDotIndex = getFileName().lastIndexOf(".");
        if (lastDotIndex == -1) return null;
        return getFileName().substring(lastDotIndex + 1);
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @JsonIgnore
    public String hash() {
        return DigestUtils.md5Hex(getContentAsBytes());
    }
}
