package ru.adaptms.vwf.util.file;

import java.util.Locale;

public enum FileExtension {
    RTF( "text/rtf" ),
    DOC( "application/msword" ),
    DOCX( "application/vnd.openxmlformats-officedocument.wordprocessingml.document" ),
    PDF( "application/x-pdf" ),
    PPT( "application/vnd.ms-powerpoint" ),
    PPTX( "application/vnd.openxmlformats-officedocument.presentationml.presentation" ),
    XLS( "application/vnd.ms-excel" ),
    XLSX( "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ),
    TXT( "text/plain" ),
    ZIP( "application/zip" ),
    RAR( "application/vnd.rar" ),
    JPEG( "image/jpeg" ),
    BMP( "image/bmp" ),
    PNG( "image/png" );

    public final String mimeType;

    FileExtension( String mimeType ) {
        this.mimeType = mimeType;
    }

    public String getFileExtension() {
        return name().toLowerCase( Locale.ROOT );
    }
}
