package ru.adaptms.vwf.ui.component.breadcrumb;

import java.io.Serializable;

/**
 * @author ppolyakov at 01.01.2022 21:25
 */
public class TextStep implements Serializable {
    private boolean active = false;
    private String title;
    private String uri;

    public TextStep( String title ) {
        this.title = title;
        this.active = true;
    }

    public TextStep( String title, String uri ) {
        this.title = title;
        this.uri = uri;
    }

    public boolean isActive() {
        return active;
    }

    public TextStep active() {
        this.active = true;
        return this;
    }

    public String getTitle() {
        return title;
    }

    public String getUri() {
        return uri;
    }

    public boolean isSpel() {
        return false;
    }
}
