package ru.adaptms.vwf.persistence.entity;

/**
 * @author ppolyakov at 13.10.2024 17:24
 */
public enum FileStorageType {
    FILE_SYSTEM,
    MINIO
}
