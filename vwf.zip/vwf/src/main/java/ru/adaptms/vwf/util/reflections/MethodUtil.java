package ru.adaptms.vwf.util.reflections;

import org.apache.commons.lang3.reflect.FieldUtils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Locale;

/**
 * @author ppolyakov at 21.09.2021 18:19
 */
public class MethodUtil {
    private MethodUtil() {}

    public static Field getField(Class<?> targetClass, String fieldName) throws NoSuchFieldException {
        var field = Arrays.stream(FieldUtils.getAllFields(targetClass))
                .filter(f -> fieldName.equals(f.getName()))
                .findFirst()
                .orElse(null);

        if (field == null)
            throw new NoSuchFieldException(MessageFormat.format("Field \"{0}\" cannot be found on type \"{1}\"", fieldName, targetClass.getCanonicalName()));

        return field;
    }

    public static Method getGetter( Class<?> targetClass, Field field ) throws NoSuchMethodException {
        return targetClass.getMethod( createFieldName( field.getType().equals( boolean.class ) ? "is" : "get", field ) );
    }

    public static Method getSetter( Class<?> targetClass, Field field ) throws NoSuchMethodException {
        return targetClass.getMethod( createFieldName( "set", field ), field.getType() );
    }

    private static String createFieldName( String prefix, Field field ) {
        return prefix + field.getName().substring( 0, 1 ).toUpperCase( Locale.ROOT )
                + field.getName().substring( 1 );
    }
}
