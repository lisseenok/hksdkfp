package ru.adaptms.vwf.util.filter;

import org.springframework.stereotype.Service;
import ru.adaptms.vwf.ui.component.select.SimpleOption;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 23.01.2022 02:45
 */
@Service( "def_filters" )
public class DefaultFilters {
    public List<SimpleOption> yesNo() {
        return List.of( new SimpleOption( "true", "Да" ),
                new SimpleOption( "false", "Нет" ) );
    }

    public List<SimpleOption> yesNoIndeterminate() {
        return List.of( new SimpleOption( "none", "" ),
                new SimpleOption( "true", "Да" ),
                new SimpleOption( "false", "Нет" ) );
    }

    public List<SimpleOption> create( String... keysValues ) {
        if ( keysValues.length % 2 != 0 )
            throw new IllegalStateException( "KeysValues for filter must have coupled elements." );

        List<SimpleOption> output = new ArrayList<>();
        for ( int i = 0; i < keysValues.length; i += 2 ) {
            output.add( new SimpleOption( keysValues[i], keysValues[i + 1] ) );
        }

        return output;
    }
}
