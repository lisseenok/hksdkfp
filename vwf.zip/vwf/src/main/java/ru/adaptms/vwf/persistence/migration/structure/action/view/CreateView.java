package ru.adaptms.vwf.persistence.migration.structure.action.view;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;

/**
 * Создать виртуальную view-таблицу
 *
 * @author polyakov_ps at 06.04.2023 17:51
 */
public class CreateView extends MigrationAction {

    private String viewName;
    private String nativeSql;

    /**
     * @param viewName имя view-таблицы, которую надо создать
     */
    public CreateView( String viewName, String nativeSql ) {
        this.viewName = viewName;
        this.nativeSql = nativeSql;
    }

    @Override
    public String generateSQL( String dbType ) {
        return "CREATE OR REPLACE VIEW " + viewName + " AS " + nativeSql;
    }
}
