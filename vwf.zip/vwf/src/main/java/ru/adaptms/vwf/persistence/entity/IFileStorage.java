package ru.adaptms.vwf.persistence.entity;

import ru.adaptms.vwf.util.encryption.EncryptionUtil;

import java.util.UUID;

/**
 * @author ppolyakov at 17.02.2022 21:50
 */
public interface IFileStorage extends IIdentifiable {
    FileStorageType getType();
    String getPath();
    String getAccessKey();
    String getUnencryptedSecretKey(EncryptionUtil encryptionUtil);
    String getBucket();
}
