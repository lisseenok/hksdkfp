package ru.adaptms.vwf.ui.action.success;

import lombok.Getter;
import lombok.NoArgsConstructor;

/**
 * Reloads root frame (top-level frame for mapped handler)
 *
 * @author ppolyakov at 03.02.2022 01:46
 */
@NoArgsConstructor
public class SuccessReloadRootFrame implements ISuccessAction {
    @Getter
    private String frame;

    public SuccessReloadRootFrame(String frame) {
        this.frame = frame;
    }

    @Override
    public String getAction() {
        return "reloadRootFrame";
    }
}
