package ru.adaptms.vwf.ui.action;

import ru.adaptms.vwf.ui.action.success.ISuccessAction;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Result of a listener execution
 *
 * @author ppolyakov at 03.02.2022 03:12
 */
public class ActionResult implements Serializable {
    protected String id;

    protected boolean success = true;
    protected List<ISuccessAction> actions = new ArrayList<>();
    protected List<String> globalErrors = new ArrayList<>();

    public ActionResult() {
    }

    public ActionResult( ISuccessAction action ) {
        this.actions.add( action );
    }

    public ActionResult then( ISuccessAction action ) {
        this.actions.add( action );
        return this;
    }

    public List<ISuccessAction> getActions() {
        return actions;
    }

    public void setActions( List<ISuccessAction> actions ) {
        this.actions = actions;
    }

    public String getId() {
        return id;
    }

    public void setId( String id ) {
        this.id = id;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess( boolean success ) {
        this.success = success;
    }

    public List<String> getGlobalErrors() {
        return globalErrors;
    }

    public void setGlobalErrors( List<String> globalErrors ) {
        this.globalErrors = globalErrors;
    }

    public void addGlobalError( String error ) {
        success = false;
        globalErrors.add( error );
    }

    public boolean containsResultOfType( Class<? extends ISuccessAction> actionType ) {
        return actions.stream().anyMatch( action -> action.getClass().getCanonicalName().equals( actionType.getCanonicalName() ) );
    }
}
