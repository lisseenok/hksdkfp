package ru.adaptms.vwf.util;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.persistence.dao.ICommonDao;

import java.util.Locale;

@Component
public class SpringUtils implements ApplicationContextAware {
    private static ApplicationContext applicationContext;

    public static ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        SpringUtils.applicationContext = applicationContext;
    }

    public static Object getBeanByName(String name) {
        return applicationContext.getBean(name);
    }

    public static ICommonDao dao() {
        return (ICommonDao) getBeanByName("commonDao");
    }

    public static SecurityContext getCurrentSecurityContext() {
        return SecurityContextHolder.getContext();
    }

    public static <T> T getInstance(Class<T> beanClass) {
        String beanName;

        try {
            return applicationContext.getBean(beanClass);
        } catch (Exception e) {
        }

        if (beanClass.isAnnotationPresent(Component.class)
                && !StringUtils.isBlank(beanClass.getAnnotation(Component.class).value())) {
            beanName = beanClass.getAnnotation(Component.class).value();
        } else if (beanClass.isAnnotationPresent(Service.class)
                && !StringUtils.isBlank(beanClass.getAnnotation(Service.class).value())) {
            beanName = beanClass.getAnnotation(Service.class).value();
        } else if (beanClass.isAnnotationPresent(Repository.class)
                && !StringUtils.isBlank(beanClass.getAnnotation(Repository.class).value())) {
            beanName = beanClass.getAnnotation(Repository.class).value();
        } else if (beanClass.isAnnotationPresent(Controller.class)
                && !StringUtils.isBlank(beanClass.getAnnotation(Controller.class).value())) {
            beanName = beanClass.getAnnotation(Controller.class).value();
        } else {
            beanName = beanClass.getSimpleName().substring(0, 1).toLowerCase(Locale.ROOT) + beanClass.getSimpleName().substring(1);
        }

        return (T) SpringUtils.getBeanByName(beanName);
    }
}
