package ru.adaptms.vwf.script.groovy;

import javax.script.Bindings;

/**
 * @author ppolyakov at 29.01.2022 17:29
 */
public abstract class GroovyScript {
    protected Bindings bindings;

    public GroovyScript( Bindings bindings ) {
        this.bindings = bindings;
    }

    public abstract Object execute();
}
