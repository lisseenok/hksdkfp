package ru.adaptms.vwf.persistence.dao;

import org.adaptms.hqlbuilder.builder.HQLBuilder;
import org.hibernate.Hibernate;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ru.adaptms.vwf.persistence.entity.IEntity;

import java.io.Serializable;
import java.util.List;

/**
 * Имплементация базового DAO для всех операций
 *
 * @author pavelpolyakov
 * @see IBaseDao
 */
@Repository( "baseDao" )
@Transactional
public class BaseDao implements IBaseDao {

    public SessionFactory sessionFactory;

    public BaseDao() {}

    @Transactional
    public <T extends IEntity> T save( T entity) {
        try {
            // пытаемся выполнить saveOrUpdate, если не вышло - мержим, т.к. есть более новая копия в памяти
            try {
                sessionFactory.getCurrentSession().saveOrUpdate( entity );
            } catch (NonUniqueObjectException e) {
                sessionFactory.getCurrentSession().merge(entity);
            }
        } catch ( NullPointerException npe ) {
            System.err.println( "NULL in save method" );
        }
        return entity;
    }

    @Override
    @Transactional( readOnly = true )
    public <T extends IEntity, PK extends Serializable> T find(Class<T> type, PK id) {
        return  (T) sessionFactory.getCurrentSession().get(type, id);
    }

    /*@Override
    public <T extends IEntity> T find( Long id ) {
        HQLBuilder builder = new HQLBuilder().select().from( EntityDescriptor.class, "ed" )
                .where( HQLBuilder.eq( "ed", "id", id ) );

        Query<EntityDescriptor> query = createQuery( builder );

        query.setMaxResults( 1 );
        return ( T ) query.uniqueResult().getEntity();
    }*/

    @Override
    @Transactional( propagation = Propagation.REQUIRED )
    public <T extends IEntity> List<T> findAll( Class<T> type ) {
        Query<T> query = sessionFactory.getCurrentSession()
                .createQuery( HQLBuilder.select( type, "e" ).build(), type );
        return query.list();
    }

    @Override
    @Transactional( propagation = Propagation.REQUIRES_NEW )
    public <T extends IEntity> void delete( T entity ) {
        sessionFactory.getCurrentSession().delete( entity );
    }

    @Override
    @Transactional( propagation = Propagation.REQUIRED )
    public <T extends IEntity> void merge( T entity ) {
        sessionFactory.getCurrentSession().merge( entity );
    }

    /** Очистить текущую сессию */
    @Override
    public void clear() {
        sessionFactory.getCurrentSession().clear();
    }

    /**
     * Обновить данные сущности
     * @param entity сущность
     * @param <T> тип
     */
    @Override
    @Transactional( propagation = Propagation.REQUIRED )
    public <T extends IEntity> void refresh( T entity ) {
        sessionFactory.getCurrentSession().refresh( entity );
    }

    /**
     * Мягкая инициализация полей ленивой сущности
     * @param entity lazy сущность (только с Id), которую надо инициализировать
     * @param <T> тип
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public <T extends IEntity> void softInitialize( T entity ) {
        if ( ! Hibernate.isInitialized( entity ) ) {
            Hibernate.initialize( entity );
        }
    }

    /**
     * Создание запроса из билдера
     * @param builder билдер
     * @param <T> ожидаемый тип
     * @return готовый запрос
     */
    protected <T> Query<T> createQuery( HQLBuilder builder ) {
        Query<T> query = sessionFactory.getCurrentSession().createQuery( builder.build() );
        if ( builder.getVariables() != null ) {
            for ( String name : builder.getVariables().keySet() ) {
                query.setParameter( name, builder.getVariables().get( name ) );
            }
        }
        return query;
    }

    @Autowired
    public void setSessionFactory( SessionFactory sessionFactory ) {
        this.sessionFactory = sessionFactory;
    }
}
