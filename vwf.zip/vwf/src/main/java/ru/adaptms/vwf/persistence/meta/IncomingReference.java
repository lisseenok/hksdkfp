package ru.adaptms.vwf.persistence.meta;

import lombok.Getter;
import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.persistence.entity.IEntity;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author ppolyakov at 13.04.2022 18:24
 */
public class IncomingReference {

    @Getter private final String fieldName;
    @Getter private final Class<? extends BaseEntity> targetClass;
    @Getter private final EntityMeta sourceMeta;

    public IncomingReference( String fieldName, Class<? extends BaseEntity> targetClass, EntityMeta sourceMeta ) {
        this.fieldName = fieldName;
        this.targetClass = targetClass;
        this.sourceMeta = sourceMeta;
    }
}
