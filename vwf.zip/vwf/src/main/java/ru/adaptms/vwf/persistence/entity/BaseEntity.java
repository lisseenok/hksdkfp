package ru.adaptms.vwf.persistence.entity;

import lombok.Getter;
import lombok.Setter;
import org.adaptms.hqlbuilder.property.EntityPath;
import ru.adaptms.vwf.persistence.entity.listener.EntityEventListener;
import ru.adaptms.vwf.persistence.entity.listener.EventType;
import ru.adaptms.vwf.persistence.meta.EntityMeta;
import ru.adaptms.vwf.persistence.meta.EntityRegistry;
import ru.adaptms.vwf.persistence.meta.Meta;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.util.LoggingUtil;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PostLoad;
import jakarta.persistence.PostPersist;
import jakarta.persistence.PostRemove;
import jakarta.persistence.PostUpdate;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreRemove;
import jakarta.persistence.PreUpdate;
import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

/**
 * @author ppolyakov at 06.09.2021 14:57
 */
@Getter
@Setter
@MappedSuperclass
public abstract class BaseEntity implements IEntity, Serializable {

    public static class DSL extends EntityPath {
        protected DSL( String input ) {
            super( input );
        }
        public EntityPath id() { return property( "id" ); }
        public EntityPath created() { return property( "created" ); }
        public EntityPath updated() { return property( "updated" ); }
        public EntityPath uuid() { return property( "uuid" ); }

        protected EntityPath property( String property) {
            return new EntityPath( step( property ) );
        }
    }

//    @Transient
//    private Map<String, Object> propertyCache = new HashMap<>();

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    protected Long id;

    @Column( name = "entity_created" )
    protected Date created = new Date();

    @Column( name = "entity_updated" )
    protected Date updated = new Date();

    @Column(name = "entity_uuid")
    protected UUID uuid = UUID.randomUUID();

    @PostLoad
    public void firePostLoadEventListeners() {
        fireEventListeners( EventType.POST_LOAD );
    }

    @PrePersist
    public void firePrePersistEventListeners() {
        fireEventListeners( EventType.PRE_PERSIST );
    }

    @PreUpdate
    public void firePreUpdateEventListeners() {
        fireEventListeners( EventType.PRE_UPDATE );
    }

    @PreRemove
    public void firePreRemoveEventListeners() {
        fireEventListeners( EventType.PRE_REMOVE );
    }

    @PostPersist
    public void firePostPersistEventListeners() {
        fireEventListeners( EventType.POST_PERSIST );
    }

    @PostUpdate
    public void firePostUpdateEventListeners() {
        fireEventListeners( EventType.POST_UPDATE );
    }

    @PostRemove
    public void firePostRemoveEventListeners() {
        fireEventListeners( EventType.POST_REMOVE );
    }

    /**
     * Execute all persistence state change listeners
     * @param type event type
     */
    private void fireEventListeners( EventType type ) {
        List<Method> listeners = getMeta().getEventListeners().get( type.name() );
        if ( listeners == null || listeners.isEmpty() ) return;

        for ( Method listener : listeners ) {
            try {
                listener.invoke( this );
            } catch ( IllegalAccessException | InvocationTargetException e ) {
                LoggingUtil.error( this.getClass(), "Couldn't invoke listener method \"" + listener.getName() + "\".", e );
            }
        }
    }

    @EntityEventListener( EventType.PRE_UPDATE )
    public void onSaveOrUpdateSetUpdateDate() {
        this.setUpdated( new Date() );
    }

    public boolean isNew() {
        return id == null;
    }

    @Override
    public String toString() {
        return "[" + ( getId() != null ? "id: " + getId() : "новый" ) + "] " + getEntityName();
    }

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof BaseEntity ) ) return false;
        BaseEntity that = ( BaseEntity ) o;
        return Objects.equals( getId(), that.getId() );
    }

    @Override
    public int hashCode() {
        return Objects.hash( getId() );
    }

    public String getEntityName() {
        if ( this.getClass().isAnnotationPresent( Meta.class ) ) {
            return this.getClass().getAnnotation( Meta.class ).title() + " (" + this.getClass().getSimpleName() + ")";
        } else {
            return this.getClass().getSimpleName();
        }
    }

    public EntityMeta getMeta() {
        return EntityRegistry.instance().getMetaByClass( this.getClass() );
    }

    public String getPubTitle(I18NService i18NService) {
        return getEntityName();
    }

    public String getIdAsString() {
        return String.valueOf(getId());
    }
}
