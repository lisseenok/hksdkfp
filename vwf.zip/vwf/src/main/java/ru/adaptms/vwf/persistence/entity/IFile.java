package ru.adaptms.vwf.persistence.entity;

import java.util.UUID;

/**
 * @author ppolyakov at 17.02.2022 21:50
 */
public interface IFile extends IIdentifiable {
    UUID getGuidInStorage();
    String getFileName();

    String getMimeType();

    Integer getSize();

    String getHash();

    boolean hasContent();
    boolean isUsesId();

    IFileStorage getStorage();
}
