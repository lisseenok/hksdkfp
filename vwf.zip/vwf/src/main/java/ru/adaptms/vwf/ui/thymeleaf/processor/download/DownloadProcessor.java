package ru.adaptms.vwf.ui.thymeleaf.processor.download;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.templatemode.TemplateMode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class DownloadProcessor extends AbstractElementModelProcessor {

    private static final String ELEMENT_NAME = "download";
    private static final int PRECEDENCE = 800;

    public DownloadProcessor( final String dialectPrefix ) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                true,
                null,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess( ITemplateContext context,
                              IModel model,
                              IElementModelStructureHandler structureHandler ) {
        final IModelFactory modelFactory = context.getModelFactory();

        Map<String, String> attributes = new HashMap<>();
        final ITemplateEvent formEvent = model.get(0);
        if ( formEvent instanceof IOpenElementTag ) {
            IOpenElementTag formElement = ( IOpenElementTag ) formEvent;
            Map<String, String> incomingAttrs = formElement.getAttributeMap();

            String[] standardAttrNames = new String[]{"id", "class", "style"};

            for ( String attrName : standardAttrNames ) {
                if ( incomingAttrs.containsKey( attrName ) )
                    attributes.put( attrName, incomingAttrs.get( attrName ) );
                else
                    attributes.put( "th:" + attrName, incomingAttrs.get( "th:" + attrName ) );
            }

            attributes.put( "href", "javascript:" );
            attributes.put( "onclick", "downloadFile( this.getAttribute( 'data-vwf-action' ) )" );

            if ( incomingAttrs.containsKey( "action" ) ) {
                attributes.put( "data-vwf-action", incomingAttrs.get( "action" ) );
            } else if ( incomingAttrs.containsKey( "th:action" ) ) {
                attributes.put( "th:data-vwf-action", incomingAttrs.get( "th:action" ) );
            } else {
                throw new IllegalStateException( "<ui:download> doesn't have required attribute 'action'." );
            }
        }

        IOpenElementTag formOpen = modelFactory
                .createOpenElementTag( "a", attributes,
                        AttributeValueQuotes.DOUBLE,
                        false );

        model.replace(0, formOpen);
        model.replace( model.size() - 1, modelFactory.createCloseElementTag( "a" ) );
    }
}
