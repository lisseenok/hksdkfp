package ru.adaptms.vwf.persistence.migration.types;

import java.util.Date;

/**
 * @author ppolyakov at 05.12.2021 15:37
 */
public enum ColumnType {
    BIT( "BIT", null, "BOOLEAN", null, "BIT", null, Boolean.class ),
    SHORT( "SMALLINT", null, "SMALLINT", null, "SMALLINT", null, Short.class ),
    INT( "INT", null, "INTEGER", null, "INT", null, Integer.class ),
    LONG( "BIGINT", null, "BIGINT", null, "NUMERIC", 19, Long.class ),
    STRING( "VARCHAR", 255, "VARCHAR", 255, "NVARCHAR", 255, String.class ),
    UUID( "BINARY", 16, "UUID", null, "UNIQUEIDENTIFIER", null, java.util.UUID.class ),
    TEXT( "LONGTEXT", null, "TEXT", null, "NVARCHAR", -1, String.class ),
    JSON( "LONGTEXT", null, "JSON", null, "NVARCHAR", -1, Object.class ),
    BLOB( "MEDIUMBLOB", null, "BYTEA", null, "VARBINARY", -1, byte[].class ),
    DATE( "DATE", null, "DATE", null, "DATE", null, Date.class ),
    TIME( "TIME", null, "TIME", null, "TIME", null, Date.class ),
    DATETIME( "DATETIME", null, "TIMESTAMP", null, "DATETIME", null, Date.class ),
    TIMESTAMP( "TIMESTAMP", null, "TIMESTAMP", null, "TIMESTAMP", null, Date.class );

    private final String mySQL;
    private final String pSQL;
    private final String msSQL;
    private final Integer defaultLengthMySQL; // -1 -> max, null -> nothing
    private final Integer defaultLengthPSQL;
    private final Integer defaultLengthMSSQL;
    private final Class<?> defaultValueType;

    ColumnType( String mySQL, Integer defaultLengthMySQL, String pSQL, Integer defaultLengthPSQL, String msSQL, Integer defaultLengthMSSQL, Class<?> defaultValueType ) {
        this.mySQL = mySQL;
        this.pSQL = pSQL;
        this.msSQL = msSQL;
        this.defaultLengthMySQL = defaultLengthMySQL;
        this.defaultLengthPSQL = defaultLengthPSQL;
        this.defaultLengthMSSQL = defaultLengthMSSQL;
        this.defaultValueType = defaultValueType;
    }

    public String getMySQL() {
        return mySQL;
    }

    public String getpSQL() {
        return pSQL;
    }

    public String getMsSQL() {
        return msSQL;
    }

    public String getType( String dbType ) {
        if ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) ) {
            return getMySQL();
        } else if ( dbType.matches( DBType.MSSQL ) ) {
            return getMsSQL();
        } else if ( dbType.matches( DBType.PSQL ) ) {
            return getpSQL();
        }
        throw new IllegalStateException( "No such DB type: " + dbType );
    }

    public Integer getDefaultLengthMySQL() {
        return defaultLengthMySQL;
    }

    public Integer getDefaultLengthPSQL() {
        return defaultLengthPSQL;
    }

    public Integer getDefaultLengthMSSQL() {
        return defaultLengthMSSQL;
    }

    public Integer getDefaultLength( String dbType ) {
        if ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) ) {
            return getDefaultLengthMySQL();
        } else if ( dbType.matches( DBType.MSSQL ) ) {
            return getDefaultLengthMSSQL();
        } else if ( dbType.matches( DBType.PSQL ) ) {
            return getDefaultLengthPSQL();
        }
        throw new IllegalStateException( "No such DB type: " + dbType );
    }

    public Class<?> getDefaultValueType() {
        return defaultValueType;
    }
}
