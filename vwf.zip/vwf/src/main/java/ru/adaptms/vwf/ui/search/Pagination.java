package ru.adaptms.vwf.ui.search;

import java.io.Serializable;

/**
 * @author ppolyakov at 22.01.2022 17:11
 */
public class Pagination implements Serializable {
    private boolean more = false;

    public Pagination() {
    }

    public boolean isMore() {
        return more;
    }

    public void setMore( boolean more ) {
        this.more = more;
    }
}
