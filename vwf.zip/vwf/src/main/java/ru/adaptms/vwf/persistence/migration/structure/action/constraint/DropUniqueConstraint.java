package ru.adaptms.vwf.persistence.migration.structure.action.constraint;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Удалить ограничение на уникальность
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropUniqueConstraint extends MigrationAction {

    private String tableName;
    private String uniqueConstraint;

    /**
     * @param tableName таблица, в которой удаляем
     * @param ucToDrop имя ограничения
     */
    public DropUniqueConstraint( String tableName, String ucToDrop ) {
        this.tableName = tableName;
        this.uniqueConstraint = ucToDrop;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder( "ALTER TABLE " );
        builder.append( tableName )
                .append( " DROP " );

        if ( dbType.matches( DBType.MYSQL_8 ) || dbType.matches( DBType.MYSQL_5 ) )
            builder.append( "INDEX " ); // в мускле это просто обертка над индексом
        else if ( dbType.matches( DBType.MSSQL ) || dbType.matches( DBType.PSQL ) )
            builder.append( "CONSTRAINT " ); // во всех остальных - отдельное ограничение
        else
            throw new IllegalStateException( "No such DB type: " + dbType );

        builder.append( uniqueConstraint );

        return  builder.toString();
    }
}
