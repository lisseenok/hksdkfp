package ru.adaptms.vwf.util;

import jakarta.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.error.IErrorLogger;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 25.04.2022 13:03
 */
@Service
public class LoggingUtil {
    public static final String LEVEL_DEBUG = "debug";
    public static final String LEVEL_INFO = "info";
    public static final String LEVEL_ERROR = "error";
    private static IErrorLogger errorLogger;
    private static Map<Class<?>, Logger> configuredLoggers = new HashMap<>();
    private List<IErrorLogger> errorLoggerCandidates;

    public static LoggingUtil instance() {
        return SpringUtils.getInstance(LoggingUtil.class);
    }

    public static void info(Class<?> targetClass, String message, Throwable throwable) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).info(message, throwable);
    }

    public static void info(Class<?> targetClass, String message) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).info(message);
    }

    public static void debug(Class<?> targetClass, String message, Throwable throwable) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))
                || LEVEL_INFO.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).debug(message, throwable);
    }

    public static void debug(Class<?> targetClass, String message) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))
                || LEVEL_INFO.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).debug(message);
    }

    public static void warn(Class<?> targetClass, String message, Throwable throwable) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))
                || LEVEL_INFO.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).warn(message, throwable);
    }

    public static void warn(Class<?> targetClass, String message) {
        if (LEVEL_ERROR.equals(AppDefines.get(AppDefines.LOG_LEVEL))
                || LEVEL_INFO.equals(AppDefines.get(AppDefines.LOG_LEVEL))) return;
        getLogger(targetClass).warn(message);
    }

    public static void error(Class<?> targetClass, String message, Throwable throwable) {
        getLogger(targetClass).error(message, throwable);
    }

    public static void error(Class<?> targetClass, String message) {
        getLogger(targetClass).error(message);
    }

    public static void error(Class<?> targetClass, Throwable throwable) {
        getLogger(targetClass).error(throwable.getMessage(), throwable);
    }

    public static void exception(String source, Throwable throwable) {
        if (errorLogger == null) {
            error(LoggingUtil.class, "Cannot log exception before app is fully initialized. The exception was: ");
            return;
        }

        errorLogger.logError(source, throwable);
    }

    private static Logger getLogger(Class<?> targetClass) {
        configuredLoggers.computeIfAbsent(targetClass, m -> LoggerFactory.getLogger(targetClass));
        return configuredLoggers.get(targetClass);
    }

    @Autowired(required = false)
    public void setErrorLoggerCandidates(List<IErrorLogger> errorLoggerCandidates) {
        this.errorLoggerCandidates = errorLoggerCandidates;
    }

    @PostConstruct
    public void init() {
        if (errorLoggerCandidates == null || errorLoggerCandidates.isEmpty()) return;
        errorLogger = errorLoggerCandidates.get(0);
    }
}
