package ru.adaptms.vwf.ui.action.success;

/**
 * Do nothing
 *
 * @author ppolyakov at 03.02.2022 01:46
 */
public class SuccessDoNothing implements ISuccessAction {
    @Override
    public String getAction() {
        return "nth";
    }
}
