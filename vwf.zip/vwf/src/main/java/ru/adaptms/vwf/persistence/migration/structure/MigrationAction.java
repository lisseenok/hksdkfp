package ru.adaptms.vwf.persistence.migration.structure;

/**
 * Абстрактное действие для любой миграции
 *
 * @author ppolyakov at 05.12.2021 15:28
 */
public abstract class MigrationAction {

    protected String[] dbTypes;

    /**
     * Собственно формирование выражения SQL для осуществления действия
     * @param dbType тип СУБД - будет передан сервисом из db.properties (можно проверять через dbType.matches( DBType.<...> ) )
     * @return готовое SQL-выражение
     */
    public abstract String generateSQL( String dbType );

    /**
     * Задать типы СУБД, для которых это действие будет применяться
     * @param dbTypes выражение, должно соответствовать чему-то из DBType
     */
    public void setDbTypes( String... dbTypes ) {
        this.dbTypes = dbTypes;
    }

    public String[] getDbTypes() {
        return dbTypes;
    }
}
