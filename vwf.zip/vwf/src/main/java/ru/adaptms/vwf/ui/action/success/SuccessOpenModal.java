package ru.adaptms.vwf.ui.action.success;

import ru.adaptms.vwf.ui.util.uri.UriBuilder;
import ru.adaptms.vwf.ui.util.uri.UriUtil;

/**
 * Open modal for given handler
 *
 * @author ppolyakov at 03.02.2022 01:46
 */
public class SuccessOpenModal implements ISuccessAction {

    private String uri;

    public SuccessOpenModal( UriBuilder modalUriBuilder ) {
        this.uri = modalUriBuilder.build();
    }

    public SuccessOpenModal( String modalUri ) {
        this.uri = UriUtil.instance().prependContextPath( modalUri );
    }

    public String getUri() {
        return uri;
    }

    public void setUri( String uri ) {
        this.uri = uri;
    }

    @Override
    public String getAction() {
        return "openModal";
    }
}
