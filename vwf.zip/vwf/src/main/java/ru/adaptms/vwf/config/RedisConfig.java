package ru.adaptms.vwf.config;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import redis.clients.jedis.JedisPoolConfig;

@Getter @Setter
@Configuration("jedisConfig")
@EnableRedisRepositories(basePackages = {"ru.adaptms"})
@RequiredArgsConstructor
@ConfigurationProperties(prefix = "redis")
public class RedisConfig {

    private String host;

    private Integer port;

    @Bean
    @ConditionalOnProperty(name = "redis.enabled")
    public JedisConnectionFactory jedisConnectionFactory() {
        var poolConfig = new JedisPoolConfig();
        poolConfig.setMaxTotal(10);
        poolConfig.setTestOnBorrow(true);
        poolConfig.setTestOnReturn(true);

        var conf = new RedisStandaloneConfiguration();
        conf.setHostName(host);
        conf.setPort(port);

        var clientConf = JedisClientConfiguration.builder()
                .usePooling()
                .poolConfig(poolConfig)
                .build();

        return new JedisConnectionFactory(conf, clientConf);
    }

    @Bean
    @ConditionalOnProperty(name = "redis.enabled")
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(jedisConnectionFactory());
        return template;
    }
}
