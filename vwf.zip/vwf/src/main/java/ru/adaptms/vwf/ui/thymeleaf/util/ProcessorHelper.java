package ru.adaptms.vwf.ui.thymeleaf.util;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.util.input.CommonValidators;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;
import ru.adaptms.vwf.util.FormattingUtil;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;

/**
 * @author polyakov_ps at 02.11.2023 12:51
 */
@SuppressWarnings("unchecked")
public class ProcessorHelper {

    public static void applyParams(UriBuilder action, Map<String, String> attributes,
                                   ITemplateContext context, IStandardExpressionParser parser,
                                   @Nullable HandlerMeta meta) {
        var allParams = getParameterMap(attributes, context, parser);

        // apply all params to UriBuilder
        for (Map.Entry<String, Object> resultingParam : allParams.entrySet()) {
            action.parameter(meta == null ? resultingParam.getKey() : meta.getParamCode(resultingParam.getKey()), resultingParam.getValue());
        }
    }

    public static Map<String, Object> getParameterMap(Map<String, String> attributes,
                                                      ITemplateContext context, IStandardExpressionParser parser) {
        var allParams = new HashMap<String, Object>();

        // add standard params from "params="${...}"" attribute
        if (attributes.containsKey("params")) {
            var params = (Map<String, Object>) SpringELUtil.execute(attributes.get("params"), context, parser);

            if (params.containsKey(AbstractUIHandler.PARAM_ACTION))
                throw new IllegalArgumentException("It is forbidden to use \"" + AbstractUIHandler.PARAM_ACTION + "\" as listener param name! Manually setting listener \"" + AbstractUIHandler.PARAM_ACTION + "\" parameter will result in replacing the original action identifier. You have attempted to set this parameter in \"param\" attribute value.");

            allParams.putAll(params);
        }

        // read params from "p:...="${...}"" or "lp:...="${...}"" attributes
        for (Map.Entry<String, String> attr : attributes.entrySet()) {
            if (!attr.getKey().startsWith("p:") && !attr.getKey().startsWith("lp:")) continue;

            if (("lp:" + AbstractUIHandler.PARAM_ACTION).equals(attr.getKey()))
                throw new IllegalArgumentException("It is forbidden to use \"" + AbstractUIHandler.PARAM_ACTION + "\" as listener param name! Manually setting listener \"" + AbstractUIHandler.PARAM_ACTION + "\" parameter will result in replacing the original action identifier. You have attempted to set this parameter via \"lp:action\" attribute.");

            var isListenerParam = attr.getKey().startsWith("lp:");

            var key = attr.getKey().split(":")[1];
            var value = SpringELUtil.execute(attr.getValue(), context, parser);

            allParams.put(isListenerParam ? "l_" + key : key, value);
        }

        return allParams;
    }

    public static String formatMaxFileSize(long sizeInBytes) {
        int i;
        double bytes = sizeInBytes;

        for (i = 0; bytes >= 1024 && i < 4; i++)
            bytes /= 1024;

        return FormattingUtil.instance().formatDecimal(bytes, "#.##") + " "
                + I18NService.instance().getMessage(CommonValidators.fileSizeUnitKeys()[i]);
    }
}
