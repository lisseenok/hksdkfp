package ru.adaptms.vwf.ui.form;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.sun.istack.NotNull;
import org.apache.commons.lang3.StringUtils;
import ru.adaptms.vwf.ui.action.ActionResult;
import ru.adaptms.vwf.ui.action.success.ISuccessAction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Result if listener on submission form
 *
 * @author ppolyakov at 02.01.2022 20:43
 */
public class SubmissionResult extends ActionResult {

    private Map<String, List<String>> fieldErrors = new HashMap<>();

    @JsonIgnore
    private String handlerId;

    public SubmissionResult( ISuccessAction action ) {
        super( action );
    }

    public SubmissionResult( String handlerId, ISuccessAction action ) {
        super( action );
        this.handlerId = handlerId;
    }

    public SubmissionResult then( ISuccessAction action ) {
        return ( SubmissionResult ) super.then( action );
    }

    public Map<String, List<String>> getFieldErrors() {
        return fieldErrors;
    }

    public void setFieldErrors( Map<String, List<String>> fieldErrors ) {
        this.fieldErrors = fieldErrors;
    }

    public void addFieldError( String fieldId, String error ) {
        if ( !StringUtils.isBlank( handlerId ) )
            fieldId = fieldId + "_" + handlerId;

        success = false;
        if ( !fieldErrors.containsKey( fieldId ) )
            fieldErrors.put( fieldId, new ArrayList<>() );
        fieldErrors.get( fieldId ).add( error );
    }

    public void validateGlobal( Object input, String errorMessage, Validator validator ) {
        if ( !validator.isValid( input ) )
            addGlobalError( errorMessage );
    }

    public void validateField( Object input, String fieldId, String errorMessage, Validator validator ) {
        if ( !validator.isValid( input ) )
            addFieldError( fieldId, errorMessage );
    }

    public static SubmissionResult fromActionResult( @NotNull ActionResult result ) {
        SubmissionResult submissionResult = new SubmissionResult( result.getActions().get( 0 ) );
        submissionResult.setId( result.getId() );
        submissionResult.setSuccess( result.isSuccess() );
        submissionResult.setGlobalErrors( result.getGlobalErrors() );
        return submissionResult;
    }

    public interface Validator {
        boolean isValid( Object input );
    }
}
