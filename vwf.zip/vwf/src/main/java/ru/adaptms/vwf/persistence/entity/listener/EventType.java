package ru.adaptms.vwf.persistence.entity.listener;

/**
 * @author ppolyakov at 19.05.2022 20:21
 */
public enum EventType {
    POST_LOAD,
    PRE_PERSIST,
    PRE_UPDATE,
    PRE_REMOVE,
    POST_PERSIST,
    POST_UPDATE,
    POST_REMOVE
}
