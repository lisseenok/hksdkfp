package ru.adaptms.vwf.ui.thymeleaf.processor.icon;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.component.tabpanel.TabPanel;
import ru.adaptms.vwf.ui.util.SpringELUtil;

/**
 * @author ppolyakov at 02.11.2023 21:04
 */
public class IconProcessor extends AbstractUITagProcessor {
    public static final String LISTENER_PARAM_TAB = TabPanel.LISTENER_PARAM;

    private static final String ELEMENT_NAME = "icon";
    private static final int PRECEDENCE = 1000;

    public IconProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "type")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        outgoingContext.setVariable("iconClass", SpringELUtil.execute(elementTag.getAttributeValue("type"), incomingContext, parser));

        if (elementTag.hasAttribute("id"))
            outgoingContext.setVariable("id", SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser));

        if (elementTag.hasAttribute("class"))
            outgoingContext.setVariable("wrapperClass", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));

        if (elementTag.hasAttribute("style"))
            outgoingContext.setVariable("wrapperStyle", SpringELUtil.execute(elementTag.getAttributeValue("style"), incomingContext, parser));

        structureHandler.replaceWith(getTemplate(outgoingContext), false);
    }

}
