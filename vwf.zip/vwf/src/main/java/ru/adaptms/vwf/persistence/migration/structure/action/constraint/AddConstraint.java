package ru.adaptms.vwf.persistence.migration.structure.action.constraint;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;

/**
 * Добавление ограничения
 *
 * @author ppolyakov at 11.12.2021 18:47
 */
public class AddConstraint extends MigrationAction {

    private String tableName;
    private DBConstraint constraint;

    /**
     * @param tableName название таблицы, в которую будем добавлять
     * @param constraintToAdd дефиниция ограничения
     */
    public AddConstraint( String tableName, DBConstraint constraintToAdd ) {
        this.tableName = tableName;
        this.constraint = constraintToAdd;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder();

        builder.append( "ALTER TABLE " )
                .append( tableName )
                .append( " ADD CONSTRAINT " );

        constraint.apply( dbType, builder );

        return builder.toString();
    }
}
