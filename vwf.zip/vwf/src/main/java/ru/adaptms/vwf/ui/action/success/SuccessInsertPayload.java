package ru.adaptms.vwf.ui.action.success;

/**
 * Legacy support action. Allows inserting content into any DIV with identifier.
 * Useful for layout manipulations (updating name etc). Layout doesn't have a handler representation
 *
 * @author ppolyakov at 29.01.2022 16:40
 */
public class SuccessInsertPayload implements ISuccessAction {

    private String targetId;
    private String payload;

    public SuccessInsertPayload( String targetId, String payload ) {
        this.targetId = targetId;
        this.payload = payload;
    }

    @Override
    public String getAction() {
        return "insertPayload";
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId( String targetId ) {
        this.targetId = targetId;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload( String payload ) {
        this.payload = payload;
    }
}
