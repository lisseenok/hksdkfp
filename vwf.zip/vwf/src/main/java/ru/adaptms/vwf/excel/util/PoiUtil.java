package ru.adaptms.vwf.excel.util;

import org.apache.poi.ss.usermodel.Cell;

/**
 * @author ppolyakov at 08.01.2022 18:46
 */
public class PoiUtil {
    public static String getCellValue( Cell cell ) {
        if ( cell != null ) {
            switch ( cell.getCellType() ) {
                case STRING:
                    return cell.getRichStringCellValue().getString().trim();
                case NUMERIC:
                    double cellDouble = Math.abs( cell.getNumericCellValue() );
                    double floorDouble = Math.floor( cellDouble );
                    if ( cellDouble == floorDouble ) {
                        return Long.toString( Math.round( cell.getNumericCellValue() ) );
                    } else {
                        return Double.toString( cell.getNumericCellValue() );
                    }
                case FORMULA:
                    try {
                        return cell.getRichStringCellValue().toString().trim();
                    } catch ( Exception e ) { // if formula does not return string we get exception
                        try {
                            return Double.toString( cell.getNumericCellValue() ); // lets try number
                        } catch (Exception e1) {
                            return null;
                        }
                    }
                default:
                    return null;
            }
        }
        return null;
    }
}
