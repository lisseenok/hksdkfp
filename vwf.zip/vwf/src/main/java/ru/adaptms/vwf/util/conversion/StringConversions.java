package ru.adaptms.vwf.util.conversion;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.SpringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author ppolyakov at 04.01.2022 21:56
 */
@Service("framework_conversionsUtil")
public class StringConversions {
    public static StringConversions instance() {
        return SpringUtils.getInstance(StringConversions.class);
    }

    private Map<Class<?>, ConversionType> typeRegistry = new HashMap<>();

    public <T> T convert(String input, Class<T> type) {
        ConversionType conversionType = typeRegistry.get(type);
        if (conversionType != null)
            return (T) conversionType.doConvert(input);
        return null;
    }

    public <T> T convert(String input, CustomConversion conversion) {
        return (T) conversion.convert(input);
    }

    @Autowired
    public void setTypes(List<ConversionType> types) {
        if (types != null) {
            for (ConversionType type : types) {
                typeRegistry.put(type.getTargetClass(), type);
            }
        }
    }

    public boolean toBoolean(String source) {
        return convert(source, boolean.class);
    }

    public interface CustomConversion {
        Object convert(String input);
    }
}
