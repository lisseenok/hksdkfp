package ru.adaptms.vwf.ui.component.tabpanel;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.*;

/**
 * @author ppolyakov at 12.03.2022 16:05
 */
@Getter @Setter
public class TabPanel implements Serializable {
    public static final String LISTENER_PARAM = "tab";

    private String listener;
    private String activeTab;
    private boolean disabled = false;
    private Map<String, TextTab> tabs = new HashMap<>();

    public TabPanel(String listener) {
        setListener(listener);
    }

    public TabPanel activeTab(String id) {
        setActiveTab(id);
        return this;
    }

    public TabPanel disabled() {
        setDisabled(true);
        return this;
    }

    public TabPanel addTextTab(String id, String label) {
        textTab(id, label);
        return this;
    }

    public TabPanel addSpelTab(String id, String label) {
        spelTab(id, label);
        return this;
    }

    public TextTab textTab(String id, String label) {
        getTabs().put(id, new TextTab(id, label, getTabs().size()));
        return getTabs().get(id);
    }

    public SpelTab spelTab(String id, String label) {
        getTabs().put(id, new SpelTab(id, label, getTabs().size()));
        return (SpelTab) getTabs().get(id);
    }

    public TextTab getTab(String id) {
        return getTabs().get(id);
    }

    public Collection<TextTab> getTabList() {
        List<TextTab> tabs = new ArrayList<>(getTabs().values());
        tabs.sort(Comparator.comparing(TextTab::getOrder));
        return tabs;
    }
}
