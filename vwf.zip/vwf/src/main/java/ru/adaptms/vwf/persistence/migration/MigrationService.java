package ru.adaptms.vwf.persistence.migration;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.config.PersistenceConfig;
import ru.adaptms.vwf.persistence.migration.structure.AbstractMigration;
import ru.adaptms.vwf.persistence.migration.structure.ExecuteAfter;
import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.structure.action.SimpleAction;
import ru.adaptms.vwf.persistence.migration.structure.action.table.CreateTable;
import ru.adaptms.vwf.persistence.migration.structure.action.util.DBActionUtil;
import ru.adaptms.vwf.persistence.migration.structure.db.Columns;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTable;
import ru.adaptms.vwf.persistence.migration.types.DBType;
import ru.adaptms.vwf.persistence.migration.version.PlatformVersion;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.net.NetworkInterface;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;

/**
 * Database migration service. Reads all migration definitions and executes them in order if they were not executed before.
 *
 * @author ppolyakov at 05.12.2021 15:04
 */

@Service
@RequiredArgsConstructor
public class MigrationService {

    private final ReflectionsUtil reflectionsUtil;
    private final PersistenceConfig persistenceConfig;

    /**
     * Execute a migration
     */
    public void migrate() {
        LoggingUtil.info(MigrationService.class, "Beginning DB migrations...");

        Throwable exception = null;

        var dbType = persistenceConfig.getType();
        var dataSourceUrl = persistenceConfig.getUrl();
        var dataSourceDefaultSchema = persistenceConfig.getDataSourceDefaultSchema();
        var dataSourceUsername = persistenceConfig.getUsername();
        var dataSourcePassword = persistenceConfig.getPassword();

        try {
            // select DB type and init the driver for it
            if (dbType.matches(DBType.MYSQL_5) || dbType.matches(DBType.MYSQL_8))
                Class.forName("com.mysql.cj.jdbc.Driver");
            else if (dbType.matches(DBType.PSQL))
                Class.forName("org.postgresql.Driver");
            else if (dbType.matches(DBType.MSSQL))
                Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        } catch (ClassNotFoundException e) {
            LoggingUtil.error(MigrationService.class, "ERROR: cannot initialize DB driver.", e);
            throw new IllegalStateException("Couldn't migrate. No suitable driver class found.");
        }

        // create a JDBC connection
        Connection connection;
        try {
            connection = DriverManager.getConnection(dataSourceUrl, dataSourceUsername, dataSourcePassword);
            connection.setAutoCommit(false);
        } catch (Exception e) {
            LoggingUtil.error(MigrationService.class, "ERROR: cannot initialize DB connection.", e);
            throw new IllegalStateException("Couldn't migrate. No connection to DB was initialized.");
        }

        try {
            // create migration log table if not present
            if (!tableExists(connection, dataSourceDefaultSchema, "db_migration_log")) {
                LoggingUtil.debug(MigrationService.class, "    - DB migration log table not found. Creating...");

                DBTable migrationLogTable = new DBTable("db_migration_log").columns(
                        Columns.LONG("id").notNull().autoIncrement().primaryKey(),
                        Columns.STRING("module_name").notNull(),
                        Columns.STRING("app_version").notNull(),
                        Columns.INT("migration_revision").notNull(),
                        Columns.DATETIME("time_executed").notNull()
                );

                MigrationAction createMigrationLogTable = new CreateTable(migrationLogTable);
                LoggingUtil.debug(MigrationService.class, "        [STATEMENT] " + createMigrationLogTable.generateSQL(dbType));
                connection.prepareStatement(createMigrationLogTable.generateSQL(dbType)).execute();

                LoggingUtil.debug(MigrationService.class, "    - Success.");
            }

            // create migration lock table if not present (concurrent access protection)
            if (!tableExists(connection, dataSourceDefaultSchema, "db_migration_lock")) {
                LoggingUtil.debug(MigrationService.class, "    - DB migration lock table not found. Creating...");

                DBTable migrationLockTable = new DBTable("db_migration_lock").columns(
                        Columns.LONG("id").notNull().autoIncrement().primaryKey(),
                        Columns.STRING("owner_system").notNull(),
                        Columns.BIT("currently_locked").notNull().defaultValue(false)
                );

                MigrationAction createMigrationLockTable = new CreateTable(migrationLockTable);
                LoggingUtil.debug(MigrationService.class, "        [STATEMENT] " + createMigrationLockTable.generateSQL(dbType));
                connection.prepareStatement(createMigrationLockTable.generateSQL(dbType)).execute();

                LoggingUtil.debug(MigrationService.class, "    - Success.");
            }

            // find out current MAC address (to identify a device while locking)
            String currentMac = null;
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                byte[] adr = ni.getHardwareAddress();
                if (adr == null || adr.length != 6)
                    continue;
                currentMac = String.format("%02X:%02X:%02X:%02X:%02X:%02X",
                        adr[0], adr[1], adr[2], adr[3], adr[4], adr[5]);
                break;
            }

            if (currentMac == null)
                throw new IllegalStateException("Cannot read MAC of the server."); // something went wrong

            // db migration lock info
            boolean lockEntryExists = true;
            Long lockEntryId = null;
            while (true) {
                LoggingUtil.info(MigrationService.class, "    - Acquiring DB migration log...");

                // find current lock record (expected only one at a time)
                ResultSet lockInfo = connection.prepareStatement("SELECT * FROM db_migration_lock").executeQuery();
                if (!lockInfo.next()) {
                    lockEntryExists = false; // there is no record - need to create it
                    break;
                } else if (lockInfo.getBoolean(3) && !currentMac.equals(lockInfo.getString(2))) {
                    // if locked by another device (another MAC) - wait 30 seconds
                    LoggingUtil.debug(MigrationService.class, "    - Migration already locked by server with other MAC. Waiting 30 seconds to re-check.");
                    Thread.sleep(30000); // подождем пока чужой LOCK рассосётся
                } else {
                    lockEntryId = lockInfo.getLong(1); // set ID of a record that will need to be cleared later
                    break;
                }
            }

            if (lockEntryExists) {
                // if lock record exists - update it for us
                connection.prepareStatement("UPDATE db_migration_lock SET owner_system='" + currentMac
                        + "', currently_locked=" + DBActionUtil.convertBoolean(dbType, true) + " WHERE id=" + lockEntryId).execute();
            } else {
                // otherwise create new one
                connection.prepareStatement("INSERT INTO db_migration_lock (owner_system, currently_locked) VALUES ('"
                        + currentMac + "', " + DBActionUtil.convertBoolean(dbType, true) + ")").execute();

                // store ID of a record (in case we have previously deleted others and the ID isn't 1)
                String lastLockIdSQL;
                if (dbType.matches(DBType.MYSQL_5) || dbType.matches(DBType.MYSQL_8))
                    lastLockIdSQL = "SELECT id FROM db_migration_lock ORDER BY id DESC LIMIT 1";
                else if (dbType.matches(DBType.MSSQL))
                    lastLockIdSQL = "SELECT TOP 1 id FROM db_migration_lock ORDER BY id DESC";
                else if (dbType.matches(DBType.PSQL))
                    lastLockIdSQL = "SELECT id FROM db_migration_lock ORDER BY id DESC LIMIT 1";
                else
                    throw new IllegalStateException("No such DB type: " + dbType);
                ResultSet lastIdSet = connection.prepareStatement(lastLockIdSQL).executeQuery();
                lastIdSet.next();
                lockEntryId = lastIdSet.getLong(1);
            }
            LoggingUtil.info(MigrationService.class, "    - DB migration lock acquired.");

            // find all migrations
            List<Class<? extends AbstractMigration>> migrators = new ArrayList<>(reflectionsUtil.getSubclasses(AbstractMigration.class));

            // parse versions and add to migration wrapper
            List<MigratorDefinition> migratorDefinitions = new ArrayList<>();
            for (Class<? extends AbstractMigration> migratorClass : migrators) {
                migratorDefinitions.add(new MigratorDefinition(migratorClass));
            }

            if (!migratorDefinitions.isEmpty()) {
                Set<UniquityCheckWrapper> uniqueCheck = new HashSet<>(); // unique check with special wrapper

                // prepare migration history Select SQL (according to DBMS type)
                String migrationLogSQL;
                if (dbType.matches(DBType.MYSQL_5) || dbType.matches(DBType.MYSQL_8))
                    migrationLogSQL = "SELECT * FROM db_migration_log WHERE module_name = '${MODULE}' AND app_version = '${VERSION}' AND migration_revision = ${revision} LIMIT 1";
                else if (dbType.matches(DBType.MSSQL))
                    migrationLogSQL = "SELECT TOP 1 * FROM db_migration_log WHERE module_name = '${MODULE}' AND app_version = '${VERSION}' AND migration_revision = ${revision}";
                else if (dbType.matches(DBType.PSQL))
                    migrationLogSQL = "SELECT * FROM db_migration_log WHERE module_name = '${MODULE}' AND app_version = '${VERSION}' AND migration_revision = ${revision} LIMIT 1";
                else
                    throw new IllegalStateException("No such DB type: " + dbType);

                // remove migrations that are already executed
                for (int i = migratorDefinitions.size() - 1; i >= 0; i--) {
                    MigratorDefinition definition = migratorDefinitions.get(i);

                    // check that no migrations are executed twice or have same module, version or revision
                    if (!uniqueCheck.add(new UniquityCheckWrapper(definition.getModule(), definition.getVersion())))
                        throw new IllegalStateException("Changelog for module \"" + definition.getModule() + "\" with version \"" + definition.getVersion().getVersion() + "\" is duplicated.");

                    // find records about migration in db_migration_log
                    ResultSet thisMigration = connection.prepareStatement(
                            migrationLogSQL
                                    .replace("${MODULE}", definition.getModule())
                                    .replace("${VERSION}", definition.getVersion().getVersion())
                                    .replace("${revision}", definition.getVersion().getRevision().toString())
                    ).executeQuery();

                    if (thisMigration.next()) {
                        migratorDefinitions.remove(i); // убираем миграцию, если уже есть запись о ее выполнении
                    }
                }

                // sort migrations by version
                sortMigrations(migratorDefinitions);
                ensureOrder(migratorDefinitions);

                // choose current time expression for this DBMS type
                String now;
                if (dbType.matches(DBType.MYSQL_5) || dbType.matches(DBType.MYSQL_8))
                    now = "NOW()";
                else if (dbType.matches(DBType.MSSQL))
                    now = "CURRENT_TIMESTAMP";
                else if (dbType.matches(DBType.PSQL))
                    now = "NOW()";
                else
                    throw new IllegalStateException("No such DB type: " + dbType);

                // run migrations
                for (MigratorDefinition migratorDefinition : migratorDefinitions) {
                    LoggingUtil.info(MigrationService.class, "    - Processing migration. Version: \"" + migratorDefinition.getVersion().getVersion() +
                            "\", module: \"" + migratorDefinition.getModule() + "\", revision: \"" + migratorDefinition.getVersion().getRevision() + "\".");

                    // initialize migrator
                    AbstractMigration migration = migratorDefinition.migratorClass.getConstructor().newInstance();
                    migration.setDbType(dbType);
                    migration.prepare(); // create event queue
                    List<MigrationAction> queue = migration.getQueue();

                    // execute migrator event queue
                    for (MigrationAction migrationAction : queue) {
                        // skip action if it's marked to not run on this DBMS
                        if (migrationAction.getDbTypes() != null
                                && Arrays.stream(migrationAction.getDbTypes()).noneMatch(t -> dbType.matches(t))) {
                            LoggingUtil.debug(MigrationService.class, "        (skipped action \"" + migrationAction.generateSQL(dbType) + "\" because it has DB types condition which is not fulfilled.)");
                            continue;
                        }

                        if (migrationAction instanceof SimpleAction) {
                            ((SimpleAction) migrationAction).execute(connection);
                        } else {
                            LoggingUtil.debug(MigrationService.class, "        [STATEMENT] " + migrationAction.generateSQL(dbType));
                            connection.prepareStatement(migrationAction.generateSQL(dbType)).execute(); // execute event
                        }
                    }

                    // create log entry about migration
                    connection.prepareStatement("INSERT INTO db_migration_log (module_name, app_version, migration_revision, time_executed) VALUES ('"
                            + migratorDefinition.getModule() + "', '" + migratorDefinition.getVersion().getVersion() + "', '" + +migratorDefinition.getVersion().getRevision() + "', " + now + ")").execute();

                    LoggingUtil.info(MigrationService.class, "    - Successfully executed.");
                }

            }

            // lift the migration lock using the ID that was previously chosen
            connection.prepareStatement("UPDATE db_migration_lock SET owner_system='', " +
                    "currently_locked=" + DBActionUtil.convertBoolean(dbType, false) + " WHERE id=" + lockEntryId).execute();

            LoggingUtil.info(MigrationService.class, "    - DB migration lock released.");
            LoggingUtil.info(MigrationService.class, "Success.");
        } catch (Exception e) {
            exception = e;
        } finally {
            // close DB connection
            try {
                if (exception == null) {
                    connection.commit(); // if all is fine - commit
                } else {
                    connection.rollback(); // rollback if some exception was caught
                }
                connection.close(); // in any case - close connection
            } catch (SQLException sqle) {
                LoggingUtil.error(MigrationService.class, "ERROR: couldn't close connection.");
                throw new IllegalStateException("Couldn't close DB connection.");
            }
        }

        if (exception != null)
            throw new IllegalStateException("ERROR: Couldn't migrate. Transaction rolled back.", exception);
    }

    public void sortMigrations(List<MigratorDefinition> migratorDefinitions) {
        migratorDefinitions.sort(new Comparator<>() {
            @Override
            public int compare(MigrationService.MigratorDefinition o1, MigrationService.MigratorDefinition o2) {
                int versionsResult = compareVersions(o1.getVersion(), o2.getVersion());
                if (versionsResult != 0)
                    return versionsResult;

                // if versions are same - compare revisions
                int revisionResult = Integer.compare(o1.getVersion().getRevision(), o2.getVersion().getRevision());

                // if revision number and the module is same - 'tis but a duplicate migration
                if (revisionResult == 0) {
                    if (o1.getModule().equals(o2.getModule()))
                        throw new IllegalStateException("More than one comparator with same module, version and revision are present. Module: \""
                                + o1.getModule() + "\", revision: " + o1.getVersion().getRevision());

                    // ensure order (may request executing migration after another one is done)
                    if (o1.getMigratorClass().isAnnotationPresent(ExecuteAfter.class)
                            && Arrays
                            .stream(o1.getMigratorClass().getAnnotation(ExecuteAfter.class).value())
                            .anyMatch(cl -> cl == o2.getMigratorClass())) {
                        return 1;
                    } else if (o2.getMigratorClass().isAnnotationPresent(ExecuteAfter.class)
                            && Arrays
                            .stream(o2.getMigratorClass().getAnnotation(ExecuteAfter.class).value())
                            .anyMatch(cl -> cl == o1.getMigratorClass())) {
                        return -1;
                    }
                }

                return revisionResult;
            }
        });
    }

    public void ensureOrder(List<MigratorDefinition> migratorDefinitions) {
        boolean changed = true;
        while (changed) {
            changed = false;
            List<Class<? extends AbstractMigration>> all = new ArrayList<>();
            for (MigratorDefinition migratorDefinition : migratorDefinitions) {
                all.add(migratorDefinition.getMigratorClass());
            }

            for (int i = 0; i < all.size(); i++) {
                Class<? extends AbstractMigration> current = all.get(i);

                if (!current.isAnnotationPresent(ExecuteAfter.class)) continue;

                for (Class<? extends AbstractMigration> beforeClass : current.getAnnotation(ExecuteAfter.class).value()) {
                    int position = all.indexOf(beforeClass);
                    if (position >= 0 && position >= i) {
                        Collections.rotate(migratorDefinitions.subList(i, position + 1), -1);
                        changed = true;
                        break;
                    }
                }
            }
        }


//        List<Class<? extends AbstractMigration>> all = new ArrayList<>();
//        for (MigratorDefinition migratorDefinition : migratorDefinitions) {
//            all.add(migratorDefinition.getMigratorClass());
//        }
//
//        List<Class<? extends AbstractMigration>> before = new ArrayList<>();
//        for (int i = 0; i < all.size(); i++) {
//            Class<? extends AbstractMigration> current = all.get(i);
//            before.add(current);
//
//            if (!current.isAnnotationPresent(ExecuteAfter.class)) continue;
//
//            Integer newPosition = null;
//
//            for (Class<? extends AbstractMigration> beforeClass : current.getAnnotation(ExecuteAfter.class).value()) {
//                if (!before.contains(beforeClass)) {
//                    int position = all.indexOf(beforeClass);
//                    if (newPosition == null || newPosition < (position + 1))
//                        newPosition = position + 1;
//                }
//            }
//
//            if (newPosition != null) {
//                Collections.rotate(migratorDefinitions.subList(i, newPosition), -1);
//
//                ensureOrder(migratorDefinitions);
//            }
//        }
    }

    /**
     * Check if table exists in connected database
     *
     * @param connection open JDBC connection
     * @param schema     schema to check against (if specified)
     * @param tableName  table to seek
     * @return is table present in schema
     * @throws SQLException something went wrong with connection
     * @apiNote there is a problem with MySQL: if multiple databases with same table names are mapped to a single user,
     * the result will be incorrect. Please create separate user for each stand.
     */
    private boolean tableExists(Connection connection, String schema, String tableName) throws SQLException {
        DatabaseMetaData meta = connection.getMetaData();
        ResultSet resultSet = meta.getTables(null, schema, tableName, new String[]{"TABLE"});

        return resultSet.next();
    }

    /**
     * Read migration version
     *
     * @param migratorClass class of a migration
     * @return version object
     */
    private PlatformVersion parseVersion(Class<? extends AbstractMigration> migratorClass) {
        return new PlatformVersion(migratorClass.getSimpleName(), true);
    }

    /**
     * Compare 2 PlatformVersions
     *
     * @param o1 first to compare
     * @param o2 second to compare
     * @return 1 if first is bigger, -1 if second and 0 if same
     */
    public int compareVersions(PlatformVersion o1, PlatformVersion o2) {
        if (o1.getMajor() < o2.getMajor()) // мажорная версия
            return -1;
        else if (o1.getMajor() > o2.getMajor())
            return 1;

        if (o1.getMinor() < o2.getMinor()) // минорная версия
            return -1;
        else if (o1.getMinor() > o2.getMinor())
            return 1;

        if (o1.getFix() < o2.getFix()) // фикс
            return -1;
        else if (o1.getFix() > o2.getFix())
            return 1;

        return 0; // будут стоять на одном уровне
    }

    /**
     * Migration wrapper
     */
    public class MigratorDefinition {
        private String module;
        private PlatformVersion version;
        private Class<? extends AbstractMigration> migratorClass;

        public MigratorDefinition(Class<? extends AbstractMigration> migratorClass) {
            module = migratorClass.getSimpleName().split("_")[0].toLowerCase(Locale.ROOT);
            version = parseVersion(migratorClass);
            this.migratorClass = migratorClass;

            if (compareVersions(version, AppDefines.get(AppDefines.VERSION)) == 1)
                throw new IllegalStateException("Found migration with version \"" + version.toString() + "\" which is greater than application version \"" + AppDefines.get(AppDefines.VERSION).toString() + "\". This is not allowed.");
        }

        public PlatformVersion getVersion() {
            return version;
        }

        public Integer getMajor() {
            return version.getMajor();
        }

        public Integer getMinor() {
            return version.getMinor();
        }

        public Integer getFix() {
            return version.getFix();
        }

        public String getModule() {
            return module;
        }

        public Class<? extends AbstractMigration> getMigratorClass() {
            return migratorClass;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof MigratorDefinition)) return false;
            MigratorDefinition that = (MigratorDefinition) o;
            return Objects.equals(getMigratorClass(), that.getMigratorClass());
        }

        @Override
        public int hashCode() {
            return Objects.hash(getMigratorClass());
        }

        @Override
        public String toString() {
            return module + ": " + version.getVersion() + "_rev" + version.getRevision();
        }
    }

    public MigratorDefinition createDefinition(Class<? extends AbstractMigration> migratorClass) {
        return new MigratorDefinition(migratorClass);
    }

    /**
     * Version unique check wrapper
     */
    public class UniquityCheckWrapper {
        private String module;
        private String version;

        public UniquityCheckWrapper(String module, PlatformVersion version) {
            this.module = module;
            this.version = version.getVersion();
        }

        public String getModule() {
            return module;
        }

        public String getVersion() {
            return version;
        }
    }
}
