package ru.adaptms.vwf.util.ldap;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.util.SpringUtils;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.LdapContext;
import java.util.Arrays;
import java.util.Base64;
import java.util.stream.Collectors;

/**
 * @author polyakov_ps at 18.10.2022 14:01
 */
@Service
public class LdapUtils {
    public static LdapUtils instance() {
        return SpringUtils.getInstance(LdapUtils.class);
    }

    public static int UAC_ACCOUNT_DISABLED = 0b10;
    public static int UAC_PASSWD_NOTREQD = 0b100000;
    public static int UAC_PASSWD_CANT_CHANGE = 0b100;
    public static int UAC_NORMAL_ACCOUNT = 0b1000000000;
    public static int UAC_DONT_EXPIRE_PASSWORD = 0b10000000000000000;
    public static int UAC_PASSWORD_EXPIRED = 0b100000000000000000000000;

    public String createUser(LdapContext context, String firstName, String lastName, String middleName, String description, String caseNumber,
                             String username, String password, String uid,
                             String baseSearch, String domainForPrincipal, String ou, String groupDN, String email,
                             boolean useUnicodePwd) throws NamingException {
        // sAMAccountName - must be unique
        String usernameResult = username;
        int usernameAppend = 0;
        while (isExists(context, "sAMAccountName=" + usernameResult, baseSearch)) {
            usernameAppend++;
            usernameResult = username + usernameAppend;
        }

        // CN - must be unique
        var fullName =  buildName(lastName, firstName, middleName, false);
        if (fullName.length() > 50) fullName = fullName.substring(0, 50);

        String nameResult = buildName(lastName, firstName, middleName, false);
        int nameAppend = 0;
        while (isExists(context, "name=" + nameResult, baseSearch)) {
            nameAppend++;
            nameResult = fullName + nameAppend;
        }

        // Create a container set of attributes
        Attributes container = new BasicAttributes();

        // Create the objectclass to add
        Attribute objClasses = new BasicAttribute("objectClass");
        objClasses.add("top");
        objClasses.add("person");
        objClasses.add("organizationalPerson");
        objClasses.add("user");

        Attribute cn = new BasicAttribute("cn", nameResult);
        Attribute sAMAccountName = new BasicAttribute("sAMAccountName", usernameResult);
        Attribute principalName = new BasicAttribute("userPrincipalName", usernameResult
                + "@" + domainForPrincipal);
        Attribute givenName = new BasicAttribute("givenName", firstName);
        Attribute displayName = new BasicAttribute("displayName", fullName);
        Attribute sn = new BasicAttribute("sn", lastName);
        Attribute descriptionAttr = new BasicAttribute("description", description);

        Attribute otherMailbox = null;
        if (!StringUtils.isBlank(email))
            otherMailbox = new BasicAttribute("otherMailbox", email);

        Attribute employeeNumber = null;
        if (!StringUtils.isBlank(caseNumber))
            employeeNumber = new BasicAttribute("employeeNumber", caseNumber);
        Attribute uidAttr = new BasicAttribute("uid", uid);
        Attribute userAccountControl = new BasicAttribute("userAccountControl", String.valueOf(UAC_ACCOUNT_DISABLED));
        Attribute pwdLastSet = new BasicAttribute("pwdLastSet", "-1");

        if (useUnicodePwd) {
            Attribute unicodePwdAttr = new BasicAttribute("unicodePwd", ActiveDirectory.getPassword(password));
            container.put(unicodePwdAttr);
        } else {
            Attribute userPassword = new BasicAttribute("userPassword", /*"{MD5}" + */ Base64.getEncoder().encodeToString(DigestUtils.sha256(password)));
            container.put(userPassword);
        }

        // Add these to the container
        container.put(objClasses);
        container.put(sAMAccountName);
        container.put(principalName);
        container.put(cn);
        container.put(sn);
        container.put(givenName);
        container.put(displayName);
        container.put(descriptionAttr);

        if (otherMailbox != null)
            container.put(otherMailbox);

        if (employeeNumber != null)
            container.put(employeeNumber);
        container.put(uidAttr);

        container.put(userAccountControl);
        container.put(pwdLastSet);

        String userDn = "CN=" + nameResult + "," + ou;

        context.createSubcontext(userDn, container); // create user
        addOrRemoveToGroup(context, userDn, groupDN, true);
        return usernameResult;
    }

    public void addOrRemoveToGroup(LdapContext context, String userDN, String groupDN, boolean doAdd) throws NamingException {
        ModificationItem[] mods = new ModificationItem[1];
        Attribute mod = new BasicAttribute("member", userDN);
        mods[0] = new ModificationItem((doAdd ? DirContext.ADD_ATTRIBUTE : DirContext.REMOVE_ATTRIBUTE), mod);
        try {
            context.modifyAttributes(groupDN, mods);
        } catch (Exception nnfe) {
            // wasn't added as member
        }
    }

    public void enableOrDisableUser(LdapContext context, String userDN, boolean doEnable) throws NamingException {
        ModificationItem[] mods = new ModificationItem[1];
        Attribute mod = new BasicAttribute("userAccountControl", String.valueOf(doEnable ? UAC_NORMAL_ACCOUNT : UAC_ACCOUNT_DISABLED));
        mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, mod);
        context.modifyAttributes(userDN, mods);
    }

    public void move(LdapContext context, String dnFrom, String dnTo) throws NamingException {
        context.rename(dnFrom, dnTo);
    }

    public boolean isExists(LdapContext context, String query, String ou) throws NamingException {
        return find(context, query, ou, new String[]{"objectSID"}).hasMore();
    }

    public NamingEnumeration<SearchResult> find(LdapContext context, String query, String ou, String[] attrsToReturn) throws NamingException {
        return context.search(ou, query, getSearchControls(attrsToReturn));
    }

    public SearchControls getSearchControls(String[] attrsToReturn) {
        SearchControls cons = new SearchControls();
        cons.setSearchScope(SearchControls.SUBTREE_SCOPE);
        cons.setReturningAttributes(attrsToReturn);
        return cons;
    }

    public String createDN(String name, String ou, String domain) {
        String[] domainParts = domain.split("\\.");
        return "cn=" + name + "," + ou + Arrays.stream(domainParts).map(p -> ",dc=" + p).collect(Collectors.joining());
    }

    public String buildName(String last, String first, String middle, boolean initials) {
        StringBuilder builder = new StringBuilder(last);
        if (initials) {
            if (!StringUtils.isBlank(first))
                builder.append(" ").append(first.charAt(0)).append(".");
            if (!StringUtils.isBlank(middle))
                builder.append(" ").append(middle.charAt(0)).append(".");
        } else {
            if (!StringUtils.isBlank(first))
                builder.append(" ").append(first);
            if (!StringUtils.isBlank(middle))
                builder.append(" ").append(middle);
        }

        return builder.toString();
    }
}
