package ru.adaptms.vwf.util.conversion;

/**
 * @author ppolyakov at 04.01.2022 21:56
 */
public abstract class ConversionType {
    public abstract Class<?> getTargetClass();

    public abstract Object doConvert( String input );
}
