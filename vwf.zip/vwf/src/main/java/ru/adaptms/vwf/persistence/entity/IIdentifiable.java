package ru.adaptms.vwf.persistence.entity;

/**
 * Интерфейс для определения любых элементов, у которых есть ID
 *
 * @author ppolyakov at 17.10.2021 18:40
 */
public interface IIdentifiable {
    Long getId();
}
