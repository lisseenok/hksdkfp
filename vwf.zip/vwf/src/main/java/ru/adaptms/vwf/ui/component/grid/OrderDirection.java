package ru.adaptms.vwf.ui.component.grid;

/**
 * @author ppolyakov at 23.01.2022 03:24
 */
public enum OrderDirection {
    ASC,
    DESC;

    public boolean isAsc() {
        return this == ASC;
    }
}
