package ru.adaptms.vwf.ui.action.success;

/**
 * Reload page (hard, like browser 'refresh' avtion)
 *
 * @author ppolyakov at 03.02.2022 01:46
 */
public class SuccessReloadPage implements ISuccessAction {
    @Override
    public String getAction() {
        return "reloadPage";
    }
}
