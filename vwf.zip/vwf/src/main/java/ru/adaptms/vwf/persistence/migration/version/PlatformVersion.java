package ru.adaptms.vwf.persistence.migration.version;

/**
 * @author ppolyakov at 05.12.2021 15:05
 */
public class PlatformVersion {
    private Integer major;
    private Integer minor;
    private Integer fix;
    private Integer revision;

    public PlatformVersion( String version, boolean migration ) {
        if ( !migration ) {
            String[] versionParts = version.split( "\\." );
            major = Integer.parseInt( versionParts[ 0 ] );
            minor = Integer.parseInt( versionParts[ 1 ] );
            fix = Integer.parseInt( versionParts[ 2 ] );
        } else {
            String[] versionParts = version.split( "_" );
            major = Integer.parseInt( versionParts[ 1 ] );
            minor = Integer.parseInt( versionParts[ 2 ] );
            fix = Integer.parseInt( versionParts[ 3 ] );

            revision = Integer.parseInt( versionParts[ 4 ].replace( "rev", "" ) );
        }
    }

    public String getVersion() {
        return major + "." + minor + "." + fix;
    }

    public Integer getMajor() {
        return major;
    }

    public Integer getMinor() {
        return minor;
    }

    public Integer getFix() {
        return fix;
    }

    public Integer getRevision() {
        return revision;
    }

    public String toString() {
        return getVersion();
    }
}
