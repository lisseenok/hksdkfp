package ru.adaptms.vwf.persistence.migration.types;

/**
 * @author ppolyakov at 05.12.2021 16:02
 */
public class DBType {
    public static final String MYSQL_5 = "mysql5|MySQL5|mysql-5|MySQL-5|mysql 5|MySQL 5";
    public static final String MYSQL_8 = "mysql8|MySQL8|mysql-8|MySQL-8|mysql 8|MySQL 8";
    public static final String MSSQL = "mssql|sqlserver|mssqlserver|MSSQL|SQL Server|MS SQL Server";
    public static final String PSQL = "psql|postgres|postgresql|PSQL|PostgreSQL";
}
