package ru.adaptms.vwf.config.websocket;

import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;
import org.springframework.web.socket.config.annotation.StompEndpointRegistry;
import org.springframework.web.socket.config.annotation.WebSocketMessageBrokerConfigurer;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.util.HashSet;
import java.util.Set;

/**
 * @author polyakov_ps at 25.05.2023 19:04
 */
//@Configuration
//@EnableWebSocketMessageBroker
@RequiredArgsConstructor
public class WebsocketConfig implements WebSocketMessageBrokerConfigurer {
    private final ReflectionsUtil reflectionsUtil;

    @Override
    public void configureMessageBroker(MessageBrokerRegistry config) {
        config.setApplicationDestinationPrefixes("/svc");

        Set<String> registered = new HashSet<>();

        // register brokers
        Set<Class<?>> wsClasses = reflectionsUtil.getWithAnnotation(WebsocketBroker.class);
        if (CollectionUtils.isNotEmpty(wsClasses)) {
            for (Class<?> wsClass : wsClasses) {
                String[] brokerNames = wsClass.getAnnotation(WebsocketBroker.class).value();
                for (String brokerName : brokerNames) {
                    if (!brokerName.startsWith("/")) brokerName = "/" + brokerName;

                    if (!registered.add(brokerName))
                        throw new IllegalStateException("Broker \"" + brokerName + "\" is already defined. Duplicate found in: " + wsClass.getSimpleName());

                    config.enableSimpleBroker(brokerName);
                }
            }
        }
    }

    @Override
    public void registerStompEndpoints(StompEndpointRegistry registry) {
        registry.addEndpoint("/ws").withSockJS();
    }
}
