package ru.adaptms.vwf.persistence.hibernate.dialect;

import org.hibernate.dialect.MySQLDialect;

/**
 * @author ppolyakov at 03.10.2021 23:47
 */
//MySQLDialect
public class MySQL8Dialect extends org.hibernate.dialect.MySQL8Dialect {
    public MySQL8Dialect() {
        super();
        //super( 800 );

        // MySQL doesn't add the new reserved keywords to their JDBC driver to preserve backward compatibility.

        registerKeyword("CUME_DIST");
        registerKeyword("DENSE_RANK");
        registerKeyword("EMPTY");
        registerKeyword("EXCEPT");
        registerKeyword("FIRST_VALUE");
        registerKeyword("GROUPS");
        registerKeyword("JSON_TABLE");
        registerKeyword("LAG");
        registerKeyword("LAST_VALUE");
        registerKeyword("LEAD");
        registerKeyword("NTH_VALUE");
        registerKeyword("NTILE");
        registerKeyword("PERSIST");
        registerKeyword("PERCENT_RANK");
        registerKeyword("PERSIST_ONLY");
        registerKeyword("RANK");
        registerKeyword("ROW_NUMBER");
    }
}
