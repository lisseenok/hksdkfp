package ru.adaptms.vwf.ui.thymeleaf.processor.notification;

import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.util.SpringELUtil;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class NotificationProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "notification";
    private static final int PRECEDENCE = 1000;

    public NotificationProcessor( String dialectPrefix ) {
        super( dialectPrefix, ELEMENT_NAME, PRECEDENCE );
    }

    @Override
    protected void doProcess( ITemplateContext incomingContext,
                              IProcessableElementTag elementTag,
                              IElementTagStructureHandler structureHandler ) {
        //if ( !requireAttributes( elementTag, structureHandler, "type" ) ) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser( incomingContext );

        outgoingContext.setVariable( "classes", SpringELUtil.execute( elementTag.getAttributeValue( "class" ), incomingContext, parser ) );
        outgoingContext.setVariable( "style", SpringELUtil.execute( elementTag.getAttributeValue( "style" ), incomingContext, parser ) );
        outgoingContext.setVariable( "type", SpringELUtil.execute( elementTag.getAttributeValue( "type" ), incomingContext, parser ) );
        applyBooleanField( outgoingContext, elementTag, "light", SpringELUtil.execute( elementTag.getAttributeValue( "light" ), incomingContext, parser ) );
        applyBooleanField( outgoingContext, elementTag, "icon", SpringELUtil.execute( elementTag.getAttributeValue( "icon" ), incomingContext, parser ) );
        applyBooleanField( outgoingContext, elementTag, "shadow", SpringELUtil.execute( elementTag.getAttributeValue( "shadow" ), incomingContext, parser ) );
        outgoingContext.setVariable( "text", SpringELUtil.execute( elementTag.getAttributeValue( "text" ), incomingContext, parser ) );

        structureHandler.replaceWith( getTemplate( outgoingContext ), false );
    }
}
