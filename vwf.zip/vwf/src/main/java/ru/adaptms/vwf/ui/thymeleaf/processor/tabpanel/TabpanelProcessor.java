package ru.adaptms.vwf.ui.thymeleaf.processor.tabpanel;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.component.tabpanel.TabPanel;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.util.RandomUtils;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class TabpanelProcessor extends AbstractUITagProcessor {
    public static final String LISTENER_PARAM_TAB = TabPanel.LISTENER_PARAM;

    private static final String ELEMENT_NAME = "tabpanel";
    private static final int PRECEDENCE = 1000;

    public TabpanelProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "source")) return; //listener

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        String id = (String) SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser);
        if (StringUtils.isBlank(id))
            id = RandomUtils.instance().randomString(8);

        AbstractUIHandler handler = (AbstractUIHandler) incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE);
        if (handler != null) {
            id += "_" + handler.getHandlerId();
        }

        outgoingContext.setVariable("id", id);

        TabPanel panel = (TabPanel) SpringELUtil.execute(elementTag.getAttributeValue("source"), incomingContext, parser);

        outgoingContext.setVariable("tabpanel", panel);
        outgoingContext.setVariable("listener", panel.getListener()); //SpringELUtil.execute( elementTag.getAttributeValue( "listener" ), incomingContext, parser )
        outgoingContext.setVariable("style", SpringELUtil.execute(elementTag.getAttributeValue("style"), incomingContext, parser));
        outgoingContext.setVariable("classes", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));
        if (elementTag.hasAttribute("disabled")
                && StringUtils.isBlank(elementTag.getAttributeValue("disabled"))) {
            outgoingContext.setVariable("disabled", true);
        } else {
            applyBooleanField(outgoingContext, elementTag, "disabled", SpringELUtil.execute(elementTag.getAttributeValue("disabled"), incomingContext, parser));
        }
        if (elementTag.hasAttribute("active")
                && StringUtils.isBlank(elementTag.getAttributeValue("active"))) {
            outgoingContext.setVariable("active", true);
        } else {
            applyBooleanField(outgoingContext, elementTag, "active", SpringELUtil.execute(elementTag.getAttributeValue("active"), incomingContext, parser));
        }

        applyBooleanField(outgoingContext, elementTag, "standalone", SpringELUtil.execute(elementTag.getAttributeValue("standalone"), incomingContext, parser));

        outgoingContext.setVariable(AbstractUIHandler.HANDLER_VARIABLE, incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE));

        structureHandler.replaceWith(getTemplate(outgoingContext), false);
    }

}
