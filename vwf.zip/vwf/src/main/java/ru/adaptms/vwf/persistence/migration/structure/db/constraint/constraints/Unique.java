package ru.adaptms.vwf.persistence.migration.structure.db.constraint.constraints;

import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Уникальное ограничение
 *
 * @author ppolyakov at 05.12.2021 19:36
 */
public class Unique extends DBConstraint {

    private List<String> uniqueColumns = new ArrayList<>();

    /**
     * @param constraintName имя ограничения
     * @param uniqueColumns колонки, к которым оно будет применено (можно несколько, тогда они будут уникальны вместе)
     */
    public Unique( String constraintName, String... uniqueColumns ) {
        super( constraintName );

        if ( uniqueColumns == null )
            throw new IllegalStateException( "No columns provided for Unique constraint \"" + constraintName + "\"" );

        this.uniqueColumns.addAll( Arrays.asList( uniqueColumns ) );
    }

    @Override
    public void apply( String dbType, StringBuilder builder ) {
        builder.append( constraintName )
                .append( " UNIQUE (" )
                .append( String.join( ", ", uniqueColumns ) )
                .append( ")" );
    }

    public List<String> getUniqueColumns() {
        return uniqueColumns;
    }
}
