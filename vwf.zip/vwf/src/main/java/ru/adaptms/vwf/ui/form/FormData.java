package ru.adaptms.vwf.ui.form;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import ru.adaptms.quickui.util.input.FormDataValidator;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Representation of form data that is received from the frontend
 *
 * @author ppolyakov at 08.01.2022 17:56
 */
public class FormData implements Serializable {

    @Getter @Setter
    private String csrf; // todo actually use

    @Getter @Setter
    private Map<String, List<String>> fields;

    @Getter @Setter
    private Map<String, List<AsyncFile>> files;

    @Getter( AccessLevel.PROTECTED ) @Setter
    private FormDataValidator formDataValidator;

    public FormData() {
        setFormDataValidator( new FormDataValidator( this ) );
    }

    /**
     * Get a text value of a single input
     * @param fieldName name of the field
     * @return provided value of the field or NULL if not passed
     */
    public String getFieldValueSingle( String fieldName ) {
        List<String> value = fields.get( fieldName );
        if ( value == null || value.isEmpty() )
            return null;
        if ( value.size() > 1 )
            throw new IllegalArgumentException( "Expected 1 value for field \"" + fieldName + "\", got " + value.size() );
        return value.get( 0 );
    }

    /**
     * Get a text value for multi-value inputs
     * @param fieldName name of the field
     * @return list of all provided values
     */
    public List<String> getFieldValueMultiple( String fieldName ) {
        List<String> value = fields.get( fieldName );
        if ( value == null || value.isEmpty() )
            return null;
        return value;
    }

    /**
     * Get an uploaded file
     * @param fieldName name of file upload field
     * @return {@link AsyncFile} object or null if no file was uploaded
     */
    public AsyncFile getFileSingle( String fieldName ) {
        List<AsyncFile> value = files.get( fieldName );
        if ( value == null || value.isEmpty() )
            return null;
        if ( value.size() > 1 )
            throw new IllegalArgumentException( "Expected 1 file for field \"" + fieldName + "\", got " + value.size() );
        return value.get( 0 );
    }

    /**
     * Get multi-upload file input values
     * @param fieldName name of file upload field
     * @return {@link AsyncFile} objects or null if no file was uploaded
     */
    public List<AsyncFile> getFileMultiple( String fieldName ) {
        List<AsyncFile> value = files.get( fieldName );
        if ( value == null || value.isEmpty() )
            return null;
        return value;
    }

    public FormDataValidator validator() {
        return getFormDataValidator();
    }

    public boolean hasAnyFields() {
        return fields != null && !fields.isEmpty();
    }

    public boolean hasAnyFiles() {
        return files != null && !files.isEmpty();
    }
}
