package ru.adaptms.vwf.ui.util.uri;

import lombok.Getter;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;

/**
 * @author ppolyakov at 13.04.2022 16:38
 */
public class RedirectBuilder extends UriBuilder {

    @Getter private final Class<? extends AbstractUIHandler> handlerClass;

    public RedirectBuilder( Class<? extends AbstractUIHandler> handlerClass ) {
        super( MappingRegistry.instance().getMetaByClass( handlerClass ).getMapping(), true );
        this.handlerClass = handlerClass;
    }

    public static RedirectBuilder create( Class<? extends AbstractUIHandler> handlerClass ) {
        return new RedirectBuilder( handlerClass );
    }
}
