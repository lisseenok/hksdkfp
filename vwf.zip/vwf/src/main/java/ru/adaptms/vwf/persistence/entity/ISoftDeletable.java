package ru.adaptms.vwf.persistence.entity;

import java.util.Date;

/**
 * @author ppolyakov at 22.03.2022 13:08
 */
public interface ISoftDeletable extends IEntity {

    Date getDeleted();
    void setDeleted( Date deleted );
}
