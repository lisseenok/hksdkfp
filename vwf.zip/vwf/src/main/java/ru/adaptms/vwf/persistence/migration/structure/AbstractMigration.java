package ru.adaptms.vwf.persistence.migration.structure;

import lombok.Getter;
import lombok.Setter;
import ru.adaptms.vwf.persistence.migration.structure.action.SimpleAction;
import ru.adaptms.vwf.persistence.migration.structure.action.column.AddColumn;
import ru.adaptms.vwf.persistence.migration.structure.action.column.DropColumn;
import ru.adaptms.vwf.persistence.migration.structure.action.column.ModifyColumn;
import ru.adaptms.vwf.persistence.migration.structure.action.constraint.AddConstraint;
import ru.adaptms.vwf.persistence.migration.structure.action.constraint.DropForeignKey;
import ru.adaptms.vwf.persistence.migration.structure.action.constraint.DropIndex;
import ru.adaptms.vwf.persistence.migration.structure.action.constraint.DropUniqueConstraint;
import ru.adaptms.vwf.persistence.migration.structure.action.table.CreateTable;
import ru.adaptms.vwf.persistence.migration.structure.action.table.DropTable;
import ru.adaptms.vwf.persistence.migration.structure.action.view.CreateView;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTable;
import ru.adaptms.vwf.persistence.migration.structure.db.DBTableColumn;
import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;
import ru.adaptms.vwf.persistence.migration.template.ITableTemplate;
import ru.adaptms.vwf.persistence.migration.types.DBType;

import jakarta.persistence.Table;
import java.util.LinkedList;
import java.util.List;

/**
 * @author ppolyakov at 05.12.2021 15:28
 */
public abstract class AbstractMigration {

    protected List<MigrationAction> queue = new LinkedList<>();
    @Getter
    @Setter
    protected String dbType;

    public abstract void prepare();

    public DBTable createTable(String name) {
        return createTable(name, null);
    }

    public DBTable createTable(String name, ITableTemplate template) {
        DBTable table = new DBTable(name, template);
        queue.add(new CreateTable(table));
        return table;
    }

    public DBTable createTable(Class<?> entityClass) {
        return createTable(entityClass, null);
    }

    public DBTable createTable(Class<?> entityClass, ITableTemplate template) {
        DBTable table = new DBTable(entityClass, template);
        queue.add(new CreateTable(table));
        return table;
    }

    public void createOrReplaceView(Class<?> viewClass, String nativeSql) {
        if (!viewClass.isAnnotationPresent(Table.class))
            throw new IllegalArgumentException("View class must have @Table annotation.");
        createOrReplaceView(viewClass.getAnnotation(Table.class).name(), nativeSql);
    }

    public void createOrReplaceView(String viewName, String nativeSql) {
        queue.add(new CreateView(viewName, nativeSql));
    }

    public void performAction(SimpleAction.ActionDefinition action) {
        queue.add(new SimpleAction(action));
    }

    protected void createTable(DBTable table) {
        queue.add(new CreateTable(table));
    }

    protected void dropTable(String tableName) {
        queue.add(new DropTable(tableName));
    }

    protected void dropTable(Class<?> entityClass) {
        dropTable(resolveTableName(entityClass));
    }

    protected void addColumn(String tableName, DBTableColumn column) {
        queue.add(new AddColumn(tableName, column));
    }

    protected void addColumn(Class<?> entityClass, DBTableColumn column) {
        addColumn(resolveTableName(entityClass), column);
    }

    protected void modifyColumn(String tableName, DBTableColumn column) {
        queue.add(new ModifyColumn(tableName, column));
    }

    protected void modifyColumn(Class<?> entityClass, DBTableColumn column) {
        modifyColumn(resolveTableName(entityClass), column);
    }

    protected void dropColumn(String tableName, String column) {
        queue.add(new DropColumn(tableName, column));
    }

    protected void dropColumn(Class<?> entityClass, String column) {
        dropColumn(resolveTableName(entityClass), column);
    }

    protected void addConstraint(String tableName, DBConstraint constraint) {
        queue.add(new AddConstraint(tableName, constraint));
    }

    protected void addConstraint(Class<?> entityClass, DBConstraint constraint) {
        addConstraint(resolveTableName(entityClass), constraint);
    }

    protected void dropForeignKey(String tableName, String fkToDrop) {
        queue.add(new DropForeignKey(tableName, fkToDrop));
        DropIndex mySQL = new DropIndex(tableName, fkToDrop);
        mySQL.setDbTypes(DBType.MYSQL_5, DBType.MYSQL_8);
        queue.add(mySQL);
    }

    protected void dropForeignKey(Class<?> entityClass, String fkToDrop) {
        dropForeignKey(resolveTableName(entityClass), fkToDrop);
    }

    protected void dropUniqueConstraint(String tableName, String ucToDrop) {
        queue.add(new DropUniqueConstraint(tableName, ucToDrop));
    }

    protected void dropUniqueConstraint(Class<?> entityClass, String ucToDrop) {
        dropUniqueConstraint(resolveTableName(entityClass), ucToDrop);
    }

    protected void dropIndex(String tableName, String indexToDrop) {
        queue.add(new DropIndex(tableName, indexToDrop));
    }

    protected void dropIndex(Class<?> entityClass, String indexToDrop) {
        dropIndex(resolveTableName(entityClass), indexToDrop);
    }

    public List<MigrationAction> getQueue() {
        return queue;
    }

    protected String resolveTableName(Class<?> entityClass) {
        if (!entityClass.isAnnotationPresent(Table.class))
            throw new IllegalStateException("No @jakarta.persistence.Table annotation found on class " + entityClass.getSimpleName());

        return entityClass.getAnnotation(Table.class).name();
    }
}
