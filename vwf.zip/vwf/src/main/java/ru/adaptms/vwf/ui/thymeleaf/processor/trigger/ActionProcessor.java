package ru.adaptms.vwf.ui.thymeleaf.processor.trigger;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.util.HandlerUtil;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class ActionProcessor extends AbstractElementModelProcessor {

    private static final String ELEMENT_NAME = "action";
    private static final int PRECEDENCE = 800;

    public ActionProcessor(final String dialectPrefix) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                true,
                null,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess(ITemplateContext context,
                             IModel model,
                             IElementModelStructureHandler structureHandler) {
        final IModelFactory modelFactory = context.getModelFactory();
        IEngineConfiguration configuration = context.getConfiguration();
        IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);

        Map<String, String> attributes = new HashMap<>();
        final ITemplateEvent formEvent = model.get(0);
        if (formEvent instanceof IOpenElementTag) {
            IOpenElementTag formElement = (IOpenElementTag) formEvent;
            Map<String, String> incomingAttrs = formElement.getAttributeMap();

            AbstractUIHandler handler = (AbstractUIHandler) context.getVariable(AbstractUIHandler.HANDLER_VARIABLE);

            AbstractUIHandler topLevelHandler = handler;
            while (topLevelHandler.getParent() != null) {
                topLevelHandler = topLevelHandler.getParent();
            }

            boolean disabled = false;
            if (incomingAttrs.containsKey("disabled")) {
                if (StringUtils.isBlank(incomingAttrs.get("disabled"))) {
                    disabled = true;
                } else {
                    Object dsbld = SpringELUtil.execute(incomingAttrs.get("disabled"), context, parser);
                    if (dsbld instanceof Boolean) {
                        disabled = (Boolean) dsbld;
                    } else if (dsbld instanceof String) {
                        disabled = !"false".equals(dsbld);
                    }
                }
            }

            String classes = (String) SpringELUtil.execute(incomingAttrs.get("class"), context, parser);

            if (!disabled) {
                UriBuilder action = UriBuilder.create(topLevelHandler.getMeta().getMapping(), true);
                action.parameter(AbstractUIHandler.PARAM_ACTION, handler.getHandlerId() + "." + SpringELUtil.execute(incomingAttrs.get("listener"), context, parser));

                Map<String, String> importantParameters = HandlerUtil.getIdentifyingParams(topLevelHandler.getParameters());
                for (Map.Entry<String, String> entry : importantParameters.entrySet()) {
                    action.parameter(entry.getKey(), entry.getValue());
                }

                ProcessorHelper.applyParams(action, incomingAttrs, context, parser, null);

                attributes.put("action", action.build());

                // auto-refresh
                if (incomingAttrs.containsKey("refresh"))
                    attributes.put("data-vwf-refresh", (String) SpringELUtil.execute(incomingAttrs.get("refresh"), context, parser));

                if (incomingAttrs.containsKey("confirmMessage"))
                    attributes.put("data-vwf-confirmmessage", (String) SpringELUtil.execute(incomingAttrs.get("confirmMessage"), context, parser));
                if (incomingAttrs.containsKey("confirmDialogType"))
                    attributes.put("data-vwf-confirmdialogtype", (String) SpringELUtil.execute(incomingAttrs.get("confirmDialogType"), context, parser));
                if (incomingAttrs.containsKey("confirmButtonLabel"))
                    attributes.put("data-vwf-confirmbuttonlabel", (String) SpringELUtil.execute(incomingAttrs.get("confirmButtonLabel"), context, parser));
                if (incomingAttrs.containsKey("toggleId"))
                    attributes.put("data-vwf-toggle", (String) SpringELUtil.execute(incomingAttrs.get("toggleId"), context, parser) + "_" + handler.getHandlerId());

                attributes.put("class", (!StringUtils.isBlank(classes) ? classes : "") + " vwf_ac_li");
            } else {
                attributes.put("disabled", "disabled");
                attributes.put("class", (!StringUtils.isBlank(classes) ? classes : "") + " is-disabled");
            }

            String id = (String) SpringELUtil.execute(incomingAttrs.get("id"), context, parser);
            if (!StringUtils.isBlank(id)) attributes.put("id", id);
            attributes.put("href", "javascript:");
            attributes.put("style", (String) SpringELUtil.execute(incomingAttrs.get("style"), context, parser));

            String title = (String) SpringELUtil.execute(incomingAttrs.get("title"), context, parser);
            if (!StringUtils.isBlank(title))
                attributes.put("title", title);

            if (incomingAttrs.containsKey("focus")) {
                String focus = (String) SpringELUtil.execute(incomingAttrs.get("focus"), context, parser);
                if ("none".equals(focus)) {
                    attributes.put("focusable", "false");
                } else if ("unreachable".equals(focus)) {
                    attributes.put("tabindex", "-1");
                }
            }
        }

        IOpenElementTag formOpen = modelFactory
                .createOpenElementTag("a", attributes,
                        AttributeValueQuotes.DOUBLE,
                        false);

        model.replace(0, formOpen);
        model.replace(model.size() - 1, modelFactory.createCloseElementTag("a"));
    }
}
