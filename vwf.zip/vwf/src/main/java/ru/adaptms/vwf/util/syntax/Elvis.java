package ru.adaptms.vwf.util.syntax;

import org.apache.commons.lang3.StringUtils;

/**
 * @author polyakov_ps at 10.05.2023 22:38
 */
public class Elvis {
    public static <T> T decide(T input, T defaultValue) {
        if (defaultValue instanceof String)
            return StringUtils.isNotBlank((String) input) ? input : defaultValue;
        return input == null ? defaultValue : input;
    }
}
