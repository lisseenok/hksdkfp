package ru.adaptms.vwf.ui.thymeleaf.processor.logicOutput;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.ui.component.breadcrumb.Breadcrumb;
import ru.adaptms.vwf.ui.util.SpringELUtil;

import java.util.Locale;

/**
 * Tag name: &lt;ui:logic-output&gt;
 * Attributes:
 * - value (boolean, required) - value to be displayed
 * - mode (default(=empty)|tick|text)
 *
 * @author ppolyakov at 01.01.2022 21:04
 */
public class LogicOutputProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "logic-output";
    private static final int PRECEDENCE = 1000;

    public LogicOutputProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "value")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        // value to be displayed (true or false, null equals to false)
        outgoingContext.setVariable("displayValue", (Boolean) SpringELUtil.execute(elementTag.getAttributeValue("value"), incomingContext, parser));

        // if mode is "tick" or "text" - define whether falsy value will be displayed as grey minus (light) or red cross
        applyBooleanField(outgoingContext, elementTag, "light", SpringELUtil.execute(elementTag.getAttributeValue("light"), incomingContext, parser));
        outgoingContext.setVariable(AbstractUIHandler.HANDLER_VARIABLE, incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE)); // pass handler to render context

        var mode = (String) SpringELUtil.execute(elementTag.getAttributeValue("mode"), incomingContext, parser);
        if (StringUtils.isBlank(mode)) mode = "default";

        structureHandler.replaceWith(getTemplate(outgoingContext, mode.toLowerCase(Locale.ROOT)), false);
    }
}
