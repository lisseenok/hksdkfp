package ru.adaptms.vwf.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * @author ppolyakov at 12.10.2021 00:04
 */
public class AppConfigUtil {
    public static final String DB_CONFIG = "db";
    public static final String APP_CONFIG = "app";

    public static Properties loadConfig( String jvmProperty, String configName ) {
        Properties properties = new Properties();

        if ( System.getProperty( jvmProperty ) == null )
            throw new IllegalStateException( "Property -D" + jvmProperty + " must be provided in VM options." );

        String filePath = System.getProperty( jvmProperty );
        if ( !filePath.endsWith( "/" ) ) filePath += "/";
        filePath += configName + ".properties";

        try ( InputStream fileStream = new FileInputStream( filePath ) ) {
            properties.load( fileStream );
            return properties;
        } catch ( IOException e ) {
            throw new IllegalStateException( e );
        }
    }

    public static boolean getBooleanValue( Properties properties, String property ) {
        return Boolean.valueOf( properties.getProperty( property ) );
    }
}
