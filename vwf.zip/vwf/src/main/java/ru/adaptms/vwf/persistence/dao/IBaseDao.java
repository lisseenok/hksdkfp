package ru.adaptms.vwf.persistence.dao;

import ru.adaptms.vwf.persistence.entity.IEntity;

import java.io.Serializable;
import java.util.List;

/**
 * Basic DAO for all data-access operations
 *
 * @author pavelpolyakov
 */
public interface IBaseDao extends Serializable {

    /**
     * Save entity (create or update)
     * @param entity entity to save
     * @param <T> type
     * @return persisted entity
     */
    <T extends IEntity> T save( T entity );

    /**
     * Find entry in database by entity type and ID
     * @param type entity class (table) in which to seek
     * @param id internal ID in table
     * @param <T> type
     * @param <PK> ID type (mostly Long)
     * @return found entity or null
     */
    <T extends IEntity, PK extends Serializable> T find( Class<T> type, PK id );


    /**
     * Find all entries of type
     * @param type entity class (table) to seek in
     * @param <T> type
     * @return список найденных элементов
     */
    <T extends IEntity> List<T> findAll( Class<T> type );

    /**
     * Delete entity
     * @param entity entity to delete
     * @param <T> type
     */
    <T extends IEntity> void delete( T entity );

    /**
     * Merge with other versions in Hibernate cache
     * @param entity entity to merge
     * @param <T> type
     */
    <T extends IEntity> void merge( T entity );

    /** Clear current session */
    void clear();

    /**
     * Обновить данные сущности
     * @param entity entity
     * @param <T> type
     */
    <T extends IEntity> void refresh( T entity );

    /**
     * Soft init lazy-loaded entity
     * @param entity lazy entity (only Id is loaded), that requires full initialization
     * @param <T> type
     */
    <T extends IEntity> void softInitialize( T entity );
}
