package ru.adaptms.vwf.ui.i18n.xml;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import java.util.List;
import java.util.Objects;

/**
 * @author ppolyakov at 25.08.2021 16:37
 */
public class MessageNode {

    @XmlAttribute( required = true )
    public String code;

    @XmlElement( name = "translation", required = true )
    public List<TranslationNode> translations;

    public MessageNode() {
    }

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof MessageNode ) ) return false;
        MessageNode that = ( MessageNode ) o;
        return Objects.equals( code, that.code );
    }

    @Override
    public int hashCode() {
        return Objects.hash( code );
    }
}
