package ru.adaptms.vwf.persistence.migration.structure.action.view;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;

/**
 * Удалить view-таблицу
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropView extends MigrationAction {

    private String viewName;

    /**
     * @param viewName имя view-таблицу, которую надо удалить
     */
    public DropView( String viewName ) {
        this.viewName = viewName;
    }

    @Override
    public String generateSQL( String dbType ) {
        return "DROP VIEW " + viewName;
    }
}
