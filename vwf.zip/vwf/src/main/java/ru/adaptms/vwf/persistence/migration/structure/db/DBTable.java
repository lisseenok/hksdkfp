package ru.adaptms.vwf.persistence.migration.structure.db;

import ru.adaptms.vwf.persistence.migration.structure.db.constraint.DBConstraint;
import ru.adaptms.vwf.persistence.migration.template.ITableTemplate;

import jakarta.persistence.Table;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Дефиниция для создаваемой табоицы
 *
 * @author ppolyakov at 05.12.2021 15:35
 */
public class DBTable {
    private String name;
    private List<DBTableColumn> columns = new LinkedList<>();

    private List<DBConstraint> constraints;

    /**
     * @param name имя таблицы
     */
    public DBTable( String name ) {
        set( name, null );
    }

    /**
     * @param entityClass класс сущности с аннотацией @Table, по которой создается таблица
     * @param template шаблон таблицы
     */
    public DBTable( Class<?> entityClass, ITableTemplate template ) {
        if ( !entityClass.isAnnotationPresent( Table.class ) )
            throw new IllegalStateException( "Cannot resolve table name from class " + entityClass.getSimpleName() + " for table creation because " +
                    "it doesn't have the @java.persistence.Table annotation. Try adding the annotation or specify table name as a string." );
        set( entityClass.getAnnotation( Table.class ).name(), template );
    }

    /**
     * @param name имя таблицы
     * @param template шаблон таблицы
     */
    public DBTable( String name, ITableTemplate template ) {
        set( name, template );
    }

    private void set( String name, ITableTemplate template ) {
        this.name = name;
        if ( template != null )
            columns.addAll( template.getColumns() ); // добавим все колонки из шаблона
    }

    /**
     * @param columns задать колонки для таблицы
     */
    public DBTable columns( DBTableColumn... columns ) {
        this.columns.addAll( Arrays.asList( columns ) );
        return this;
    }

    /**
     * @param constraints задать ограничения на уровне таблицы
     */
    public DBTable constraints( DBConstraint... constraints ) {
        if ( this.constraints == null )
            this.constraints = new ArrayList<>();
        this.constraints.addAll( Arrays.asList( constraints ) );
        return this;
    }

    public String getName() {
        return name;
    }

    public List<DBTableColumn> getColumns() {
        return columns;
    }

    public List<DBConstraint> getConstraints() {
        return constraints;
    }
}
