package ru.adaptms.vwf.persistence.migration.structure.action.constraint;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Удалить индекс
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropIndex extends MigrationAction {

    private String tableName;
    private String index;

    /**
     * @param tableName таблица, из которой удаляем
     * @param indexToDrop имя индекса
     */
    public DropIndex( String tableName, String indexToDrop ) {
        this.tableName = tableName;
        this.index = indexToDrop;
    }

    @Override
    public String generateSQL( String dbType ) {
        if ( dbType.matches( DBType.MYSQL_5 ) || dbType.matches( DBType.MYSQL_8 ) || dbType.matches( DBType.PSQL ) )
            return "ALTER TABLE " + tableName + " DROP INDEX " + index;
        else if ( dbType.matches( DBType.MSSQL ) )
            return "DROP INDEX " + index; // T-SQL отличился - ALTER TABLE не надо
        else
            throw new IllegalStateException( "No such DB type: " + dbType );
    }
}
