package ru.adaptms.vwf.ui.thymeleaf.processor.trigger;

import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.IEngineConfiguration;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.*;
import org.thymeleaf.processor.element.AbstractElementModelProcessor;
import org.thymeleaf.processor.element.IElementModelStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import org.thymeleaf.standard.expression.StandardExpressions;
import org.thymeleaf.templatemode.TemplateMode;
import ru.adaptms.quickui.handler.meta.HandlerMeta;
import ru.adaptms.quickui.registry.MappingRegistry;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.ui.util.uri.UriBuilder;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 08.01.2022 15:32
 */
public class LinkProcessor extends AbstractElementModelProcessor {

    private static final String ELEMENT_NAME = "link";
    private static final int PRECEDENCE = 800;

    public LinkProcessor(final String dialectPrefix) {
        super(
                TemplateMode.HTML,
                dialectPrefix,
                ELEMENT_NAME,
                true,
                null,
                false,
                PRECEDENCE
        );
    }

    @Override
    protected void doProcess(ITemplateContext context,
                             IModel model,
                             IElementModelStructureHandler structureHandler) {
        final IModelFactory modelFactory = context.getModelFactory();
        IEngineConfiguration configuration = context.getConfiguration();
        IStandardExpressionParser parser = StandardExpressions.getExpressionParser(configuration);

        Map<String, String> attributes = new HashMap<>();
        final ITemplateEvent linkEvent = model.get(0);

        var noBackdrop = false;

        if (linkEvent instanceof IOpenElementTag linkElement) {
            Map<String, String> incomingAttrs = linkElement.getAttributeMap();

            boolean disabled = false;
            if (incomingAttrs.containsKey("disabled")) {
                if (StringUtils.isBlank(incomingAttrs.get("disabled"))) {
                    disabled = true;
                } else {
                    Object dsbld = SpringELUtil.execute(incomingAttrs.get("disabled"), context, parser);
                    if (dsbld instanceof Boolean) {
                        disabled = (Boolean) dsbld;
                    } else if (dsbld instanceof String) {
                        disabled = !"false".equals(dsbld);
                    }
                }
            }

            String classes = (String) SpringELUtil.execute(incomingAttrs.get("class"), context, parser);

            if (!disabled) {
                HandlerMeta meta = MappingRegistry.instance().getMetaByName((String) SpringELUtil.execute(incomingAttrs.get("handler"), context, parser));
                UriBuilder action = UriBuilder.create(meta.getMapping(), true);

                ProcessorHelper.applyParams(action, incomingAttrs, context, parser, meta);

                /*if ( incomingAttrs.containsKey( "params" ) ) {
                    Map<String, Object> params = ( Map<String, Object> ) SpringELUtil.execute( incomingAttrs.get( "params" ), context, parser );
                    for ( Map.Entry<String, Object> entry : params.entrySet() ) {
                        action.parameter( meta.getParamCode( entry.getKey() ), entry.getValue() );
                    }
                }*/

                if (incomingAttrs.containsKey("target")) {
                    var target = (String) SpringELUtil.execute(incomingAttrs.get("target"), context, parser);
                    attributes.put("target", target);

                    if ("_blank".equals(target))
                        noBackdrop = true;
                }

                attributes.put("href", action.build());
                if (!StringUtils.isBlank(classes)) attributes.put("class", classes);
            } else {
                attributes.put("disabled", "disabled");
                attributes.put("class", (!StringUtils.isBlank(classes) ? classes : "") + " is-disabled");
                attributes.put("href", "javascript:");
            }

            String id = (String) SpringELUtil.execute(incomingAttrs.get("id"), context, parser);
            if (!StringUtils.isBlank(id)) attributes.put("id", id);
            attributes.put("style", (String) SpringELUtil.execute(incomingAttrs.get("style"), context, parser));

            // target="_blank" doesn't need backdrop
            if (!noBackdrop && !disabled)
                attributes.put("onclick", "showBackdrop(event)");

            String title = (String) SpringELUtil.execute(incomingAttrs.get("title"), context, parser);
            if (!StringUtils.isBlank(title))
                attributes.put("title", title);
        }

        IOpenElementTag formOpen = modelFactory
                .createOpenElementTag("a", attributes,
                        AttributeValueQuotes.DOUBLE,
                        false);

        model.replace(0, formOpen);
        model.replace(model.size() - 1, modelFactory.createCloseElementTag("a"));
    }
}
