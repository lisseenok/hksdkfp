package ru.adaptms.vwf.persistence.entity;

/**
 * Интерфейс для всех стандартных сущностей
 *
 * @author pavelpolyakov
 */
public interface IEntity extends IIdentifiable {
    //Long getGlobalId();
}
