package ru.adaptms.vwf.util.conversion.standard;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.adaptms.vwf.util.FormattingUtil;
import ru.adaptms.vwf.util.conversion.ConversionType;

import java.util.Date;

@Component
public class DateConversion extends ConversionType {
    @Override
    public Class<?> getTargetClass() {
        return Date.class;
    }

    @Override
    public Object doConvert(String input) {
        if (StringUtils.isBlank(input))
            return null;
        return FormattingUtil.instance().stringToDate(input);
    }
}
