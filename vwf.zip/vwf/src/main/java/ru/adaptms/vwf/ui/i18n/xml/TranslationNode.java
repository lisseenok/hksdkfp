package ru.adaptms.vwf.ui.i18n.xml;

import jakarta.xml.bind.annotation.XmlAttribute;
import java.util.Objects;

/**
 * @author ppolyakov at 24.01.2022 22:49
 */
public class TranslationNode {

    @XmlAttribute( required = true )
    public String lang;

    @XmlAttribute( required = true )
    public String value;

    public TranslationNode() {
    }

    @Override
    public boolean equals( Object o ) {
        if ( this == o ) return true;
        if ( !( o instanceof TranslationNode ) ) return false;
        TranslationNode that = ( TranslationNode ) o;
        return Objects.equals( lang, that.lang ) && Objects.equals( value, that.value );
    }

    @Override
    public int hashCode() {
        return Objects.hash( lang, value );
    }
}
