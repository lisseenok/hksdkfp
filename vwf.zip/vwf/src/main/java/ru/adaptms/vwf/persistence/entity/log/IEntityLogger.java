package ru.adaptms.vwf.persistence.entity.log;

import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.persistence.entity.browsing.EntityField;

/**
 * @author ppolyakov at 13.03.2022 18:33
 */
public interface IEntityLogger {

    void log( BaseEntity entity, EntityField field, String previousValue, String newValue );

}
