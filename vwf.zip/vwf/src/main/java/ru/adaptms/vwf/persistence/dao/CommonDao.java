package ru.adaptms.vwf.persistence.dao;

import org.adaptms.hqlbuilder.builder.HQLBuilder;
import org.adaptms.hqlbuilder.expression.Expressions;
import org.adaptms.hqlbuilder.expression.column.ColumnExpressionType;
import org.adaptms.hqlbuilder.property.EntityPath;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import ru.adaptms.vwf.persistence.entity.IEntity;
import ru.adaptms.vwf.persistence.entity.ISoftDeletable;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Имплементация стандартного DAO для всех необходимых операций
 *
 * @author polyakov_ps
 */
@Repository( "commonDao" )
@Transactional
public class CommonDao extends BaseDao implements ICommonDao {

    @Override
    public <T extends ISoftDeletable> T softDelete( T entity ) {
        if ( entity.getDeleted() == null )
            entity.setDeleted( new Date() );

        return save( entity );
    }

    @Override
    public <T extends IEntity, PK extends Serializable> void delete(Class<T> type, PK id) {
        T toDelete = find(type, id);

        if (toDelete != null)
            delete(toDelete);
    }

    @Override
    public <T> T list( String hql, Map<String, Object> params, Class<T> expectedType ) {
        return list( hql, params, List.class.isAssignableFrom( expectedType ) );
    }

    @Override
    public <T> T list( String hql, Map<String, Object> params, boolean list ) {
        Query<T> query = sessionFactory.getCurrentSession().createQuery( hql );
        for ( String key : params.keySet() ) {
            query.setParameter( key, params.get( key ) );
        }

        if ( list )
            return ( T ) query.list();
        else {
            query.setMaxResults( 1 );
            return query.uniqueResult();
        }
    }

    @Override
    public <T> T executeHQL( String hql, boolean list ) {
        Query<T> query = sessionFactory.getCurrentSession().createQuery( hql );
        if ( list )
            return ( T ) query.list();
        else {
            query.setMaxResults( 1 );
            return query.uniqueResult();
        }
    }

    @Override
    public List<Object> list( String hql ) {
        Query query = sessionFactory.getCurrentSession().createQuery( hql );
        return query.list();
    }

    @Override
    public <T> T executeSelect( HQLBuilder builder, Class<T> expectedType ) {
        return executeSelect( builder, List.class.isAssignableFrom( expectedType ) );
    }

    @Override
    public <T> T executeSelect( HQLBuilder builder, boolean list ) {
        Query<T> query = createQuery( builder );

        if ( list )
            return ( T ) query.list();
        else {
            query.setMaxResults( 1 );
            return query.uniqueResult();
        }
    }

    @Override
    public <T> int executeUpdate( HQLBuilder builder ) {
        Query<T> query = createQuery( builder );
        return query.executeUpdate();
    }

    @Override
    public <T> List<T> list( org.adaptms.hqlbuilder.builder.HQLBuilder builder ) {
        Query<T> query = createQuery( builder );

        return query.list();
    }

    @Override
    public long count( org.adaptms.hqlbuilder.builder.HQLBuilder builder, EntityPath countProperty ) {
        builder.column( countProperty, ColumnExpressionType.COUNT );
        return executeSelect( builder, long.class );
    }

    @Override
    public <T> List<T> list( org.adaptms.hqlbuilder.builder.HQLBuilder builder, int max, int offset ) {
        Query<T> query = createQuery( builder );

        query.setMaxResults( max );
        query.setFirstResult( offset );

        return query.list();
    }

    @Override
    public <T> T first( org.adaptms.hqlbuilder.builder.HQLBuilder builder ) {
        Query<T> query = createQuery( builder );

        query.setMaxResults( 1 );
        return query.uniqueResult();
    }
}
