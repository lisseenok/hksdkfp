package ru.adaptms.vwf.ui.i18n;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.ui.i18n.xml.MessageNode;
import ru.adaptms.vwf.ui.i18n.xml.MessagesNode;
import ru.adaptms.vwf.ui.i18n.xml.TranslationNode;
import ru.adaptms.vwf.util.SpringUtils;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.Map;

/**
 * @author ppolyakov at 24.01.2022 23:44
 */
@Service( "i18n" )
public class I18NService {
    public static I18NService instance() { return SpringUtils.getInstance( I18NService.class ); }

    private MessageSource messageSource;

    public String decideLocale( String ru, String en ) {
        Locale locale = LocaleContextHolder.getLocale();

        if ( locale.equals( new Locale( "ru" ) ) ) return ru;
        if ( locale.equals( new Locale( "en" ) ) ) return en;

        return ru;
    }

    public String decideLocale( MessageDefinition definition ) {
        Locale locale = LocaleContextHolder.getLocale();

        return definition.getTranslation( locale.getLanguage() );
    }

    public boolean isLocale( String locale ) {
        return LocaleContextHolder.getLocale().equals( new Locale( locale ) );
    }

    public String getLocale() {
        return getLocaleObject().getLanguage();
    }

    public Locale getLocaleObject() {
        return LocaleContextHolder.getLocale();
    }

    public String getMessage( String code ) {
        return messageSource.getMessage( code, null, getLocaleObject() );
    }

    public String getMessage( String code, Locale locale ) {
        return messageSource.getMessage( code, null, locale );
    }

    public String getMessage( String code, String defaultMessage ) {
        return messageSource.getMessage( code, null, defaultMessage, getLocaleObject() );
    }

    public String getMessage( String code, String defaultMessage, Locale locale ) {
        return messageSource.getMessage( code, null, defaultMessage, locale );
    }

    public String getMessageFormatted(String code, Object substitutions) {
        return MessageFormat.format(messageSource.getMessage(code, null, getLocaleObject()), substitutions);
    }

    public static void processMessagesNode( Map<String, MessageDefinition> messages, MessagesNode messagesNode, String previousPrefix ) {
        if ( previousPrefix == null )
            previousPrefix = "";

        String currentPrefix = ( messagesNode.prefix != null ? messagesNode.prefix : "" );

        if ( messagesNode.messages != null ) {
            for ( MessageNode message : messagesNode.messages ) {
                MessageDefinition definition = new MessageDefinition( message.code );
                for ( TranslationNode translation : message.translations ) {
                    definition.translation( translation.lang, translation.value );
                }

                messages.put( previousPrefix + currentPrefix + message.code, definition );
            }
        }

        if ( messagesNode.blocks != null ) {
            for ( MessagesNode block : messagesNode.blocks ) {
                processMessagesNode( messages, block, previousPrefix + currentPrefix );
            }
        }
    }

    @Autowired
    public void setMessageSource( MessageSource messageSource ) {
        this.messageSource = messageSource;
    }
}
