package ru.adaptms.vwf.persistence.migration.structure.action.constraint;

import ru.adaptms.vwf.persistence.migration.structure.MigrationAction;
import ru.adaptms.vwf.persistence.migration.types.DBType;

/**
 * Удаление внешнего ключа (ссылки на сущность)
 * @implNote для MySQL нужно вручную отдельно удалять соответствующий индекс
 * @see DropIndex
 * @see ru.adaptms.framework.persistence.migration.structure.AbstractMigration AbstractMigration.dropForeignKey(String, String) автоматически добавит это действие для MySQL
 *
 * @author ppolyakov at 11.12.2021 19:09
 */
public class DropForeignKey extends MigrationAction {

    private String tableName;
    private String foreignKey;

    /**
     * @param tableName Таблица, с которой работаем
     * @param fkToDrop имя ключа (ограничения)
     */
    public DropForeignKey( String tableName, String fkToDrop ) {
        this.tableName = tableName;
        this.foreignKey = fkToDrop;
    }

    @Override
    public String generateSQL( String dbType ) {
        StringBuilder builder = new StringBuilder( "ALTER TABLE " );
        builder.append( tableName )
                .append( " DROP " );

        // разные СУБД по-разному строят этот синтаксис
        if ( dbType.matches( DBType.MYSQL_8 ) || dbType.matches( DBType.MYSQL_5 ) )
            builder.append( "FOREIGN KEY " ); // индекс при этом не удаляется!
        else if ( dbType.matches( DBType.MSSQL ) || dbType.matches( DBType.PSQL ) )
            builder.append( "CONSTRAINT " ); // индекс удаляется автоматически
        else
            throw new IllegalStateException( "No such DB type: " + dbType );

        builder.append( foreignKey );

        return  builder.toString();
    }
}
