package ru.adaptms.vwf.persistence.migration.template;

/**
 * @author ppolyakov at 10.12.2021 17:30
 */
public class DefaultTemplates {

    public static final ITableTemplate SIMPLE_ENTITY = new SimpleEntityTable();
}
