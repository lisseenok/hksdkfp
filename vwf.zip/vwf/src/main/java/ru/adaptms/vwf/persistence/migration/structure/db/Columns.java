package ru.adaptms.vwf.persistence.migration.structure.db;

import ru.adaptms.vwf.persistence.migration.types.ColumnType;

/**
 * Шорткаты для создания колонок всех типов
 *
 * @author ppolyakov at 10.12.2021 17:44
 */
public class Columns {

    public static DBTableColumn BIT(String name) {
        return new DBTableColumn(name, ColumnType.BIT);
    }

    public static DBTableColumn BOOLEAN(String name) {
        return BIT(name);
    }

    public static DBTableColumn SHORT(String name) {
        return new DBTableColumn(name, ColumnType.SHORT);
    }

    public static DBTableColumn INT(String name) {
        return new DBTableColumn(name, ColumnType.INT);
    }

    public static DBTableColumn LONG(String name) {
        return new DBTableColumn(name, ColumnType.LONG);
    }

    public static DBTableColumn STRING(String name) {
        return new DBTableColumn(name, ColumnType.STRING);
    }

    public static DBTableColumn UUID(String name) {
        return new DBTableColumn(name, ColumnType.UUID);
    }

    public static DBTableColumn TEXT(String name) {
        return new DBTableColumn(name, ColumnType.TEXT);
    }
    public static DBTableColumn JSON(String name) {
        return new DBTableColumn(name, ColumnType.JSON);
    }

    public static DBTableColumn BLOB(String name) {
        return new DBTableColumn(name, ColumnType.BLOB);
    }

    public static DBTableColumn DATE(String name) {
        return new DBTableColumn(name, ColumnType.DATE);
    }

    public static DBTableColumn TIME(String name) {
        return new DBTableColumn(name, ColumnType.TIME);
    }

    public static DBTableColumn DATETIME(String name) {
        return new DBTableColumn(name, ColumnType.DATETIME);
    }

    public static DBTableColumn TIMESTAMP(String name) {
        return new DBTableColumn(name, ColumnType.TIMESTAMP);
    }

}
