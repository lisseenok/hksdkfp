package ru.adaptms.vwf.ui.search;

import java.io.Serializable;

/**
 * @author ppolyakov at 21.01.2022 03:41
 */
public class SearchFilter implements Serializable {
    private String filter;
    private Integer page;

    public SearchFilter() {
    }

    public SearchFilter( String filter, Integer page ) {
        this.filter = filter;
        this.page = page;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter( String filter ) {
        this.filter = filter;
    }

    public Integer getPage() {
        return page;
    }

    public void setPage( Integer page ) {
        this.page = page;
    }

    @Override
    public String toString() {
        return this.getFilter();
    }
}
