package ru.adaptms.vwf.persistence.meta;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.MappedSuperclass;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.util.LoggingUtil;
import ru.adaptms.vwf.util.SpringUtils;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author ppolyakov at 13.04.2022 18:24
 */
@Service("framework_entityregistry")
@RequiredArgsConstructor
public class EntityRegistry {
    private final Map<Class<? extends BaseEntity>, EntityMeta> entityClassToMeta = new HashMap<>();
    private final Map<String, EntityMeta> entityNameToMeta = new HashMap<>();
    private final ReflectionsUtil reflectionsUtil;

    public static EntityRegistry instance() {
        return SpringUtils.getInstance(EntityRegistry.class);
    }

    public EntityMeta getMetaByClass(Class<? extends BaseEntity> entityClass) {
        return entityClassToMeta.get(entityClass);
    }

    public EntityMeta getMetaByName(String entityName) {
        return entityNameToMeta.get(entityName);
    }

    @PostConstruct
    public void init() {
        LoggingUtil.debug(EntityRegistry.class, "Creating entity metadata...");

        Set<Class<? extends BaseEntity>> entityClasses = reflectionsUtil.getSubclasses(BaseEntity.class);

        Map<Class<? extends BaseEntity>, List<IncomingReference>> references = new HashMap<>();

        // traverse all found entities
        if (entityClasses != null) {
            for (Class<? extends BaseEntity> entityClass : entityClasses) {
                if (entityClass.isAnnotationPresent(MappedSuperclass.class)) continue;

                List<IncomingReference> referencesForClass = new ArrayList<>();
                EntityMeta meta = new EntityMeta(entityClass, referencesForClass);
                entityClassToMeta.put(entityClass, meta);
                entityNameToMeta.put(meta.getName(), meta);

                // if class has any outgoing references - put it so that they could later be attached to appropriate metas
                for (IncomingReference ref : referencesForClass) {
                    if (!references.containsKey(ref.getTargetClass()))
                        references.put(ref.getTargetClass(), new ArrayList<>());
                    references.get(ref.getTargetClass()).add(ref);
                }
            }
        }

        // attach found references to their target classes' meta
        for (Map.Entry<Class<? extends BaseEntity>, List<IncomingReference>> reference : references.entrySet()) {
            getMetaByClass(reference.getKey()).getIncomingReferences().addAll(reference.getValue());
        }

        LoggingUtil.debug(EntityRegistry.class, MessageFormat.format("Done. {0} entities found.", entityClassToMeta.size()));
    }
}
