package ru.adaptms.vwf.ui.thymeleaf.dialect;

import org.thymeleaf.processor.IProcessor;
import ru.adaptms.quickui.thymeleaf.processor.component.ComponentProcessor;
import ru.adaptms.quickui.thymeleaf.processor.frame.FrameProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.block.BlockProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.breadcrumb.BreadcrumbProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.download.DownloadProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.form.FormProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.grid.GridProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.icon.IconProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.input.InputProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.loader.LoaderProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.logicOutput.LogicOutputProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.notification.NotificationProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.select.SelectProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.tabpanel.TabpanelProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.trigger.ActionProcessor;
import ru.adaptms.vwf.ui.thymeleaf.processor.trigger.LinkProcessor;

import java.util.HashSet;
import java.util.Set;

/**
 * @author ppolyakov at 01.01.2022 21:00
 */
public class VanguardUIDialect extends AbstractUIDialect {
    private static final String PROCESSOR_NAME = "Adapt Vanguard UI dialect";
    private static final String DIALECT_PREFIX = "ui";
    private static final int PRECEDENCE = 1200;

    public VanguardUIDialect() {
        super(PROCESSOR_NAME, DIALECT_PREFIX, PRECEDENCE);
    }

    @Override
    public Set<IProcessor> getProcessors(final String dialectPrefix) {
        final Set<IProcessor> processors = new HashSet<IProcessor>();
        processors.add(new FrameProcessor(DIALECT_PREFIX));
        processors.add(new ComponentProcessor(DIALECT_PREFIX));
        processors.add(new FormProcessor(DIALECT_PREFIX));
        processors.add(new InputProcessor(DIALECT_PREFIX));
        processors.add(new SelectProcessor(DIALECT_PREFIX));
        processors.add(new GridProcessor(DIALECT_PREFIX));
        processors.add(new ActionProcessor(DIALECT_PREFIX));
        processors.add(new LinkProcessor(DIALECT_PREFIX));
        processors.add(new DownloadProcessor(DIALECT_PREFIX));
        processors.add(new BreadcrumbProcessor(DIALECT_PREFIX));
        processors.add(new NotificationProcessor(DIALECT_PREFIX));
        processors.add(new TabpanelProcessor(DIALECT_PREFIX));
        processors.add(new BlockProcessor(DIALECT_PREFIX));
        processors.add(new LogicOutputProcessor(DIALECT_PREFIX));
        processors.add(new IconProcessor(DIALECT_PREFIX));
        processors.add(new LoaderProcessor(DIALECT_PREFIX));
        return processors;
    }
}
