package ru.adaptms.vwf.ui.thymeleaf.processor.input;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.thymeleaf.context.Context;
import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.model.IProcessableElementTag;
import org.thymeleaf.processor.element.IElementTagStructureHandler;
import org.thymeleaf.standard.expression.IStandardExpressionParser;
import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.thymeleaf.processor.AbstractUITagProcessor;
import ru.adaptms.vwf.persistence.entity.IFile;
import ru.adaptms.vwf.ui.i18n.I18NService;
import ru.adaptms.vwf.ui.thymeleaf.util.ProcessorHelper;
import ru.adaptms.vwf.ui.util.SpringELUtil;
import ru.adaptms.vwf.util.FormattingUtil;
import ru.adaptms.vwf.util.file.MimeTypeUtil;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * @author ppolyakov at 01.01.2022 21:04
 */
public class InputProcessor extends AbstractUITagProcessor {
    private static final String ELEMENT_NAME = "input";
    private static final int PRECEDENCE = 900;

    public InputProcessor(String dialectPrefix) {
        super(dialectPrefix, ELEMENT_NAME, PRECEDENCE);
    }

    @Override
    protected void doProcess(ITemplateContext incomingContext,
                             IProcessableElementTag elementTag,
                             IElementTagStructureHandler structureHandler) {
        if (!requireAttributes(elementTag, structureHandler, "type", "id")) return;

        Context outgoingContext = getContext();
        IStandardExpressionParser parser = getParser(incomingContext);

        Type type = Type.valueOf(elementTag.getAttributeValue("type").toUpperCase(Locale.ROOT));

        String id = (String) SpringELUtil.execute(elementTag.getAttributeValue("id"), incomingContext, parser);

        AbstractUIHandler handler = (AbstractUIHandler) incomingContext.getVariable(AbstractUIHandler.HANDLER_VARIABLE);
        if (handler != null) {
            id += "_" + handler.getHandlerId();
        }

        // common attributes
        outgoingContext.setVariable("id", id);
        outgoingContext.setVariable("handler", handler);
        outgoingContext.setVariable("name", SpringELUtil.execute(elementTag.getAttributeValue("name"), incomingContext, parser));
        outgoingContext.setVariable("label", SpringELUtil.execute(elementTag.getAttributeValue("label"), incomingContext, parser));
        outgoingContext.setVariable("classes", SpringELUtil.execute(elementTag.getAttributeValue("class"), incomingContext, parser));
        outgoingContext.setVariable("outerClasses", SpringELUtil.execute(elementTag.getAttributeValue("outerClasses"), incomingContext, parser));
        outgoingContext.setVariable("styles", SpringELUtil.execute(elementTag.getAttributeValue("style"), incomingContext, parser));
        outgoingContext.setVariable("placeholder", SpringELUtil.execute(elementTag.getAttributeValue("placeholder"), incomingContext, parser));
        outgoingContext.setVariable("patternHelp", SpringELUtil.execute(elementTag.getAttributeValue("patternHelp"), incomingContext, parser));
        outgoingContext.setVariable("help", SpringELUtil.execute(elementTag.getAttributeValue("help"), incomingContext, parser));

        String formId = (String) SpringELUtil.execute(elementTag.getAttributeValue("form"), incomingContext, parser);
        if (!StringUtils.isBlank(formId) && handler != null)
            formId = formId + "_" + handler.getHandlerId();

        outgoingContext.setVariable("form", formId);

        applyBooleanField(outgoingContext, elementTag, "required", SpringELUtil.execute(elementTag.getAttributeValue("required"), incomingContext, parser));
        applyBooleanField(outgoingContext, elementTag, "disabled", SpringELUtil.execute(elementTag.getAttributeValue("disabled"), incomingContext, parser));
        applyBooleanField(outgoingContext, elementTag, "readonly", SpringELUtil.execute(elementTag.getAttributeValue("readonly"), incomingContext, parser));

        // process value and set to render context
        if (type == Type.FILE) {
            // for files - get file name
            IFile file = (IFile) SpringELUtil.execute(elementTag.getAttributeValue("value"), incomingContext, parser);
            if (file != null)
                outgoingContext.setVariable("value", file);
        } else if (type == Type.DATE) {
            // date - apply as a date (@note also applies some date format variables)
            applyDateTimeValueAndSpecifics(incomingContext, elementTag, outgoingContext, parser);
        } else {
            // in all other cases - just get value
            outgoingContext.setVariable("value", SpringELUtil.execute(elementTag.getAttributeValue("value"), incomingContext, parser));
        }

        // process settings for different types of fields
        if (Set.of(
                Type.TEXT,
                Type.PASSWORD,
                Type.EMAIL,
                Type.TEXTAREA,
                Type.CODE,
                Type.WYSIWYG,
                Type.NUMBER
        ).contains(type)) {
            // standard fields for any text-like fields
            outgoingContext.setVariable("pattern", SpringELUtil.execute(elementTag.getAttributeValue("pattern"), incomingContext, parser));
            outgoingContext.setVariable("onkeypress", SpringELUtil.execute(elementTag.getAttributeValue("onkeypress"), incomingContext, parser));
            outgoingContext.setVariable("size", SpringELUtil.execute(elementTag.getAttributeValue("size"), incomingContext, parser));
            outgoingContext.setVariable("minLength", SpringELUtil.execute(elementTag.getAttributeValue("minLength"), incomingContext, parser));

            if (elementTag.hasAttribute("maxLength"))
                outgoingContext.setVariable("maxLength", SpringELUtil.execute(elementTag.getAttributeValue("maxLength"), incomingContext, parser));
            else if (type != Type.TEXTAREA && type != Type.CODE && type != Type.WYSIWYG)
                outgoingContext.setVariable("maxLength", 255); // all fields except for textarea, code and wysiwyg default to 255 max length
        } else if (type == Type.CHECKBOX
                || type == Type.SWITCH
                || type == Type.RADIO) {
            // checkboxes etc use another way of indicating that a value is picked. "value" is used to set what is passed if it's checked
//            outgoingContext.setVariable("checked", SpringELUtil.execute(elementTag.getAttributeValue("checked"), incomingContext, parser));
            applyBooleanField(outgoingContext, elementTag, "checked", SpringELUtil.execute(elementTag.getAttributeValue("checked"), incomingContext, parser));
        } else if (type == Type.FILE) {
            String defaultFileHelp = "";

            // resolve available file extensions as mime types for provided "extensions" attribute
            String extensionsAttr = (String) SpringELUtil.execute(elementTag.getAttributeValue("extensions"), incomingContext, parser);
            if (!StringUtils.isBlank(extensionsAttr)) {
                outgoingContext.setVariable("extensions", extensionsAttr);
                String[] extensions = extensionsAttr.split(",");
                List<String> mimeTypes = Arrays.stream(extensions).map(ext -> MimeTypeUtil.getMimeType("." + ext)).toList();
                outgoingContext.setVariable("mimeTypes", String.join("|", mimeTypes));
                outgoingContext.setVariable("accept", "." + String.join(", .", extensions));

                defaultFileHelp += MessageFormat.format(I18NService.instance().getMessage("framework.ui.validation.files.help.extension"), String.join(", ", extensions));
            }

            Long maxSizeAttr = (Long) SpringELUtil.execute(elementTag.getAttributeValue("maxSize"), incomingContext, parser);
            outgoingContext.setVariable("maxSize", maxSizeAttr);

            if (maxSizeAttr != null) {
                if (StringUtils.isNotBlank(defaultFileHelp)) defaultFileHelp += " ";
                defaultFileHelp += MessageFormat.format(I18NService.instance().getMessage("framework.ui.validation.files.help.size"), ProcessorHelper.formatMaxFileSize(maxSizeAttr));
            }

            outgoingContext.setVariable("defaultFileHelp", defaultFileHelp);

            // handler listener for downloading current value
            outgoingContext.setVariable("downloadListener", SpringELUtil.execute(elementTag.getAttributeValue("downloadListener"), incomingContext, parser));

            // toggles built-in camera (webcam) usage to use for file field
            applyBooleanField(outgoingContext, elementTag, "useCamera", SpringELUtil.execute(elementTag.getAttributeValue("useCamera"), incomingContext, parser));
        }

        // apply special attributes only allowed for certain input types
        if (type == Type.TEXT) {
            outgoingContext.setVariable("mask", SpringELUtil.execute(elementTag.getAttributeValue("mask"), incomingContext, parser));
            applyBooleanField(outgoingContext, elementTag, "copyable", SpringELUtil.execute(elementTag.getAttributeValue("copyable"), incomingContext, parser));
        } else if (type == Type.DATE) {
            outgoingContext.setVariable("scrollContainer", SpringELUtil.execute(elementTag.getAttributeValue("scrollContainer"), incomingContext, parser));
        } else if (type == Type.NUMBER) {
            outgoingContext.setVariable("step", SpringELUtil.execute(elementTag.getAttributeValue("step"), incomingContext, parser));
            outgoingContext.setVariable("min", SpringELUtil.execute(elementTag.getAttributeValue("min"), incomingContext, parser));
            outgoingContext.setVariable("max", SpringELUtil.execute(elementTag.getAttributeValue("max"), incomingContext, parser));
        } else if (type == Type.TEXTAREA || type == Type.CODE) {
            outgoingContext.setVariable("rows", SpringELUtil.execute(elementTag.getAttributeValue("rows"), incomingContext, parser));
            outgoingContext.setVariable("columns", SpringELUtil.execute(elementTag.getAttributeValue("columns"), incomingContext, parser));
            applyBooleanField(outgoingContext, elementTag, "monospace", SpringELUtil.execute(elementTag.getAttributeValue("monospace"), incomingContext, parser));
        }

        if (type == Type.CODE) {
            if (!requireAttributes(elementTag, structureHandler, "lang")) return;
            outgoingContext.setVariable("codeLanguage", SpringELUtil.execute(elementTag.getAttributeValue("lang"), incomingContext, parser));
        }

        // render
        structureHandler.replaceWith(getTemplate(outgoingContext, "type_" + type.name()), false);
    }

    /**
     * Calculate date/time input's value and specific parameters and set them to render context
     */
    private void applyDateTimeValueAndSpecifics(ITemplateContext incomingContext,
                                                IProcessableElementTag elementTag,
                                                Context outgoingContext,
                                                IStandardExpressionParser parser) {
        // define format (date / time / datetime)
        boolean date = resolveDateTimeEnabled(incomingContext, elementTag, outgoingContext, parser, "date", true);
        boolean time = resolveDateTimeEnabled(incomingContext, elementTag, outgoingContext, parser, "time", false);

        String helpPattern; // pattern for UI in locale

        Object value = SpringELUtil.execute(elementTag.getAttributeValue("value"), incomingContext, parser); // get value from context
        helpPattern = applyDateTimeVariables(value, outgoingContext, date, time);

        // both placeholder and helper text
        outgoingContext.setVariable("placeholder", helpPattern);
        outgoingContext.setVariable("patternHelp", helpPattern);

        // input restrictions
        Date minDate = (Date) SpringELUtil.execute(elementTag.getAttributeValue("minDate"), incomingContext, parser);
        Date maxDate = (Date) SpringELUtil.execute(elementTag.getAttributeValue("maxDate"), incomingContext, parser);
        Date minTime = (Date) SpringELUtil.execute(elementTag.getAttributeValue("minTime"), incomingContext, parser);
        Date maxTime = (Date) SpringELUtil.execute(elementTag.getAttributeValue("maxTime"), incomingContext, parser);

        outgoingContext.setVariable("minDate", FormattingUtil.instance().formatDate(minDate, "MM/dd/yyyy"));
        outgoingContext.setVariable("maxDate", FormattingUtil.instance().formatDate(maxDate, "MM/dd/yyyy"));
        outgoingContext.setVariable("minTime", FormattingUtil.instance().formatDate(minTime, "HH:mm"));
        outgoingContext.setVariable("maxTime", FormattingUtil.instance().formatDate(maxTime, "HH:mm"));
    }

    /**
     * Check whether date or time are enabled in this date input
     * @param attribute attribute name to check
     * @param defaultValue value to
     * @return result or default value if attribute doesn't exist
     */
    private boolean resolveDateTimeEnabled(ITemplateContext incomingContext,
                                           IProcessableElementTag elementTag,
                                           Context outgoingContext,
                                           IStandardExpressionParser parser,
                                           String attribute, boolean defaultValue) {
        if (elementTag.hasAttribute(attribute)) {
            // resolve by attribute value
            applyBooleanField(outgoingContext, elementTag, attribute, SpringELUtil.execute(elementTag.getAttributeValue(attribute), incomingContext, parser));
        } else {
            // use default value
            outgoingContext.setVariable(attribute, defaultValue);
        }
        return (boolean) outgoingContext.getVariable(attribute); // return from context
    }

    /**
     * Apply specific formatting variables (for Air DatePicker)
     * @param value value to set, can be either a string (dd.MM.yyyy HH:mm) or a date
     * @param outgoingContext render context to apply variables to
     * @param date is date part enabled
     * @param time is time part enabled
     * @return resulting help pattern
     */
    private String applyDateTimeVariables(Object value, Context outgoingContext,
                                          boolean date, boolean time) {
        String pattern = "^", helpPatternRu = "", helpPatterEn = "", mask = "", valuePattern = "";

        // first part - if date is enabled
        if (date) {
            pattern += "([0-2][0-9]|3[0-1])\\.([0-1][0-2]|0[0-9])\\.[1-2][\\d]{3}";
            helpPatternRu += "дд.мм.гггг";
            helpPatterEn += "dd.mm.yyyy";
            mask += "00.00.0000";
            valuePattern += "dd.MM.yyyy";
        }

        // if time is enabled
        if (time) {
            // if date part is enabled - add spaces
            if (date) {
                pattern += "\\s";
                helpPatternRu += " ";
                helpPatterEn += " ";
                mask += " ";
                valuePattern += " ";
            }

            // add time parts
            pattern += "([0-1][0-9]|2[0-3]):([0-5][0-9])";
            helpPatternRu += "чч:мм";
            helpPatterEn += "hh:mm";
            mask += "00:00";
            valuePattern += "HH:mm";
        }

        pattern += "$"; // end of the input matching for regexp

        outgoingContext.setVariable("pattern", pattern);
        outgoingContext.setVariable("mask", mask);

        // required variables for Air Datepicker to set the correct date/time pattern
        if (date) outgoingContext.setVariable("airDate", "dd.MM.yyyy");
        if (time) outgoingContext.setVariable("airTime", "HH:mm");

        if (value instanceof Date dateValue)
            outgoingContext.setVariable("value", FormattingUtil.instance().formatDate(dateValue, valuePattern));
        else
            outgoingContext.setVariable("value", value);

        return I18NService.instance().decideLocale(helpPatternRu, helpPatterEn);
    }

    @Getter
    @RequiredArgsConstructor
    public enum Type {
        TEXT,
        PASSWORD,
        EMAIL,
        NUMBER,
        DATE,
        CHECKBOX,
        SWITCH,
        RADIO,
        TEXTAREA,
        CODE,
        WYSIWYG,
        FILE
    }
}
