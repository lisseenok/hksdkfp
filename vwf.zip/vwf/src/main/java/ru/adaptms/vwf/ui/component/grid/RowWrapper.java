package ru.adaptms.vwf.ui.component.grid;

import ru.adaptms.vwf.persistence.entity.IIdentifiable;

import java.util.HashMap;
import java.util.Map;

/**
 * @author ppolyakov at 27.01.2022 15:26
 */
public class RowWrapper implements IIdentifiable {

    private Long id;

    private Map<String, Object> properties = new HashMap<>();

    public RowWrapper( Long id ) {
        this.id = id;
    }

    public RowWrapper setProperty( String name, Object value ) {
        properties.put( name, value );
        return this;
    }

    public Object getProperty( String name ) {
        return properties.get( name );
    }

    @Override
    public Long getId() {
        return id;
    }

    public void setId( Long id ) {
        this.id = id;
    }
}
