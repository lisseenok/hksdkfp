package ru.adaptms.vwf.persistence.entity.log;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.adaptms.vwf.persistence.entity.BaseEntity;
import ru.adaptms.vwf.persistence.entity.browsing.EntityField;
import ru.adaptms.vwf.util.SpringUtils;

/**
 * @author ppolyakov at 07.02.2022 19:59
 */
@Service
public class EntityLogUtil {

    private IEntityLogger entityLogger;

    public static EntityLogUtil instance() { return SpringUtils.getInstance( EntityLogUtil.class ); }

    public void logField( BaseEntity entity, EntityField field, String previousValue, String newValue ) {
        if ( entityLogger != null )
            entityLogger.log( entity, field, previousValue, newValue );
    }

    @Autowired( required = false )
    public void setEntityLogger( IEntityLogger entityLogger ) {
        this.entityLogger = entityLogger;
    }
}
