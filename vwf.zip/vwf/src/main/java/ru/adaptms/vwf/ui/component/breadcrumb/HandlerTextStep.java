package ru.adaptms.vwf.ui.component.breadcrumb;

import ru.adaptms.quickui.handler.AbstractUIHandler;
import ru.adaptms.quickui.registry.MappingRegistry;

/**
 * @author ppolyakov at 17.03.2022 10:06
 */
public class HandlerTextStep extends TextStep {

    public HandlerTextStep( String title ) {
        super( title );
    }

    public HandlerTextStep( String title, String handlerName ) {
        super( title, MappingRegistry.instance().getMetaByName( handlerName ).getMapping() );
    }

    public HandlerTextStep( String title, Class<? extends AbstractUIHandler> handlerClass ) {
        super( title, MappingRegistry.instance().getMetaByClass( handlerClass ).getMapping() );
    }

    @Override
    public boolean isSpel() {
        return true;
    }
}
