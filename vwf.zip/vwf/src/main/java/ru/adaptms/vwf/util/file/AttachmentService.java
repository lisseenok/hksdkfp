package ru.adaptms.vwf.util.file;

import org.springframework.http.ContentDisposition;

import jakarta.servlet.http.HttpServletResponse;
import java.nio.charset.StandardCharsets;

public class AttachmentService {

    public static void prepareAttachmentResponse( HttpServletResponse response, String fileNameWithExtension ) {
        prepareAttachmentResponse( response, fileNameWithExtension, true );
    }

    public static void prepareAttachmentResponse( HttpServletResponse response, String fileNameWithExtension, boolean setDefaultHeaders ) {
        ContentDisposition disposition = ContentDisposition.builder( "attachment" )
                .filename( fileNameWithExtension, StandardCharsets.UTF_8 )
                .build();
        response.setContentType( MimeTypeUtil.getMimeType( fileNameWithExtension ) );
        if ( setDefaultHeaders )
            setDefaultHeaders( response );
        response.setHeader( "Content-Disposition", disposition.toString() );
    }

    public static void prepareAttachmentResponse( HttpServletResponse response, String fileName, FileExtension type ) {
        ContentDisposition disposition = ContentDisposition.builder( "attachment" )
                .filename( fileName + "." + type.getFileExtension(), StandardCharsets.UTF_8 )
                .build();
        response.setContentType( type.mimeType );
        setDefaultHeaders( response );
        response.setHeader( "Content-Disposition", disposition.toString() );
    }

    private static void setDefaultHeaders( HttpServletResponse response ) {
        response.setHeader( "Cache-Control", "no-cache" );
        response.setHeader( "Expires", "0" );
        response.setHeader( "Pragma", "no-cache" );
    }
}
