package ru.adaptms.vwf.persistence.migration.structure.db.constraint;

/**
 * Абстрактный прародитель  для всех ограничений
 *
 * @author ppolyakov at 05.12.2021 19:36
 */
public abstract class DBConstraint {

    protected String baseColumn;
    protected String constraintName;

    /**
     * @param constraintName имя ограничения
     */
    protected DBConstraint( String constraintName ) {
        this.constraintName = constraintName;
    }

    /**
     * Задать колонку, к которой оно будет применяться
     * @param column имя колонки
     */
    public DBConstraint baseColumn( String column ) {
        this.baseColumn = column;
        return this;
    }

    public String getBaseColumn() {
        return baseColumn;
    }

    public String getConstraintName() {
        return constraintName;
    }

    /**
     * Модификация билдера для задания данного ограничения (когда до него дойдет очередь)
     * @param dbType тип СУБД
     * @param builder билдер
     */
    public abstract void apply( String dbType, StringBuilder builder );

}
