package ru.adaptms.vwf.ui.util;

import org.thymeleaf.context.ITemplateContext;
import org.thymeleaf.standard.expression.IStandardExpression;
import org.thymeleaf.standard.expression.IStandardExpressionParser;

/**
 * @author ppolyakov at 01.01.2022 21:31
 */
public class SpringELUtil {
    public static Object execute( String expression, ITemplateContext incomingContext,
                                  IStandardExpressionParser parser ) {
        if ( expression == null ||
                !( expression.contains( "${" )
                    || expression.contains( "@{" )
                    || expression.contains( "~{" )
                    || expression.contains( "#{" ) ) )
            return expression;

        //create and execute expression
        final IStandardExpression messageExpression = parser.parseExpression( incomingContext, expression );
        return messageExpression.execute( incomingContext );
    }

    public static boolean stringToBoolean( String input ) {
        if ( null == input || input.isEmpty() )
            return false;
        else if ( "true".equals( input ) )
            return true;
        else if ( "false".equals( input ) )
            return false;
        return false;
    }
}
