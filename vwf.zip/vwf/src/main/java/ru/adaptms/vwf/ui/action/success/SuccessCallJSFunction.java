package ru.adaptms.vwf.ui.action.success;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Do nothing
 *
 * @author ppolyakov at 18.02.2025 00:46
 */
@RequiredArgsConstructor
public class SuccessCallJSFunction implements ISuccessAction {

    @Getter
    private final String fn;

    @Getter
    private Object fnData;

    public SuccessCallJSFunction data(Object fnData) {
        this.fnData = fnData;
        return this;
    }

    @Override
    public String getAction() {
        return "jsfn";
    }
}
