package ru.adaptms.vwf.persistence.migration;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.adaptms.vwf.config.PersistenceConfig;
import ru.adaptms.vwf.persistence.migration.structure.AbstractMigration;
import ru.adaptms.vwf.persistence.migration.structure.ExecuteAfter;
import ru.adaptms.vwf.persistence.migration.version.PlatformVersion;
import ru.adaptms.vwf.ui.util.AppDefines;
import ru.adaptms.vwf.util.reflections.ReflectionsUtil;

import java.util.ArrayList;
import java.util.List;

@ExtendWith(MockitoExtension.class)
class MigrationServiceTest {

    @Mock
    private ReflectionsUtil reflectionsUtil;

    @Mock
    private PersistenceConfig persistenceConfig;

    @InjectMocks
    private MigrationService migrationService;

    @Test
    void migrate() {
        AppDefines.set(AppDefines.VERSION, new PlatformVersion("1.1.0", false));

        List<MigrationService.MigratorDefinition> migratorDefinitions = new ArrayList<>();

        migratorDefinitions.add(migrationService.createDefinition(Alm_1_0_2_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Api_1_0_0_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Sh_1_0_0_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Sh_1_0_2_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Fb_1_0_1_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Rnsi_1_0_1_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Dorg_1_0_1_rev1.class));
        migratorDefinitions.add(migrationService.createDefinition(Dpass_1_0_1_rev1.class));

        migrationService.sortMigrations(migratorDefinitions);
        migrationService.ensureOrder(migratorDefinitions);

        for (MigrationService.MigratorDefinition migratorDefinition : migratorDefinitions) {
            System.err.println(migratorDefinition.getMigratorClass().getSimpleName());
        }
    }

    private static class Alm_1_0_2_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    private static class Api_1_0_0_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    private static class Sh_1_0_0_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    private static class Sh_1_0_2_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    @ExecuteAfter(Rnsi_1_0_1_rev1.class)
    private static class Dorg_1_0_1_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    @ExecuteAfter(Rnsi_1_0_1_rev1.class)
    private static class Fb_1_0_1_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    private static class Rnsi_1_0_1_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

    @ExecuteAfter(Rnsi_1_0_1_rev1.class)
    private static class Dpass_1_0_1_rev1 extends AbstractMigration {
        @Override
        public void prepare() {
            System.err.println(this.getClass().getSimpleName());
        }
    }

}
